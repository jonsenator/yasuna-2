<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';

$slug = trim($_GET['slug'] ?? '');
$post = $slug !== '' ? get_post_by_slug($slug) : null;

if (!$post) {
    http_response_code(404);
    $meta_title = 'Topilmadi';
    require __DIR__ . '/includes/header.php';
    echo '<section class="wrap section"><div class="empty"><h3>Sahifa topilmadi</h3><a class="btn-cta" href="' . BASE_URL . '/">Bosh sahifaga &rarr;</a></div></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

if (empty($_SESSION['viewed'][$post['id']])) {
    increment_views((int)$post['id']);
    $_SESSION['viewed'][$post['id']] = 1;
    $post['views']++;
}
$img = post_image_url($post['image']);

$related = [];
if (!empty($post['category_id'])) {
    $related = get_related_posts((int)$post['category_id'], (int)$post['id'], 3);
}

$meta_title = $post['title'] . ' — ' . setting('site_name', 'PMM');
$meta_desc  = make_excerpt($post, 180);
if (!empty($post['cat_slug'])) $active_url = category_url(['slug' => $post['cat_slug']]);
require __DIR__ . '/includes/header.php';
?>

<div class="wrap">
  <div class="breadcrumb on-light">
    <a href="<?= BASE_URL ?>/">Bosh sahifa</a>
    <?php if (!empty($post['cat'])): ?>
      <span>/</span><a href="<?= category_url(['slug'=>$post['cat_slug'],'name'=>$post['cat']]) ?>"><?= h($post['cat']) ?></a>
    <?php endif; ?>
    <span>/</span><span><?= h($post['title']) ?></span>
  </div>
</div>

<article class="wrap article">
  <?php if ($img): ?><div class="hero-img"><img src="<?= h($img) ?>" alt="<?= h($post['title']) ?>"></div><?php endif; ?>
  <div class="inner">
    <?php if (!empty($post['cat'])): ?><div class="eyebrow"><?= h($post['cat']) ?></div><?php endif; ?>
    <h1><?= h($post['title']) ?></h1>
    <div class="meta">
      <span>
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
        <?= uzdate($post['created_at']) ?>
      </span>
      <span>
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
        <?= (int)$post['views'] ?> marta o'qildi
      </span>
    </div>
    <div class="content"><?= safe_html($post['content']) ?></div>

    <?php if (!empty($post['excerpt'])): ?>
      <div class="content-abstract"><strong>Qisqacha:</strong> <?= h($post['excerpt']) ?></div>
    <?php endif; ?>

    <a class="btn-cta back" href="<?= BASE_URL ?>/">&larr; Barcha yangiliklar</a>
  </div>
</article>

<?php if ($related): ?>
<section class="wrap section">
  <div class="sec-head"><div><div class="eyebrow">Shuningdek</div><h2>O'xshash yangiliklar</h2></div></div>
  <div class="grid">
    <?php foreach ($related as $p): $ri = post_image_url($p['image']); ?>
      <a class="card reveal" href="<?= post_url($p) ?>">
        <div class="thumb">
          <?php if ($ri): ?><img src="<?= h($ri) ?>" alt="<?= h($p['title']) ?>" loading="lazy"><?php else: ?><div class="noimg">PMM</div><?php endif; ?>
          <?php if (!empty($p['cat'])): ?><span class="badge"><?= h($p['cat']) ?></span><?php endif; ?>
        </div>
        <div class="body">
          <div class="date"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg><?= uzdate($p['created_at']) ?></div>
          <h3><?= h($p['title']) ?></h3>
          <span class="readmore">Batafsil &rarr;</span>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
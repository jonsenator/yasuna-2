<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/conferences.php';
conferences_ensure_table();

$id = (int)($_GET['id'] ?? 0);
$row = [
    'id'=>0,'title'=>'','type'=>'respublika','year'=>date('Y'),
    'event_date'=>'','date_text'=>'','location'=>'','participants'=>0,
    'countries'=>0,'tags'=>'','short_code'=>'','description'=>'',
    'pdf_url'=>'','link_url'=>'','image'=>'','sort_order'=>0,'active'=>1,
];
if ($id) { $found = get_conference($id); if ($found) $row = $found; }
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $title = trim($_POST['title'] ?? '');
    $type  = ($_POST['type'] ?? '') === 'xalqaro' ? 'xalqaro' : 'respublika';
    $year  = (int)($_POST['year'] ?? 0) ?: null;
    $event_date = trim($_POST['event_date'] ?? '') ?: null;
    $date_text = trim($_POST['date_text'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $participants = max(0, (int)($_POST['participants'] ?? 0));
    $countries = max(0, (int)($_POST['countries'] ?? 0));
    $tags = trim($_POST['tags'] ?? '');
    $short_code = mb_strtoupper(trim($_POST['short_code'] ?? ''));
    $description = trim($_POST['description'] ?? '');
    $pdf_url = trim($_POST['pdf_url'] ?? '');
    $link_url = trim($_POST['link_url'] ?? '');
    $image = trim($_POST['image'] ?? '');
    $sort_order = (int)($_POST['sort_order'] ?? 0);
    $active = !empty($_POST['active']) ? 1 : 0;
    if ($title === '') $errors[] = 'Sarlavha majburiy';
    if (!$errors) {
        if ($id) {
            db()->prepare("UPDATE conferences SET title=?, type=?, year=?, event_date=?, date_text=?, location=?, participants=?, countries=?, tags=?, short_code=?, description=?, pdf_url=?, link_url=?, image=?, sort_order=?, active=? WHERE id=?")
               ->execute([$title,$type,$year,$event_date,$date_text,$location,$participants,$countries,$tags,$short_code,$description,$pdf_url,$link_url,$image,$sort_order,$active,$id]);
            flash_set('Konferensiya yangilandi');
        } else {
            db()->prepare("INSERT INTO conferences (title,type,year,event_date,date_text,location,participants,countries,tags,short_code,description,pdf_url,link_url,image,sort_order,active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$title,$type,$year,$event_date,$date_text,$location,$participants,$countries,$tags,$short_code,$description,$pdf_url,$link_url,$image,$sort_order,$active]);
            flash_set('Konferensiya qo\'shildi');
        }
        redirect('conferences.php');
    }
    $row = array_merge($row, compact('title','type','year','event_date','date_text','location','participants','countries','tags','short_code','description','pdf_url','link_url','image','sort_order','active'));
}

$active = 'conferences';
$page_title = $id ? 'Konferensiyani tahrirlash' : 'Yangi konferensiya';
require __DIR__ . '/includes/header.php';
?>
<?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>
<div class="card" style="max-width:780px">
  <form method="post">
    <?= csrf_field() ?>
    <label>Sarlavha *</label>
    <input type="text" name="title" value="<?= h($row['title']) ?>" required>
    <label>Turi</label>
    <select name="type">
      <option value="respublika" <?= $row['type']==='respublika'?'selected':'' ?>>Respublika</option>
      <option value="xalqaro" <?= $row['type']==='xalqaro'?'selected':'' ?>>Xalqaro</option>
    </select>
    <label>Yil</label>
    <input type="number" name="year" value="<?= h($row['year'] ?: '') ?>">
    <label>Sana (matn)</label>
    <input type="text" name="date_text" value="<?= h($row['date_text']) ?>" placeholder="22-noyabr">
    <label>Sana (kalendar)</label>
    <input type="date" name="event_date" value="<?= h($row['event_date'] ?: '') ?>">
    <label>Joy</label>
    <input type="text" name="location" value="<?= h($row['location']) ?>">
    <label>Ishtirokchilar</label>
    <input type="number" name="participants" value="<?= (int)$row['participants'] ?>">
    <label>Davlatlar soni</label>
    <input type="number" name="countries" value="<?= (int)$row['countries'] ?>">
    <label>Qisqa kod</label>
    <input type="text" name="short_code" value="<?= h($row['short_code']) ?>" placeholder="XAL">
    <label>Teglar</label>
    <input type="text" name="tags" value="<?= h($row['tags']) ?>" placeholder="Pedagogika, Psixologiya">
    <label>PDF havolasi</label>
    <input type="url" name="pdf_url" value="<?= h($row['pdf_url']) ?>">
    <label>Batafsil havola</label>
    <input type="url" name="link_url" value="<?= h($row['link_url']) ?>">
    <label><input type="checkbox" name="active" value="1" <?= !empty($row['active'])?'checked':'' ?>> Faol</label>
    <div class="actions">
      <button class="btn" type="submit">Saqlash</button>
      <a href="conferences.php" class="btn gray">Bekor</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
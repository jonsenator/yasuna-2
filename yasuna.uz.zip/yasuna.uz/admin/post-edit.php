<?php
require_once __DIR__ . '/auth.php';

$id = (int)($_GET['id'] ?? 0);
$post = ['id'=>0,'title'=>'','category_id'=>'','excerpt'=>'','content'=>'','image'=>'','status'=>'published'];
if ($id) {
    $st = db()->prepare('SELECT * FROM posts WHERE id = ?');
    $st->execute([$id]);
    $post = $st->fetch() ?: $post;
}

$cats = db()->query('SELECT id, name FROM categories ORDER BY sort_order, name')->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $title   = trim($_POST['title'] ?? '');
    $catId   = ($_POST['category_id'] ?? '') !== '' ? (int)$_POST['category_id'] : null;
    $excerpt = trim($_POST['excerpt'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $status  = ($_POST['status'] ?? '') === 'draft' ? 'draft' : 'published';
    $image   = $post['image'];

    if ($title === '') $errors[] = 'Sarlavha kiritilmagan';

    // Rasmni olib tashlash
    if (!empty($_POST['remove_image']) && $image) {
        delete_upload($image);
        $image = null;
    }

    // Rasm yuklash
    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        [$ok, $res] = upload_image($_FILES['image']);
        if ($ok) { if ($image) delete_upload($image); $image = $res; }
        else $errors[] = $res;
    }

    if (!$errors) {
        if ($id) {
            db()->prepare('UPDATE posts SET title=?, category_id=?, excerpt=?, content=?, image=?, status=? WHERE id=?')
               ->execute([$title, $catId, $excerpt, $content, $image, $status, $id]);
            flash_set('Yangilik yangilandi');
        } else {
            $slug = slugify($title) . '-' . substr(md5($title . microtime()), 0, 5);
            db()->prepare('INSERT INTO posts (title, slug, category_id, excerpt, content, image, status, author_id) VALUES (?,?,?,?,?,?,?,?)')
               ->execute([$title, $slug, $catId, $excerpt, $content, $image, $status, $_SESSION['user_id']]);
            flash_set('Yangilik qo\'shildi');
        }
        redirect('posts.php');
    }
    $post = array_merge($post, ['title'=>$title,'category_id'=>$catId,'excerpt'=>$excerpt,'content'=>$content,'status'=>$status,'image'=>$image]);
}

$active = 'posts';
$page_title = $id ? 'Yangilikni tahrirlash' : 'Yangi yangilik';
require __DIR__ . '/includes/header.php';
?>
<?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>

<div class="card" style="max-width:860px">
  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <label>Sarlavha *</label>
    <input type="text" name="title" value="<?= h($post['title']) ?>" required>

    <div class="f2">
      <div>
        <label>Kategoriya</label>
        <select name="category_id">
          <option value="">— Tanlanmagan —</option>
          <?php foreach ($cats as $c): ?>
            <option value="<?= $c['id'] ?>" <?= (string)$post['category_id']===(string)$c['id']?'selected':'' ?>><?= h($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Holat</label>
        <select name="status">
          <option value="published" <?= $post['status']==='published'?'selected':'' ?>>E'lon qilingan</option>
          <option value="draft" <?= $post['status']==='draft'?'selected':'' ?>>Qoralama</option>
        </select>
      </div>
    </div>

    <label>Qisqacha tavsif (excerpt)</label>
    <textarea name="excerpt" rows="2" maxlength="600"><?= h($post['excerpt']) ?></textarea>

    <label>To'liq matn</label>
    <textarea name="content" id="content" rows="16" class="editor"><?= h($post['content']) ?></textarea>
    <p class="wys-tip">
      💡 Matnni to'g'ridan-to'g'ri yozing yoki Word/saytdan nusxalab qo'ying — format avtomatik tozalanadi.
      <b>HTML kodi</b> tugmasi orqali kodni qo'lda ham tahrirlashingiz mumkin.
    </p>

    <label>Asosiy rasm</label>
    <?php if ($post['image']): ?>
      <div class="prev-img"><img src="<?= UPLOAD_URL . h($post['image']) ?>" alt=""></div>
      <label style="display:flex;align-items:center;gap:8px;margin:6px 0 10px;font-weight:500">
        <input type="checkbox" name="remove_image" value="1" style="width:auto"> Rasmni o'chirish (saqlaganda)
      </label>
    <?php endif; ?>
    <input type="file" name="image" accept="image/*">

    <div class="actions">
      <button class="btn" type="submit">Saqlash</button>
      <a href="posts.php" class="btn gray">Bekor qilish</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
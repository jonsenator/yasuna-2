<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';
require_once __DIR__ . '/../includes/cardsedit.php';

$pid = (int)($_GET['page'] ?? 0);

// ---- Saqlash ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $pid = (int)($_POST['page_id'] ?? 0);
    $st = db()->prepare('SELECT * FROM pages WHERE id=?');
    $st->execute([$pid]);
    $pg = $st->fetch();
    if ($pg) {
        $groups = [];
        foreach ((array)($_POST['g'] ?? []) as $g) {
            $cards = [];
            foreach ((array)($g['c'] ?? []) as $c) {
                $cards[] = [
                    'nm'    => mb_substr(trim((string)($c['nm'] ?? '')), 0, 200),
                    'pos'   => mb_substr(trim((string)($c['pos'] ?? '')), 0, 200),
                    'phone' => mb_substr(trim((string)($c['phone'] ?? '')), 0, 60),
                    'email' => mb_substr(trim((string)($c['email'] ?? '')), 0, 120),
                    'extra' => mb_substr(trim((string)($c['extra'] ?? '')), 0, 300),
                    'about' => mb_substr(trim((string)($c['about'] ?? '')), 0, 3000),
                    'photo' => (function ($v) {
                        $v = trim((string)$v);
                        if ($v === '') return '';
                        if (preg_match('~^https?://~i', $v)) return valid_image_url($v) ?? '';
                        return valid_library_image($v) ?? '';
                    })($c['photo'] ?? ''),
                ];
            }
            $groups[] = ['title' => mb_substr(trim((string)($g['title'] ?? '')), 0, 200), 'cards' => $cards];
        }
        save_setting('cards_backup_page_' . $pid, (string)$pg['content']);   // zaxira
        $new = cards_write((string)$pg['content'], $groups);

        // Mudir / rahbar kartochkasi
        $pp = (array)($_POST['p'] ?? []);
        if ($pp) {
            $new = person_write($new, [
                'nm'    => !empty($pp['remove']) ? '' : mb_substr(trim((string)($pp['nm'] ?? '')), 0, 200),
                'pos'   => mb_substr(trim((string)($pp['pos'] ?? '')), 0, 200),
                'phone' => mb_substr(trim((string)($pp['phone'] ?? '')), 0, 60),
                'email' => mb_substr(trim((string)($pp['email'] ?? '')), 0, 120),
                'time'  => mb_substr(trim((string)($pp['time'] ?? '')), 0, 40),
                'bio'   => mb_substr(trim((string)($pp['bio'] ?? '')), 0, 4000),
                'photo' => (function ($v) {
                    $v = trim((string)$v);
                    if ($v === '') return '';
                    if (preg_match('~^https?://~i', $v)) return valid_image_url($v) ?? '';
                    return valid_library_image($v) ?? '';
                })($pp['photo'] ?? ''),
            ]);
        }
        db()->prepare('UPDATE pages SET content=? WHERE id=?')->execute([$new, $pid]);
        flash_set('Kartalar saqlandi');
    }
    redirect('cards.php?page=' . $pid);
}

// ---- Zaxiradan qaytarish ----
if (isset($_GET['undo'], $_GET['csrf']) && hash_equals(csrf_token(), (string)$_GET['csrf'])) {
    $b = setting('cards_backup_page_' . $pid);
    if ($b !== '') {
        db()->prepare('UPDATE pages SET content=? WHERE id=?')->execute([$b, $pid]);
        db()->prepare('DELETE FROM settings WHERE skey=?')->execute(['cards_backup_page_' . $pid]);
        flash_set('Oxirgi o\'zgarish bekor qilindi');
    }
    redirect('cards.php?page=' . $pid);
}

$pages = db()->query("SELECT id, title, slug, (content LIKE '%pmm-staff%') AS has_cards FROM pages ORDER BY has_cards DESC, title")->fetchAll();
$pg = null;
if ($pid) {
    $st = db()->prepare('SELECT * FROM pages WHERE id=?');
    $st->execute([$pid]);
    $pg = $st->fetch() ?: null;
}
$groups = $pg ? cards_read((string)$pg['content']) : [];
$person = $pg ? person_read((string)$pg['content']) : [];
$hasBackup = $pg && setting('cards_backup_page_' . $pid) !== '';

$active = 'cards';
$page_title = 'Kartalar';
require __DIR__ . '/includes/header.php';

// Bitta karta qatori (PHP va JS shablon uchun umumiy)
function card_row(string $gi, string $ci, array $c = []): string {
    $v = fn($k) => h($c[$k] ?? '');
    return '
    <div class="cd-card">
      <div class="cd-photo" data-photo>
        <img data-el="prev" src="' . ($v('photo') !== '' ? h(preg_match('~^https?://~i', (string)($c['photo'] ?? '')) ? $c['photo'] : UPLOAD_URL . rawurlencode((string)$c['photo'])) : '') . '" alt="" ' . ($v('photo') !== '' ? '' : 'hidden') . '>
        <span data-el="empty" ' . ($v('photo') !== '' ? 'hidden' : '') . '>NO<br>FOTO</span>
        <input type="hidden" name="g[' . $gi . '][c][' . $ci . '][photo]" value="' . $v('photo') . '" data-el="val">
        <div class="cd-pbtns">
          <button type="button" data-p="file" title="Kompyuterdan yuklash">💻</button>
          <button type="button" data-p="lib" title="Saytdagi rasmlardan">🖼</button>
          <button type="button" data-p="url" title="Havola (URL)">🔗</button>
          <button type="button" data-p="del" title="Rasmni olib tashlash">✕</button>
        </div>
      </div>
      <div class="cd-handle">
        <span class="cd-num"></span>
        <button type="button" data-act="up" title="Yuqoriga">↑</button>
        <button type="button" data-act="down" title="Pastga">↓</button>
      </div>
      <div class="cd-fields">
        <div class="cd-row2">
          <input type="text" name="g[' . $gi . '][c][' . $ci . '][nm]" value="' . $v('nm') . '" placeholder="F.I.Sh. yoki nomi *" class="cd-nm">
          <input type="text" name="g[' . $gi . '][c][' . $ci . '][pos]" value="' . $v('pos') . '" placeholder="Lavozimi (Dotsent, O\'qituvchi …)">
        </div>
        <div class="cd-row3">
          <input type="text" name="g[' . $gi . '][c][' . $ci . '][phone]" value="' . $v('phone') . '" placeholder="📞 Telefon">
          <input type="text" name="g[' . $gi . '][c][' . $ci . '][email]" value="' . $v('email') . '" placeholder="✉ Email">
          <input type="text" name="g[' . $gi . '][c][' . $ci . '][extra]" value="' . $v('extra') . '" placeholder="Qo\'shimcha (ixtiyoriy)">
        </div>
        <textarea name="g[' . $gi . '][c][' . $ci . '][about]" rows="2" class="cd-about"
                  placeholder="Ma\'lumot — saytda kartaning o\'ng tomonida chiqadi (ilmiy daraja, mehnat staji, yutuqlari …)">' . $v('about') . '</textarea>
      </div>
      <button type="button" class="cd-del" data-act="del" title="Kartani o\'chirish">✕</button>
    </div>';
}
?>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<div class="bar">
  <form method="get" class="bar-left cd-pick">
    <label for="pgsel">Sahifa:</label>
    <select name="page" id="pgsel" onchange="this.form.submit()">
      <option value="">— Sahifani tanlang —</option>
      <?php foreach ($pages as $p): ?>
        <option value="<?= (int)$p['id'] ?>" <?= $pid === (int)$p['id'] ? 'selected' : '' ?>><?= $p['has_cards'] ? '▦ ' : '' ?><?= h($p['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
  <?php if ($pg): ?>
  <div class="bar-right">
    <?php if ($hasBackup): ?>
      <a class="btn sm gray" href="cards.php?page=<?= $pid ?>&undo=1&csrf=<?= csrf_token() ?>" onclick="return confirm('Oxirgi saqlashdan oldingi holatga qaytarilsinmi?')">↶ Oxirgi o'zgarishni bekor qilish</a>
    <?php endif; ?>
    <a class="btn sm gray" href="<?= page_url($pg) ?>" target="_blank">Saytda ko'rish ↗</a>
  </div>
  <?php endif; ?>
</div>

<?php if (!$pg): ?>
  <p class="hint">💡 Yuqoridan sahifani tanlang. <b>▦</b> belgisi bor sahifalarda kartalar mavjud. Kartasi yo'q sahifaga ham yangi guruh qo'shish mumkin.</p>
<?php else: ?>
  <p class="hint">
    💡 Keraksiz kartani <b>✕</b> bilan o'chiring, yangisini <b>«+ Karta qo'shish»</b> bilan yarating, tartibni <b>↑ ↓</b> bilan o'zgartiring.
    Oxirida <b>«Saqlash»</b> ni bosing. Sahifaning boshqa qismlari (banner, mudir kartochkasi, matnlar) o'zgarmaydi.
  </p>

  <form method="post" id="cdForm">
    <?= csrf_field() ?>
    <input type="hidden" name="page_id" value="<?= $pid ?>">
    <?php if ($pg): ?>
    <section class="card cd-person">
      <div class="cd-ghead">
        <h3 class="cd-ptitle">👤 Rahbar kartochkasi <small>(kafedra mudiri / bo'lim boshlig'i — sahifa tepasida katta kartochka)</small></h3>
      </div>
      <div class="cd-pgrid">
        <div class="cd-photo cd-pphoto" data-photo>
          <img data-el="prev" src="<?= $person['photo'] ?? '' ? h(preg_match('~^https?://~i', (string)$person['photo']) ? $person['photo'] : UPLOAD_URL . rawurlencode((string)$person['photo'])) : '' ?>" alt="" <?= !empty($person['photo']) ? '' : 'hidden' ?>>
          <span data-el="empty" <?= !empty($person['photo']) ? 'hidden' : '' ?>>NO<br>FOTO</span>
          <input type="hidden" name="p[photo]" value="<?= h($person['photo'] ?? '') ?>" data-el="val">
          <div class="cd-pbtns">
            <button type="button" data-p="file" title="Kompyuterdan yuklash">💻</button>
            <button type="button" data-p="lib" title="Saytdagi rasmlardan">🖼</button>
            <button type="button" data-p="url" title="Havola (URL)">🔗</button>
            <button type="button" data-p="del" title="Rasmni olib tashlash">✕</button>
          </div>
        </div>
        <div class="cd-pfields">
          <div class="cd-row2">
            <input type="text" name="p[nm]" value="<?= h($person['nm'] ?? '') ?>" placeholder="F.I.Sh. (bo'sh qoldirilsa kartochka o'chadi)" class="cd-nm">
            <input type="text" name="p[pos]" value="<?= h($person['pos'] ?? '') ?>" placeholder="Lavozimi (Kafedra mudiri)">
          </div>
          <div class="cd-row3">
            <input type="text" name="p[phone]" value="<?= h($person['phone'] ?? '') ?>" placeholder="📞 Telefon">
            <input type="text" name="p[email]" value="<?= h($person['email'] ?? '') ?>" placeholder="✉ Email">
            <input type="text" name="p[time]" value="<?= h($person['time'] ?? '') ?>" placeholder="🕐 Ish vaqti (8:30 – 16:30)">
          </div>
          <textarea name="p[bio]" rows="4" class="cd-about" placeholder="Ma'lumot — mehnat staji, ilmiy darajasi, yutuqlari. Har bir xatboshini yangi qatordan yozing."><?= h($person['bio'] ?? '') ?></textarea>
          <?php if (!empty($person['exists'])): ?>
            <label class="ld-check"><input type="checkbox" name="p[remove]" value="1"> Bu kartochkani butunlay o'chirish</label>
          <?php endif; ?>
        </div>
      </div>
    </section>
    <?php endif; ?>

    <div id="cdGroups">
      <?php foreach ($groups as $gi => $g): ?>
        <section class="card cd-group" data-gi="<?= $gi ?>">
          <div class="cd-ghead">
            <input type="text" name="g[<?= $gi ?>][title]" value="<?= h($g['title']) ?>" placeholder="Guruh sarlavhasi (masalan: Kafedra professor-o'qituvchilari)" class="cd-gtitle">
            <span class="cd-count"></span>
            <button type="button" class="btn sm red" data-act="delgroup">Guruhni o'chirish</button>
          </div>
          <div class="cd-cards">
            <?php foreach ($g['cards'] as $ci => $c) echo card_row((string)$gi, (string)$ci, $c); ?>
          </div>
          <button type="button" class="btn sm cd-add" data-act="add">+ Karta qo'shish</button>
        </section>
      <?php endforeach; ?>
    </div>

    <div class="cd-bottom">
      <button type="button" class="btn gray" id="addGroup">+ Yangi guruh qo'shish</button>
      <button type="submit" class="btn cd-save">Saqlash</button>
    </div>
  </form>

  <template id="tplCard"><?= card_row('__G__', '__C__') ?></template>
  <template id="tplGroup">
    <section class="card cd-group" data-gi="__G__">
      <div class="cd-ghead">
        <input type="text" name="g[__G__][title]" placeholder="Guruh sarlavhasi" class="cd-gtitle">
        <span class="cd-count"></span>
        <button type="button" class="btn sm red" data-act="delgroup">Guruhni o'chirish</button>
      </div>
      <div class="cd-cards"></div>
      <button type="button" class="btn sm cd-add" data-act="add">+ Karta qo'shish</button>
    </section>
  </template>

  <script src="<?= BASE_URL ?>/assets/js/media-picker.js?v=1"></script>
  <script>window.MEDIA_URL = 'media.php';</script>
  <script>
  (function () {
    var wrap = document.getElementById('cdGroups'), seq = Date.now(), dirty = false;
    function uid() { return 'n' + (seq++); }
    function renumber() {
      wrap.querySelectorAll('.cd-group').forEach(function (g) {
        var cards = g.querySelectorAll('.cd-card');
        cards.forEach(function (c, i) { c.querySelector('.cd-num').textContent = ('0' + (i + 1)).slice(-2); });
        g.querySelector('.cd-count').textContent = cards.length + ' ta karta';
      });
    }
    function addCard(group, focus) {
      var gi = group.dataset.gi;
      var html = document.getElementById('tplCard').innerHTML.split('__G__').join(gi).split('__C__').join(uid());
      var box = group.querySelector('.cd-cards');
      box.insertAdjacentHTML('beforeend', html);
      var card = box.lastElementChild;
      card.classList.add('is-new');
      if (focus) card.querySelector('.cd-nm').focus();
      renumber(); dirty = true;
    }
    wrap.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      var group = b.closest('.cd-group'), card = b.closest('.cd-card');
      switch (b.dataset.act) {
        case 'add': addCard(group, true); break;
        case 'del':
          var nm = card.querySelector('.cd-nm').value.trim();
          if (!nm || confirm('«' + nm + '» kartasi o‘chirilsinmi?')) { card.remove(); renumber(); dirty = true; }
          break;
        case 'up':   if (card.previousElementSibling) { card.parentNode.insertBefore(card, card.previousElementSibling); renumber(); dirty = true; } break;
        case 'down': if (card.nextElementSibling) { card.parentNode.insertBefore(card.nextElementSibling, card); renumber(); dirty = true; } break;
        case 'delgroup':
          if (confirm('Butun guruh va undagi barcha kartalar o‘chirilsinmi?')) { group.remove(); dirty = true; }
          break;
      }
    });
    // ---- Rasm tugmalari ----
    var fileInput = document.createElement('input');
    fileInput.type = 'file'; fileInput.accept = 'image/*'; fileInput.hidden = true;
    document.body.appendChild(fileInput);
    var target = null;
    function setPhoto(box, val, url) {
      box.querySelector('[data-el=val]').value = val;
      var img = box.querySelector('[data-el=prev]'), em = box.querySelector('[data-el=empty]');
      if (val) { img.src = url; img.hidden = false; em.hidden = true; }
      else { img.removeAttribute('src'); img.hidden = true; em.hidden = false; }
      dirty = true;
    }
    fileInput.addEventListener('change', function () {
      if (!fileInput.files[0] || !target) return;
      var box = target, fd = new FormData();
      fd.append('file', fileInput.files[0]);
      fd.append('csrf', document.querySelector('#cdForm input[name=csrf]').value);
      box.classList.add('is-loading');
      fetch('upload.php', {method: 'POST', body: fd, credentials: 'same-origin'})
        .then(function (r) { return r.json(); })
        .then(function (d) {
          box.classList.remove('is-loading');
          if (d.ok) setPhoto(box, d.name, d.url); else alert(d.error || 'Yuklab bo\u2018lmadi');
        })
        .catch(function () { box.classList.remove('is-loading'); alert('Yuklashda xatolik'); });
      fileInput.value = '';
    });
    document.getElementById('cdForm').addEventListener('click', function (e) {
      var b = e.target.closest('[data-p]'); if (!b) return;
      var box = b.closest('[data-photo]');
      if (b.dataset.p === 'file') { target = box; fileInput.click(); }
      if (b.dataset.p === 'lib')  MediaPicker.open(function (it) { setPhoto(box, it.name, it.url); });
      if (b.dataset.p === 'url') {
        var v = (prompt('Rasm havolasini (URL) kiriting:', box.querySelector('[data-el=val]').value) || '').trim();
        if (v && /^https?:\/\//i.test(v)) setPhoto(box, v, v);
        else if (v) alert('Havola http:// yoki https:// bilan boshlanishi kerak');
      }
      if (b.dataset.p === 'del') setPhoto(box, '', '');
    });
    wrap.addEventListener('input', function () { dirty = true; });
    document.getElementById('addGroup').addEventListener('click', function () {
      var html = document.getElementById('tplGroup').innerHTML.split('__G__').join(uid());
      wrap.insertAdjacentHTML('beforeend', html);
      var g = wrap.lastElementChild;
      addCard(g, false);
      g.querySelector('.cd-gtitle').focus();
      g.scrollIntoView({behavior: 'smooth', block: 'center'});
    });
    document.getElementById('cdForm').addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
    renumber();
  })();
  </script>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
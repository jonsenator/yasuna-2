<?php
require_once __DIR__ . '/auth.php';

// Saqlash (qo'shish/tahrirlash)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    csrf_check();
    $mid       = (int)($_POST['id'] ?? 0);
    $title     = trim($_POST['title'] ?? '');
    $type      = in_array($_POST['type'] ?? '', ['category','page','custom'], true) ? $_POST['type'] : 'category';
    $ref_id    = ($_POST['ref_id'] ?? '') !== '' ? (int)$_POST['ref_id'] : null;
    $url       = trim($_POST['url'] ?? '');
    $parent    = ($_POST['parent_id'] ?? '') !== '' ? (int)$_POST['parent_id'] : null;
    $order     = (int)($_POST['sort_order'] ?? 0);
    $active    = isset($_POST['active']) ? 1 : 0;
    $clickable = isset($_POST['clickable']) ? 0 : 1; // "Bosilmaydigan" belgilangan bo'lsa 0

    if ($title !== '') {
        // "Bo'lim" turi tanlansa — yangiliklar biriktiriladigan kategoriya
        // avtomatik yaratiladi yoki mavjudining nomi menyu nomiga moslanadi.
        if ($type === 'category') {
            $existingCatId = null;
            if ($mid) {
                $st = db()->prepare('SELECT type, ref_id FROM menus WHERE id=?');
                $st->execute([$mid]);
                $old = $st->fetch();
                if ($old && $old['type'] === 'category' && $old['ref_id']) $existingCatId = (int)$old['ref_id'];
            }
            if ($existingCatId) {
                // Slug o'zgarmaydi (eski havolalar buzilmasin) — faqat nomi va tartibi yangilanadi
                db()->prepare('UPDATE categories SET name=?, sort_order=? WHERE id=?')
                   ->execute([$title, $order, $existingCatId]);
                $ref_id = $existingCatId;
            } else {
                $slug = slugify($title);
                $chk  = db()->prepare('SELECT COUNT(*) FROM categories WHERE slug=?');
                $chk->execute([$slug]);
                if ($chk->fetchColumn() > 0) $slug .= '-' . substr(md5(microtime()), 0, 4);
                db()->prepare('INSERT INTO categories (name, slug, sort_order) VALUES (?,?,?)')
                   ->execute([$title, $slug, $order]);
                $ref_id = (int)db()->lastInsertId();
            }
            $url = null; // bo'lim uchun maxsus URL kerak emas
        }

        if ($mid) {
            db()->prepare('UPDATE menus SET title=?, type=?, ref_id=?, url=?, clickable=?, parent_id=?, sort_order=?, active=? WHERE id=?')
               ->execute([$title, $type, $ref_id, $url, $clickable, $parent, $order, $active, $mid]);
            flash_set('Menyu yangilandi');
        } else {
            db()->prepare('INSERT INTO menus (title, type, ref_id, url, clickable, parent_id, sort_order, active) VALUES (?,?,?,?,?,?,?,?)')
               ->execute([$title, $type, $ref_id, $url, $clickable, $parent, $order, $active]);
            flash_set('Menyu qo\'shildi');
        }
    }
    redirect('menus.php');
}

// O'chirish
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    $did = (int)$_POST['delete_id'];

    // O'chirilayotgan menyu "bo'lim" bo'lsa — bog'langan kategoriyani ham topamiz
    $st = db()->prepare('SELECT type, ref_id FROM menus WHERE id=?');
    $st->execute([$did]);
    $row = $st->fetch();

    db()->prepare('UPDATE menus SET parent_id=NULL WHERE parent_id=?')->execute([$did]);
    db()->prepare('DELETE FROM menus WHERE id=?')->execute([$did]);

    // Bo'lim o'chsa — kategoriya ham o'chadi. Yangiliklar O'CHMAYDI, faqat
    // kategoriyasiz (— Tanlanmagan —) bo'lib qoladi.
    if ($row && $row['type'] === 'category' && $row['ref_id']) {
        $cid = (int)$row['ref_id'];
        db()->prepare('UPDATE posts SET category_id=NULL WHERE category_id=?')->execute([$cid]);
        db()->prepare('UPDATE categories SET parent_id=NULL WHERE parent_id=?')->execute([$cid]);
        db()->prepare('DELETE FROM categories WHERE id=?')->execute([$cid]);
    }
    flash_set('Menyu o\'chirildi');
    redirect('menus.php');
}

$editId   = (int)($_GET['edit'] ?? 0);
$addUnder = (int)($_GET['add'] ?? 0); // ?add=PARENT_ID => shu menyu ichiga ichki menyu qo'shish
$edit = ['id'=>0,'title'=>'','type'=>'category','ref_id'=>'','url'=>'','parent_id'=>($addUnder?$addUnder:''),'sort_order'=>0,'active'=>1,'clickable'=>1];
if ($editId) {
    $st = db()->prepare('SELECT * FROM menus WHERE id=?');
    $st->execute([$editId]);
    $edit = $st->fetch() ?: $edit;
}

$menu_rows = db()->query('SELECT * FROM menus ORDER BY sort_order, id')->fetchAll();
$pages = db()->query("SELECT id,title FROM pages ORDER BY title")->fetchAll();

// ierarxiya — istalgan chuqurlikda (2, 3 va undan ko'p daraja)
$byId = [];
foreach ($menu_rows as $r) {
    $r['type_label'] = ['category'=>'Bo\'lim','page'=>'Sahifa','custom'=>'Havola'][$r['type']] ?? $r['type'];
    $r['kids'] = [];
    $byId[(int)$r['id']] = $r;
}
$tree = [];
foreach ($byId as $id => $_) {
    $pid = $byId[$id]['parent_id'] === null ? null : (int)$byId[$id]['parent_id'];
    if ($pid !== null && isset($byId[$pid])) $byId[$pid]['kids'][] =& $byId[$id];
    else $tree[] =& $byId[$id];
}
unset($_);

// "Ota element" ro'yxati uchun tekis ro'yxat (chuqurlik belgisi bilan)
$flat = [];
$walk = function ($items, $depth = 0) use (&$walk, &$flat) {
    foreach ($items as $it) {
        $flat[] = ['id'=>(int)$it['id'], 'title'=>$it['title'], 'depth'=>$depth];
        if (!empty($it['kids'])) $walk($it['kids'], $depth + 1);
    }
};
$walk($tree);

// O'zini va o'z avlodlarini "ota" sifatida tanlab bo'lmaydi (halqa oldini olish)
$blocked = [];
if (!empty($edit['id'])) {
    $collect = function ($id) use (&$collect, &$byId, &$blocked) {
        $blocked[$id] = 1;
        if (!empty($byId[$id]['kids'])) foreach ($byId[$id]['kids'] as $k) $collect((int)$k['id']);
    };
    $collect((int)$edit['id']);
}

$topLevel = $tree; // eski nom bilan moslik

$active = 'menus';
$page_title = 'Menyular';
require __DIR__ . '/includes/header.php';
?>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<p class="hint">
  💡 <strong>Bir menyu = bir bo'lim.</strong> Turi <span class="tag">Bo'lim</span> bo'lgan menyu ochsangiz, yangiliklarni
  (Yangiliklar bo'limidan) o'sha menyuga biriktirasiz — bosilganda shu bo'lim sahifasi ochiladi.
  <br>💡 <strong>Ichki menyu (dropdown):</strong> ota menyu qatoridagi <span class="tag gold">Ichki menyu</span> tugmasini bosing —
  forma avtomatik o'sha menyu ichiga bog'lanadi. Asosiy menyu uchun formadagi <em>«Ota element»</em> ni bo'sh qoldiring.
</p>

<div class="two-col">
  <div class="card">
    <table>
      <tr><th>Nomi</th><th>Turi</th><th>Havola</th><th>Tartib</th><th>Holat</th><th style="width:300px;text-align:right">Amal</th></tr>
      <?php
      // Menyu qatorlarini istalgan chuqurlikda chizadi
      $rowfn = function ($items, $depth = 0) use (&$rowfn) {
          foreach ($items as $m):
              $pad  = $depth * 26;
              $isTop = $depth === 0;
      ?>
      <tr>
        <td style="padding-left:<?= 12 + $pad ?>px">
          <?php if (!$isTop): ?><span style="color:#b6c6bd">&#9492;&nbsp;</span><?php endif; ?>
          <?php if ($isTop): ?><strong><?= h($m['title']) ?></strong><?php else: ?><?= h($m['title']) ?><?php endif; ?>
          <?= isset($m['clickable']) && !(int)$m['clickable'] ? ' <span class="tag gold">Bosilmaydigan</span>' : '' ?>
          <?php if ($depth >= 1 && !empty($m['kids'])): ?> <span class="tag">ichki: <?= count($m['kids']) ?></span><?php endif; ?>
        </td>
        <td><span class="tag"><?= $m['type_label'] ?></span></td>
        <td style="color:#5b6b74;font-size:13px"><?= h($m['url'] ?: ($m['ref_id'] ? 'bo\'lim#'.$m['ref_id'] : '—')) ?></td>
        <td><?= (int)$m['sort_order'] ?></td>
        <td><?= $m['active'] ? '<span class="tag green">Faol</span>' : '<span class="tag gray">O\'chiq</span>' ?></td>
        <td class="acts">
          <div class="row-actions">
            <a href="menus.php?add=<?= (int)$m['id'] ?>" class="btn sm gold" title="Bu menyu ichiga ichki menyu qo'shish">Ichki menyu</a>
            <a href="menus.php?edit=<?= (int)$m['id'] ?>" class="btn sm gray" title="Ushbu menyuni tahrirlash">Tahrirlash</a>
            <form method="post" onsubmit="return confirm('«<?= h(addslashes($m['title'])) ?>» menyusi o\'chirilsinmi?<?= !empty($m['kids']) ? '\n\nDIQQAT: ichida '.count($m['kids']).' ta ichki menyu bor — ular asosiy menyuga ko\\\'chadi.' : '' ?>')">
              <?= csrf_field() ?>
              <input type="hidden" name="delete_id" value="<?= (int)$m['id'] ?>">
              <button class="btn sm red" title="Ushbu menyuni o'chirish">O'chirish</button>
            </form>
          </div>
        </td>
      </tr>
      <?php
              if (!empty($m['kids'])) $rowfn($m['kids'], $depth + 1);
          endforeach;
      };
      $rowfn($tree);
      ?>
      <?php if (!$topLevel): ?><tr><td colspan="6" style="color:#94a3b8">Menyu bo'sh</td></tr><?php endif; ?>
    </table>
  </div>

  <div class="card">
    <h3 style="font-size:16px;margin-bottom:6px"><?= $edit['id'] ? 'Tahrirlash' : ($addUnder ? 'Yangi ichki menyu' : 'Yangi menyu') ?></h3>
    <?php if ($addUnder && $editId===0):
        $parentTitle = '';
        foreach ($flat as $t) if ($t['id']===$addUnder) $parentTitle = $t['title']; ?>
      <div class="flash">Bu menyu <strong>«<?= h($parentTitle) ?>»</strong> ota menyusining <strong>ichiga</strong> qo'shiladi.</div>
    <?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
      <label>Nomi *</label>
      <input type="text" name="title" value="<?= h($edit['title']) ?>" required>

      <label>Turi</label>
      <select name="type" id="mtype">
        <option value="category" <?= $edit['type']==='category'?'selected':'' ?>>Bo'lim (yangiliklar shu yerda chiqadi)</option>
        <option value="page" <?= $edit['type']==='page'?'selected':'' ?>>Statik sahifa</option>
        <option value="custom" <?= $edit['type']==='custom'?'selected':'' ?>>Maxsus havola (URL)</option>
      </select>

      <div class="type-field" id="f-category">
        <p class="hint" style="margin:8px 0 0">
          Bo'lim nomi menyu nomidan olinadi. Saqlaganda avtomatik yaratiladi.
          Yangilik qo'shishda uni <strong>«<?= h($edit['title'] ?: 'shu bo\'lim') ?>»</strong> ga biriktirasiz.
        </p>
      </div>
      <div class="type-field" id="f-page">
        <label>Sahifani tanlang</label>
        <select name="ref_id">
          <option value="">— Tanlang —</option>
          <?php foreach ($pages as $p): ?>
            <option value="<?= $p['id'] ?>" <?= (string)$edit['ref_id']===(string)$p['id']?'selected':'' ?>><?= h($p['title']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="type-field" id="f-custom">
        <label>Havola (URL)</label>
        <input type="text" name="url" value="<?= h($edit['url']) ?>" placeholder="/ yoki /contact.php">
      </div>

      <label>Ota element (dropdown uchun)</label>
      <select name="parent_id">
        <option value="">— Yo'q (asosiy menyu) —</option>
        <?php foreach ($flat as $t): if (isset($blocked[$t['id']])) continue; ?>
          <option value="<?= $t['id'] ?>" <?= (string)$edit['parent_id']===(string)$t['id']?'selected':'' ?>>
            <?= str_repeat('— ', $t['depth']) ?><?= h($t['title']) ?>
          </option>
        <?php endforeach; ?>
      </select>

      <label>Tartib raqami</label>
      <input type="text" name="sort_order" value="<?= (int)$edit['sort_order'] ?>">

      <label style="display:flex;align-items:center;gap:8px;margin-top:12px">
        <input type="checkbox" name="active" <?= $edit['active']?'checked':'' ?> style="width:auto"> Faol (ko'rinadi)
      </label>
      <label style="display:flex;align-items:center;gap:8px;margin-top:10px">
        <input type="checkbox" name="clickable" <?= !$edit['clickable']?'checked':'' ?> style="width:auto"> Bosilmaydigan (faqat ichki menyu ochadi — ota menyu uchun)
      </label>

      <div class="actions">
        <button class="btn" name="save" value="1">Saqlash</button>
        <?php if ($edit['id']): ?><a href="menus.php" class="btn gray">Bekor</a><?php endif; ?>
      </div>
    </form>
  </div>
</div>

<script>
(function(){
  var sel = document.getElementById('mtype');
  function upd(){
    ['f-category','f-page','f-custom'].forEach(function(id){
      document.getElementById(id).style.display = (id === 'f-'+sel.value) ? '' : 'none';
    });
  }
  sel.addEventListener('change', upd);
  upd();
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
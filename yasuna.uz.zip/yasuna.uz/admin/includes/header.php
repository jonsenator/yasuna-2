<?php
require_once __DIR__ . '/../auth.php';
$u = current_user();
$active = $active ?? '';
$page_title = $page_title ?? 'Admin panel';
$unread = (int)db()->query("SELECT COUNT(*) FROM messages WHERE is_read=0")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($page_title) ?> — Admin panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;700;800&family=Public+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="sbrand">
      <span class="dot"></span> yasuna.uz
      <small>Boshqaruv paneli</small>
    </div>
    <nav class="snav">
      <a href="index.php" class="<?= $active==='dashboard'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>Boshqaruv paneli</a>
      <a href="posts.php" class="<?= $active==='posts'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2Z"/><path d="M8 8h8M8 12h8"/></svg>Yangiliklar</a>
      <a href="menus.php" class="<?= $active==='menus'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h10"/></svg>Menyular</a>
      <a href="pages.php" class="<?= $active==='pages'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>Sahifalar</a>
      <a href="leaders.php" class="<?= $active==='leaders'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="9" cy="8" r="4"/><path d="M2 21v-1a7 7 0 0 1 14 0v1"/><path d="M16 3.5a4 4 0 0 1 0 9"/><path d="M22 21v-1a7 7 0 0 0-4-6.3"/></svg>Rahbariyat</a>
      <a href="cards.php" class="<?= $active==='cards'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M17.5 14v7M14 17.5h7"/></svg>Kartalar</a>
      <a href="card-links.php" class="<?= $active==='cardlinks'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>Karta havolalari</a>
      <a href="conferences.php" class="<?= $active==='conferences'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>Konferensiyalar</a>  
        
        
        
      <a href="slider.php" class="<?= $active==='slider'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m8 12 2-2 3 3 2-2 1 1"/></svg>Slayder</a>
      <a href="messages.php" class="<?= $active==='messages'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z"/></svg>Xabarlar
        <?php if ($unread): ?><span class="pill"><?= $unread ?></span><?php endif; ?></a>
      <a href="settings.php" class="<?= $active==='settings'?'active':'' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h.1a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.5 1h.1a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></svg>Sozlamalar</a>
      <a href="<?= BASE_URL ?>" target="_blank" class="ext">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/></svg>Saytni ochish ↗</a>
    </nav>
    <div class="suser">
      <strong><?= h($u['full_name'] ?: $u['username']) ?></strong>
      <a href="logout.php">Chiqish</a>
    </div>
  </aside>
  <div class="main">
    <div class="topbar">
      <h1 class="page"><?= h($page_title) ?></h1>
      <div class="tuser"><?= h($u['full_name'] ?: $u['username']) ?><a href="logout.php">Chiqish</a></div>
    </div>
    <div class="content">
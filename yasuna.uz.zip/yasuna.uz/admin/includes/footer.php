    </div>
  </div>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<script src="<?= BASE_URL ?>/assets/js/editor.js?v=1"></script>
</body>
</html>

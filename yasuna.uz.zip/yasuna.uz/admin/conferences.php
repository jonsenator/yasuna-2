<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/conferences.php';
conferences_ensure_table();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['delete_id'])) {
        $c = get_conference((int)$_POST['delete_id']);
        if ($c) {
            db()->prepare('DELETE FROM conferences WHERE id=?')->execute([(int)$c['id']]);
            flash_set('«' . mb_substr($c['title'], 0, 60) . '» o\'chirildi');
        }
        redirect('conferences.php');
    }
    if (isset($_POST['toggle_id'])) {
        db()->prepare('UPDATE conferences SET active = 1 - active WHERE id=?')->execute([(int)$_POST['toggle_id']]);
        redirect('conferences.php');
    }
    if (isset($_POST['move_id'], $_POST['dir'])) {
        $rows = get_conferences(false);
        $ids  = array_map(fn($r) => (int)$r['id'], $rows);
        $i    = array_search((int)$_POST['move_id'], $ids, true);
        $j    = $_POST['dir'] === 'up' ? $i - 1 : $i + 1;
        if ($i !== false && isset($ids[$j])) {
            [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
            $up = db()->prepare('UPDATE conferences SET sort_order=? WHERE id=?');
            foreach ($ids as $n => $id) $up->execute([$n + 1, $id]);
        }
        redirect('conferences.php');
    }
}

$rows = get_conferences(false);
$stats = conference_stats();
$active = 'conferences';
$page_title = 'Konferensiyalar';
require __DIR__ . '/includes/header.php';
?>
<div class="toolbar">
  <div><strong><?= count($rows) ?></strong> ta konferensiya
    <span class="muted" style="margin-left:10px">(<?= $stats['xalqaro'] ?> xalqaro · <?= $stats['respublika'] ?> respublika)</span>
  </div>
  <a class="btn" href="conference-edit.php">+ Yangi konferensiya</a>
</div>
<?php if (!$rows): ?>
  <div class="card empty-state">
    <h3>Hali konferensiya yo'q</h3>
    <p>Birinchi konferensiyani qo'shing.</p>
    <a class="btn" href="conference-edit.php">+ Qo'shish</a>
  </div>
<?php else: ?>
  <div class="card" style="padding:0;overflow:hidden">
    <table class="table">
      <thead><tr>
        <th>#</th><th>Sarlavha</th><th>Turi</th><th>Yil</th><th>Ishtirok</th><th>Holat</th><th>Amallar</th>
      </tr></thead>
      <tbody>
        <?php foreach ($rows as $i => $r): ?>
          <tr>
            <td class="muted"><?= $i + 1 ?></td>
            <td><strong><?= h(mb_substr($r['title'], 0, 90)) ?></strong></td>
            <td><span class="badge <?= $r['type']==='xalqaro'?'blue':'green' ?>"><?= $r['type']==='xalqaro' ? 'Xalqaro' : 'Respublika' ?></span></td>
            <td><?= $r['year'] ? (int)$r['year'] : '—' ?></td>
            <td><?= (int)$r['participants'] ?: '—' ?></td>
            <td>
              <form method="post" style="display:inline"><?= csrf_field() ?>
                <input type="hidden" name="toggle_id" value="<?= (int)$r['id'] ?>">
                <button type="submit" class="btn-sm <?= $r['active'] ? 'ok' : 'gray' ?>"><?= $r['active'] ? 'Faol' : 'Yashirin' ?></button>
              </form>
            </td>
            <td>
              <a class="btn-sm" href="conference-edit.php?id=<?= (int)$r['id'] ?>">Tahrirlash</a>
              <form method="post" style="display:inline" onsubmit="return confirm('O\'chirish?')">
                <?= csrf_field() ?>
                <input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>">
                <button type="submit" class="btn-sm danger">O'chirish</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';
require_once __DIR__ . '/../includes/leaders.php';
require_once __DIR__ . '/../includes/cardlinks.php';

// ---- Saqlash ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $map = card_links_map();
    foreach ((array)($_POST['rule'] ?? []) as $key => $val) {
        $key = card_key((string)$key);
        if ($key === '') continue;
        $val = (string)$val;
        $url = trim((string)($_POST['url'][$key] ?? ''));

        if ($val === 'auto')                        unset($map[$key]);
        elseif ($val === 'none')                    $map[$key] = ['type' => 'none'];
        elseif (preg_match('~^(page|category|leader):(\d+)$~', $val, $m))
                                                    $map[$key] = ['type' => $m[1], 'id' => (int)$m[2]];
        elseif ($val === 'url') {
            if ($url !== '' && (strpos($url, '/') === 0 || valid_image_url($url))) $map[$key] = ['type' => 'url', 'url' => $url];
            else unset($map[$key]);
        }
    }
    card_links_save($map);
    flash_set('Karta havolalari saqlandi');
    redirect('card-links.php');
}

// ---- Kartalarni yig'ish ----
$pagesWithCards = db()->query("SELECT id, title, slug, content FROM pages WHERE content LIKE '%pmm-staff%' ORDER BY title")->fetchAll();
$allPages   = db()->query("SELECT id, title FROM pages WHERE status='published' ORDER BY title")->fetchAll();
$allCats    = db()->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$leaders    = get_leaders(true);
$map        = card_links_map();

$active = 'cardlinks';
$page_title = 'Karta havolalari';
require __DIR__ . '/includes/header.php';
?>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<p class="hint">
  💡 Sahifalardagi kartalar (masalan «Markaz tuzilmasi») bosilganda qayerga o'tishini shu yerda belgilaysiz.<br>
  <b>Avtomatik</b> — karta nomi menyu bandi, sahifa yoki bo'lim nomiga mos kelsa, havola o'zi qo'yiladi (yashil yozuv bilan ko'rsatilgan).
  Mos kelmasa yoki boshqa joyga olib borish kerak bo'lsa — ro'yxatdan tanlang.
</p>

<?php if (!$pagesWithCards): ?>
  <div class="card"><p style="color:#94a3b8">Kartali sahifa topilmadi.</p></div>
<?php endif; ?>

<form method="post" class="cl-form">
  <?= csrf_field() ?>
  <?php foreach ($pagesWithCards as $pg):
      $cards = extract_staff_cards((string)$pg['content']);
      if (!$cards) continue;
      $group = null; ?>
    <div class="card cl-page">
      <div class="card-head">
        <h3><?= h($pg['title']) ?> <small><?= count($cards) ?> ta karta</small></h3>
        <a href="<?= page_url($pg) ?>" target="_blank" class="btn sm gray">Saytda ko'rish ↗</a>
      </div>
      <table class="cl-table">
        <?php foreach ($cards as $c):
            $key = card_key($c['title']);
            $rule = $map[$key] ?? null;
            $cur = 'auto';
            if ($rule) {
                $cur = in_array($rule['type'], ['page','category','leader'], true) ? $rule['type'] . ':' . (int)$rule['id'] : $rule['type'];
            }
            [$url, $src] = card_resolve($c['title']);
            if ($c['group'] !== $group): $group = $c['group']; ?>
              <tr class="cl-group"><td colspan="3"><?= h($group ?: '—') ?></td></tr>
            <?php endif; ?>
          <tr>
            <td class="cl-name">
              <strong><?= h($c['title']) ?></strong>
              <?php if ($c['pos']): ?><small><?= h($c['pos']) ?></small><?php endif; ?>
            </td>
            <td class="cl-sel">
              <select name="rule[<?= h($key) ?>]" class="cl-rule">
                <option value="auto" <?= $cur === 'auto' ? 'selected' : '' ?>>⚙ Avtomatik</option>
                <option value="none" <?= $cur === 'none' ? 'selected' : '' ?>>⛔ Havolasiz</option>
                <?php if ($leaders): ?>
                <optgroup label="Rahbariyat (kartochkaga)">
                  <?php foreach ($leaders as $l): $v = 'leader:' . (int)$l['id']; ?>
                    <option value="<?= $v ?>" <?= $cur === $v ? 'selected' : '' ?>><?= h($l['full_name']) ?> — <?= h(mb_strimwidth((string)$l['position'], 0, 40, '…')) ?></option>
                  <?php endforeach; ?>
                </optgroup>
                <?php endif; ?>
                <optgroup label="Sahifalar">
                  <?php foreach ($allPages as $p): $v = 'page:' . (int)$p['id']; ?>
                    <option value="<?= $v ?>" <?= $cur === $v ? 'selected' : '' ?>><?= h($p['title']) ?></option>
                  <?php endforeach; ?>
                </optgroup>
                <optgroup label="Bo'limlar (yangiliklar)">
                  <?php foreach ($allCats as $cat): $v = 'category:' . (int)$cat['id']; ?>
                    <option value="<?= $v ?>" <?= $cur === $v ? 'selected' : '' ?>><?= h($cat['name']) ?></option>
                  <?php endforeach; ?>
                </optgroup>
                <option value="url" <?= $cur === 'url' ? 'selected' : '' ?>>🔗 Maxsus havola (URL)…</option>
              </select>
              <input type="text" name="url[<?= h($key) ?>]" class="cl-url" placeholder="https://... yoki /page.php?slug=..."
                     value="<?= h(($rule['type'] ?? '') === 'url' ? $rule['url'] : '') ?>" <?= $cur === 'url' ? '' : 'hidden' ?>>
            </td>
            <td class="cl-now">
              <?php if ($src === 'off'): ?><span class="tag gray">Havolasiz</span>
              <?php elseif ($url): ?>
                <span class="tag <?= $src === 'auto' ? 'green' : 'gold' ?>"><?= $src === 'auto' ? 'Avtomatik' : 'Tanlangan' ?></span>
                <a href="<?= h($url) ?>" target="_blank" class="cl-link" title="<?= h($url) ?>"><?= h(preg_replace('~^https?://[^/]+~', '', $url) ?: $url) ?></a>
              <?php else: ?><span class="tag red-soft">Havola topilmadi</span><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </table>
    </div>
  <?php endforeach; ?>

  <?php if ($pagesWithCards): ?>
    <div class="cl-save"><button class="btn" type="submit">Saqlash</button></div>
  <?php endif; ?>
</form>

<script>
document.querySelectorAll('.cl-rule').forEach(function (s) {
  s.addEventListener('change', function () {
    var u = s.parentNode.querySelector('.cl-url');
    u.hidden = s.value !== 'url';
    if (!u.hidden) u.focus();
  });
});
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
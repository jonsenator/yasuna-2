<?php
require_once __DIR__ . '/auth.php';

$id = (int)($_GET['id'] ?? 0);
$page = ['id'=>0,'title'=>'','content'=>'','status'=>'published'];
if ($id) {
    $st = db()->prepare('SELECT * FROM pages WHERE id = ?');
    $st->execute([$id]);
    $page = $st->fetch() ?: $page;
}
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $title   = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $status  = ($_POST['status'] ?? '') === 'draft' ? 'draft' : 'published';
    if ($title === '') $errors[] = 'Sarlavha kiritilmagan';
    if (!$errors) {
        if ($id) {
            db()->prepare('UPDATE pages SET title=?, content=?, status=? WHERE id=?')
               ->execute([$title, $content, $status, $id]);
            flash_set('Sahifa yangilandi');
        } else {
            $slug = slugify($title);
            $chk = db()->prepare('SELECT COUNT(*) FROM pages WHERE slug=?');
            $chk->execute([$slug]);
            if ($chk->fetchColumn() > 0) $slug .= '-' . substr(md5(microtime()),0,4);
            db()->prepare('INSERT INTO pages (title, slug, content, status) VALUES (?,?,?,?)')
               ->execute([$title, $slug, $content, $status]);
            flash_set('Sahifa qo\'shildi');
        }
        redirect('pages.php');
    }
    $page = array_merge($page, ['title'=>$title,'content'=>$content,'status'=>$status]);
}

$active = 'pages';
$page_title = $id ? 'Sahifani tahrirlash' : 'Yangi sahifa';
require __DIR__ . '/includes/header.php';
?>
<?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>
<div class="card" style="max-width:860px">
  <form method="post">
    <?= csrf_field() ?>
    <label>Sarlavha *</label>
    <input type="text" name="title" value="<?= h($page['title']) ?>" required>
    <label>Matn</label>
    <textarea name="content" rows="16" class="editor"><?= h($page['content']) ?></textarea>
    <p class="wys-tip">
      💡 Matnni to'g'ridan-to'g'ri yozing yoki Word/saytdan nusxalab qo'ying — format avtomatik tozalanadi.
      <b>Bloklar</b> qatoridagi tugmalar bilan vaqt lentasi, rekvizitlar jadvali va boshqa chiroyli bloklarni qo'shasiz.
      <b>HTML kodi</b> tugmasi kodni qo'lda tahrirlash uchun.
    </p>
    <label>Holat</label>
    <select name="status" style="max-width:220px">
      <option value="published" <?= $page['status']==='published'?'selected':'' ?>>Faol</option>
      <option value="draft" <?= $page['status']==='draft'?'selected':'' ?>>Qoralama</option>
    </select>
    <div class="actions">
      <button class="btn" type="submit">Saqlash</button>
      <a href="pages.php" class="btn gray">Bekor qilish</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>

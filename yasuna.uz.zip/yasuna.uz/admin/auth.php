<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';

if (empty($_SESSION['user_id'])) {
    redirect('login.php');
}

function current_user(): ?array {
    static $u = null;
    if ($u === null && !empty($_SESSION['user_id'])) {
        $st = db()->prepare('SELECT * FROM users WHERE id = ?');
        $st->execute([$_SESSION['user_id']]);
        $u = $st->fetch() ?: null;
    }
    return $u;
}

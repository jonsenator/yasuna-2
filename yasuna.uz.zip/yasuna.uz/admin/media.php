<?php
/**
 * Saytdagi rasmlar kutubxonasi (assets/uploads) — JSON ro'yxat.
 * Rasm tanlash oynasi (media-picker.js) shu yerdan foydalanadi.
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$q     = mb_strtolower(trim($_GET['q'] ?? ''));
$exts  = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
$items = [];

foreach (is_dir(UPLOAD_DIR) ? scandir(UPLOAD_DIR) : [] as $f) {
    if ($f[0] === '.') continue;
    if (!in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), $exts, true)) continue;
    if ($q !== '' && mb_strpos(mb_strtolower($f), $q) === false) continue;
    $path = UPLOAD_DIR . $f;
    if (!is_file($path)) continue;
    $items[] = [
        'name' => $f,
        'url'  => UPLOAD_URL . rawurlencode($f),
        'size' => filesize($path),
        'time' => filemtime($path),
    ];
}
usort($items, fn($a, $b) => $b['time'] <=> $a['time']); // yangilari birinchi

echo json_encode(['items' => $items], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
<?php
require_once __DIR__ . '/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['save'])) {
        // Asosiy sozlamalar
        $mainKeys = ['site_name','site_short','site_slogan','meta_description','meta_keywords','banner_enabled','banner_text','footer_text','copyright'];
        foreach ($mainKeys as $k) {
            $v = ($k === 'banner_enabled') ? ((isset($_POST[$k]) && $_POST[$k] === '1') ? '1' : '0') : trim($_POST[$k] ?? '');
            save_setting($k, $v);
        }
        // Aloqa sozlamalari
        foreach (['phone','email','address','working_hours','telegram','facebook','instagram','youtube','anticorruption_url'] as $k) {
            save_setting($k, trim($_POST[$k] ?? ''));
        }
        // Gerb rasmi: kompyuterdan / saytdagi rasmlardan / tashqi havola
        $gerbErr = '';
        if (!empty($_POST['gerb_remove'])) save_setting('gerb_image', '');
        if (!empty($_FILES['gerb_file']['name']) && $_FILES['gerb_file']['error'] === UPLOAD_ERR_OK) {
            [$ok, $res] = upload_image($_FILES['gerb_file']);
            if ($ok) save_setting('gerb_image', $res); else $gerbErr = $res;
        } elseif (trim($_POST['gerb_pick'] ?? '') !== '') {
            if ($g = valid_library_image($_POST['gerb_pick'])) save_setting('gerb_image', $g);
            else $gerbErr = 'Tanlangan gerb rasmi serverda topilmadi';
        } elseif (trim($_POST['gerb_url'] ?? '') !== '' && trim($_POST['gerb_url']) !== setting('gerb_image')) {
            if ($g = valid_image_url($_POST['gerb_url'])) save_setting('gerb_image', $g);
            else $gerbErr = 'Gerb havolasi noto\'g\'ri (http:// yoki https:// bilan boshlanishi kerak)';
        }

        // Kartalar foni
        $bgType = in_array($_POST['cards_bg_type'] ?? '', ['flag','plain','image'], true) ? $_POST['cards_bg_type'] : 'flag';
        save_setting('cards_bg_type', $bgType);
        save_setting('cards_bg_opacity', (string)max(30, min(98, (int)($_POST['cards_bg_opacity'] ?? 85))));
        if (!empty($_POST['cbg_remove'])) save_setting('cards_bg_image', '');
        if (!empty($_FILES['cbg_file']['name']) && $_FILES['cbg_file']['error'] === UPLOAD_ERR_OK) {
            [$ok, $res] = upload_image($_FILES['cbg_file']);
            if ($ok) save_setting('cards_bg_image', $res);
        } elseif (trim($_POST['cbg_pick'] ?? '') !== '') {
            if ($g = valid_library_image($_POST['cbg_pick'])) save_setting('cards_bg_image', $g);
        } elseif (trim($_POST['cbg_url'] ?? '') !== '' && trim($_POST['cbg_url']) !== setting('cards_bg_image')) {
            if ($g = valid_image_url($_POST['cbg_url'])) save_setting('cards_bg_image', $g);
        }

        // Logotip
        $logoErr = '';
        if (!empty($_POST['logo_remove'])) save_setting('site_logo', '');
        if (!empty($_FILES['logo_file']['name']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK) {
            [$ok, $res] = upload_image($_FILES['logo_file']);
            if ($ok) save_setting('site_logo', $res); else $logoErr = $res;
        } elseif (trim($_POST['logo_pick'] ?? '') !== '') {
            if ($g = valid_library_image($_POST['logo_pick'])) save_setting('site_logo', $g);
            else $logoErr = 'Tanlangan logotip serverda topilmadi';
        } elseif (trim($_POST['logo_url'] ?? '') !== '' && trim($_POST['logo_url']) !== setting('site_logo')) {
            if ($g = valid_image_url($_POST['logo_url'])) save_setting('site_logo', $g);
            else $logoErr = 'Logotip havolasi noto\'g\'ri';
        }
        if ($logoErr !== '') $gerbErr = trim($gerbErr . ' Logotip: ' . $logoErr);

        // Parol
        if ($gerbErr !== '') {
            flash_set('Sozlamalar saqlandi, lekin gerb O\'ZGARMADI: ' . $gerbErr);
        } elseif (!empty($_POST['new_password'])) {
            $st = db()->prepare('SELECT password FROM users WHERE id=?');
            $st->execute([$_SESSION['user_id']]);
            if (!password_verify($_POST['current_password'] ?? '', (string)$st->fetchColumn())) {
                flash_set('Sozlamalar saqlandi, lekin parol O\'ZGARMADI: joriy parol xato.');
            } elseif (mb_strlen($_POST['new_password']) < 8) {
                flash_set('Sozlamalar saqlandi, lekin parol O\'ZGARMADI: kamida 8 ta belgi bo\'lsin.');
            } else {
                $hash = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                db()->prepare('UPDATE users SET password=? WHERE id=?')->execute([$hash, $_SESSION['user_id']]);
                flash_set('Sozlamalar saqlandi. Parol o\'zgartirildi.');
            }
        } else {
            flash_set('Sozlamalar saqlandi');
        }
        redirect('settings.php');
    }
}

$active = 'settings';
$page_title = 'Sozlamalar';
require __DIR__ . '/includes/header.php';
?>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<div class="settings-wrap">
  <form method="post" class="card" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="save" value="1">

    <h3 class="block-t">Sayt haqida</h3>
    <div class="grid2">
      <div><label>Sayt nomi</label><input type="text" name="site_name" value="<?= h(setting('site_name')) ?>"></div>
      <div><label>Qisqa nom</label><input type="text" name="site_short" value="<?= h(setting('site_short')) ?>"></div>
    </div>
    <label>Shior (slogan)</label>
    <input type="text" name="site_slogan" value="<?= h(setting('site_slogan')) ?>">
    <label>Meta tavsif (SEO)</label>
    <textarea name="meta_description" rows="2"><?= h(setting('meta_description')) ?></textarea>
    <label>Meta kalit so'zlar</label>
    <input type="text" name="meta_keywords" value="<?= h(setting('meta_keywords')) ?>">

    <hr>
    <h3 class="block-t">Logotip (sayt sarlavhasi va footer)</h3>
    <?php $li = trim((string)setting('site_logo'));
          $lurl = site_logo_url(); ?>
    <div class="gerb-set" data-picker="logo">
      <div class="gerb-prev logo-prev">
        <img src="<?= h($lurl ?: '') ?>" alt="" data-el="prev" <?= $lurl ? '' : 'hidden' ?>>
        <span data-el="empty" <?= $lurl ? 'hidden' : '' ?>>Logo<br>yo'q</span>
      </div>
      <div class="gerb-ctl">
        <div class="mp-tabs">
          <button type="button" class="mp-tab" data-src="file"><b>💻</b>Kompyuterdan</button>
          <button type="button" class="mp-tab" data-src="lib"><b>🖼</b>Saytdan</button>
          <button type="button" class="mp-tab" data-src="url"><b>🔗</b>Havola</button>
        </div>
        <input type="file" name="logo_file" data-el="file" accept="image/*" hidden>
        <input type="hidden" name="logo_pick" data-el="pick">
        <div class="mp-url" data-el="urlbox" <?= preg_match('~^https?://~i', $li) ? '' : 'hidden' ?>>
          <input type="text" name="logo_url" data-el="url" value="<?= preg_match('~^https?://~i', $li) ? h($li) : '' ?>" placeholder="https://.../logo.png">
        </div>
        <small class="ld-note" data-el="info"><?= $li !== '' ? 'Joriy: ' . h(basename($li)) : ($lurl ? 'Joriy: assets/logo.png' : 'Doira shaklidagi shaffof PNG tavsiya etiladi.') ?></small>
        <?php if ($li !== ''): ?><label class="ld-check"><input type="checkbox" name="logo_remove" value="1" data-el="remove"> Logotipni olib tashlash</label><?php endif; ?>
      </div>
    </div>

    <hr>
    <h3 class="block-t">Gerb (tuzilma sahifalaridagi banner uchun)</h3>
    <?php $gi = trim((string)setting('gerb_image'));
          $gurl = $gi === '' ? '' : (preg_match('~^https?://~i', $gi) ? $gi : UPLOAD_URL . rawurlencode($gi)); ?>
    <div class="gerb-set">
      <div class="gerb-prev">
        <img src="<?= h($gurl) ?>" alt="" id="gPrev" <?= $gurl ? '' : 'hidden' ?>>
        <span id="gEmpty" <?= $gurl ? 'hidden' : '' ?>>Gerb<br>yo'q</span>
      </div>
      <div class="gerb-ctl">
        <div class="mp-tabs">
          <button type="button" class="mp-tab" data-g="file"><b>💻</b>Kompyuterdan</button>
          <button type="button" class="mp-tab" data-g="lib"><b>🖼</b>Saytdan</button>
          <button type="button" class="mp-tab" data-g="url"><b>🔗</b>Havola</button>
        </div>
        <input type="file" name="gerb_file" id="gFile" accept="image/*" hidden>
        <input type="hidden" name="gerb_pick" id="gPick">
        <div class="mp-url" id="gUrlBox" <?= preg_match('~^https?://~i', $gi) ? '' : 'hidden' ?>>
          <input type="text" name="gerb_url" id="gUrl" value="<?= preg_match('~^https?://~i', $gi) ? h($gi) : '' ?>" placeholder="https://.../gerb.png">
        </div>
        <small class="ld-note" id="gInfo"><?= $gurl ? 'Joriy: ' . h(basename($gi)) : 'Shaffof fonli PNG tavsiya etiladi. Gerb qo\'yilmasa — bayroq naqshi chiqadi.' ?></small>
        <?php if ($gurl): ?><label class="ld-check"><input type="checkbox" name="gerb_remove" value="1" id="gRemove"> Gerbni olib tashlash</label><?php endif; ?>
      </div>
    </div>

    <hr>
    <h3 class="block-t">Kartalar foni (tuzilma va kafedra sahifalari)</h3>
    <?php $bt = setting('cards_bg_type', 'flag');
          $bi = trim((string)setting('cards_bg_image'));
          $burl = $bi === '' ? '' : (preg_match('~^https?://~i', $bi) ? $bi : UPLOAD_URL . rawurlencode($bi));
          $bop = (int)setting('cards_bg_opacity', '85'); ?>
    <div class="cbg-types">
      <label class="cbg-type"><input type="radio" name="cards_bg_type" value="flag" <?= $bt === 'flag' ? 'checked' : '' ?>>
        <span><b>Bayroq</b><small>Xira rangli bayroq (hozirgi)</small></span></label>
      <label class="cbg-type"><input type="radio" name="cards_bg_type" value="plain" <?= $bt === 'plain' ? 'checked' : '' ?>>
        <span><b>Tekis</b><small>Oddiy oq fon</small></span></label>
      <label class="cbg-type"><input type="radio" name="cards_bg_type" value="image" <?= $bt === 'image' ? 'checked' : '' ?>>
        <span><b>Rasm</b><small>O'zingiz yuklagan rasm</small></span></label>
    </div>

    <div class="gerb-set cbg-box" data-picker="cbg" <?= $bt === 'image' ? '' : 'hidden' ?>>
      <div class="gerb-prev cbg-prev">
        <img src="<?= h($burl ?: '') ?>" alt="" data-el="prev" <?= $burl ? '' : 'hidden' ?>>
        <span data-el="empty" <?= $burl ? 'hidden' : '' ?>>Rasm<br>yo'q</span>
      </div>
      <div class="gerb-ctl">
        <div class="mp-tabs">
          <button type="button" class="mp-tab" data-src="file"><b>💻</b>Kompyuterdan</button>
          <button type="button" class="mp-tab" data-src="lib"><b>🖼</b>Saytdan</button>
          <button type="button" class="mp-tab" data-src="url"><b>🔗</b>Havola</button>
        </div>
        <input type="file" name="cbg_file" data-el="file" accept="image/*" hidden>
        <input type="hidden" name="cbg_pick" data-el="pick">
        <div class="mp-url" data-el="urlbox" <?= preg_match('~^https?://~i', $bi) ? '' : 'hidden' ?>>
          <input type="text" name="cbg_url" data-el="url" value="<?= preg_match('~^https?://~i', $bi) ? h($bi) : '' ?>" placeholder="https://.../fon.jpg">
        </div>
        <small class="ld-note" data-el="info"><?= $bi !== '' ? 'Joriy: ' . h(basename($bi)) : 'Ochroq, sokin rasm tanlang — matn ustida yaxshi o\'qiladi.' ?></small>
        <label class="cbg-op">Oq parda qalinligi: <output id="opOut"><?= $bop ?></output>%
          <input type="range" name="cards_bg_opacity" min="30" max="98" step="1" value="<?= $bop ?>" oninput="document.getElementById('opOut').textContent=this.value">
        </label>
        <?php if ($bi !== ''): ?><label class="ld-check"><input type="checkbox" name="cbg_remove" value="1" data-el="remove"> Fon rasmini olib tashlash</label><?php endif; ?>
      </div>
    </div>

    <hr>
    <h3 class="block-t">Yuqori banner</h3>
    <label style="display:flex;align-items:center;gap:8px">
      <input type="checkbox" name="banner_enabled" value="1" <?= setting('banner_enabled')==='1'?'checked':'' ?> style="width:auto"> Banner ko'rsatilsin
    </label>
    <label>Banner matni</label>
    <input type="text" name="banner_text" value="<?= h(setting('banner_text')) ?>">

    <hr>
    <h3 class="block-t">Aloqa ma'lumotlari</h3>
    <div class="grid2">
      <div><label>Telefon</label><input type="text" name="phone" value="<?= h(setting('phone')) ?>"></div>
      <div><label>Email</label><input type="text" name="email" value="<?= h(setting('email')) ?>"></div>
    </div>
    <label>Manzil</label>
    <input type="text" name="address" value="<?= h(setting('address')) ?>">
    <label>Ish vaqti</label>
    <input type="text" name="working_hours" value="<?= h(setting('working_hours')) ?>">

    <hr>
    <h3 class="block-t">Ijtimoiy tarmoqlar</h3>
    <div class="grid2">
      <div><label>Telegram</label><input type="text" name="telegram" value="<?= h(setting('telegram')) ?>"></div>
      <div><label>Facebook</label><input type="text" name="facebook" value="<?= h(setting('facebook')) ?>"></div>
      <div><label>Instagram</label><input type="text" name="instagram" value="<?= h(setting('instagram')) ?>"></div>
      <div><label>YouTube</label><input type="text" name="youtube" value="<?= h(setting('youtube')) ?>"></div>
    </div>
    <label>«STOP KORRUPSIYA» tugmasi havolasi</label>
    <input type="text" name="anticorruption_url" value="<?= h(setting('anticorruption_url')) ?>" placeholder="Bo'sh qolsa — aloqa sahifasi ochiladi">

    <hr>
    <h3 class="block-t">Footer</h3>
    <label>Footer matni</label>
    <input type="text" name="footer_text" value="<?= h(setting('footer_text')) ?>">
    <label>Mualliflik huquqi</label>
    <input type="text" name="copyright" value="<?= h(setting('copyright')) ?>">

    <hr>
    <h3 class="block-t">Parolni o'zgartirish</h3>
    <div class="grid2">
      <div><label>Joriy parol</label><input type="password" name="current_password" autocomplete="current-password" placeholder="Parolni o'zgartirish uchun"></div>
      <div><label>Yangi parol (kamida 8 belgi)</label><input type="password" name="new_password" autocomplete="new-password" placeholder="O'zgartirmoqchi bo'lsangiz kiriting"></div>
    </div>

    <div class="actions">
      <button class="btn" type="submit">Barchasini saqlash</button>
    </div>
  </form>
</div>
<script>window.MEDIA_URL = 'media.php';</script>
<script src="<?= BASE_URL ?>/assets/js/media-picker.js?v=1"></script>
<script>
// Kartalar foni: tur tanlash
(function () {
  var box = document.querySelector('.cbg-box'); if (!box) return;
  document.querySelectorAll('input[name=cards_bg_type]').forEach(function (r) {
    r.addEventListener('change', function () { box.hidden = r.value !== 'image' || !r.checked; });
  });
})();
// Kartalar foni rasmi
(function () {
  var w = document.querySelector('[data-picker="cbg"]'); if (!w) return;
  var el = function (n) { return w.querySelector('[data-el="' + n + '"]'); };
  var file = el('file'), pick = el('pick'), url = el('url'), ubox = el('urlbox'), prev = el('prev'), empty = el('empty'), info = el('info');
  function show(src, t) { prev.src = src; prev.hidden = false; empty.hidden = true; info.textContent = t; if (el('remove')) el('remove').checked = false; }
  w.querySelectorAll('.mp-tab').forEach(function (b) {
    b.addEventListener('click', function () {
      w.querySelectorAll('.mp-tab').forEach(function (x) { x.classList.toggle('on', x === b); });
      ubox.hidden = b.dataset.src !== 'url';
      if (b.dataset.src === 'file') file.click();
      if (b.dataset.src === 'lib') MediaPicker.open(function (it) { file.value = ''; url.value = ''; pick.value = it.name; show(it.url, 'Saytdan: ' + it.name); });
      if (b.dataset.src === 'url') url.focus();
    });
  });
  file.addEventListener('change', function () { if (!file.files[0]) return; pick.value = ''; url.value = ''; show(URL.createObjectURL(file.files[0]), 'Kompyuterdan: ' + file.files[0].name); });
  url.addEventListener('change', function () {
    var v = url.value.trim(); if (!/^https?:\/\//i.test(v)) { info.textContent = 'Havola http:// yoki https:// bilan boshlanishi kerak'; return; }
    file.value = ''; pick.value = ''; var t = new Image();
    t.onload = function () { show(v, 'Tashqi havola \u2713'); }; t.onerror = function () { info.textContent = 'Bu havoladan rasm ochilmadi'; }; t.src = v;
  });
})();
</script>
<script>
// Logotip tanlash
(function () {
  var w = document.querySelector('[data-picker="logo"]'); if (!w) return;
  var el = function (n) { return w.querySelector('[data-el="' + n + '"]'); };
  var file = el('file'), pick = el('pick'), url = el('url'), box = el('urlbox'), prev = el('prev'), empty = el('empty'), info = el('info');
  function show(src, t) { prev.src = src; prev.hidden = false; empty.hidden = true; info.textContent = t; if (el('remove')) el('remove').checked = false; }
  w.querySelectorAll('.mp-tab').forEach(function (b) {
    b.addEventListener('click', function () {
      w.querySelectorAll('.mp-tab').forEach(function (x) { x.classList.toggle('on', x === b); });
      box.hidden = b.dataset.src !== 'url';
      if (b.dataset.src === 'file') file.click();
      if (b.dataset.src === 'lib') MediaPicker.open(function (it) { file.value = ''; url.value = ''; pick.value = it.name; show(it.url, 'Saytdan: ' + it.name); });
      if (b.dataset.src === 'url') url.focus();
    });
  });
  file.addEventListener('change', function () { if (!file.files[0]) return; pick.value = ''; url.value = ''; show(URL.createObjectURL(file.files[0]), 'Kompyuterdan: ' + file.files[0].name); });
  url.addEventListener('change', function () {
    var v = url.value.trim(); if (!/^https?:\/\//i.test(v)) { info.textContent = 'Havola http:// yoki https:// bilan boshlanishi kerak'; return; }
    file.value = ''; pick.value = ''; var t = new Image();
    t.onload = function () { show(v, 'Tashqi havola \u2713'); }; t.onerror = function () { info.textContent = 'Bu havoladan rasm ochilmadi'; }; t.src = v;
  });
})();
</script>
<script>
(function () {
  var file = document.getElementById('gFile'), pick = document.getElementById('gPick'),
      url = document.getElementById('gUrl'), box = document.getElementById('gUrlBox'),
      prev = document.getElementById('gPrev'), empty = document.getElementById('gEmpty'),
      info = document.getElementById('gInfo');
  function show(src, text) {
    prev.src = src; prev.hidden = false; empty.hidden = true; info.textContent = text;
    var rm = document.getElementById('gRemove'); if (rm) rm.checked = false;
  }
  document.querySelectorAll('.mp-tab[data-g]').forEach(function (b) {
    b.addEventListener('click', function () {
      document.querySelectorAll('.mp-tab[data-g]').forEach(function (x) { x.classList.toggle('on', x === b); });
      box.hidden = b.dataset.g !== 'url';
      if (b.dataset.g === 'file') file.click();
      if (b.dataset.g === 'lib') MediaPicker.open(function (it) {
        file.value = ''; url.value = ''; pick.value = it.name; show(it.url, 'Saytdan: ' + it.name);
      });
      if (b.dataset.g === 'url') url.focus();
    });
  });
  file.addEventListener('change', function () {
    if (!file.files[0]) return;
    pick.value = ''; url.value = ''; show(URL.createObjectURL(file.files[0]), 'Kompyuterdan: ' + file.files[0].name);
  });
  url.addEventListener('change', function () {
    var v = url.value.trim(); if (!/^https?:\/\//i.test(v)) { info.textContent = 'Havola http:// yoki https:// bilan boshlanishi kerak'; return; }
    file.value = ''; pick.value = '';
    var t = new Image();
    t.onload = function () { show(v, 'Tashqi havola \u2713'); };
    t.onerror = function () { info.textContent = 'Bu havoladan rasm ochilmadi'; };
    t.src = v;
  });
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    db()->prepare('DELETE FROM pages WHERE id = ?')->execute([(int)$_POST['delete_id']]);
    flash_set('Sahifa o\'chirildi');
    redirect('pages.php');
}

$rows = db()->query('SELECT * FROM pages ORDER BY created_at DESC')->fetchAll();

$active = 'pages';
$page_title = 'Sahifalar';
require __DIR__ . '/includes/header.php';
?>
<div class="bar">
  <div class="bar-left"><a href="page-edit.php" class="btn">+ Yangi sahifa</a></div>
</div>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>
<div class="card">
  <table>
    <tr><th>Sarlavha</th><th>Havola (slug)</th><th>Holat</th><th>Sana</th><th style="width:270px;text-align:right">Amal</th></tr>
    <?php foreach ($rows as $p): ?>
    <tr>
      <td><a href="page-edit.php?id=<?= (int)$p['id'] ?>" class="link"><?= h($p['title']) ?></a></td>
      <td style="color:#5b6b74">/page.php?slug=<?= h($p['slug']) ?></td>
      <td><?= $p['status']==='published' ? '<span class="tag green">Faol</span>' : '<span class="tag gray">Qoralama</span>' ?></td>
      <td><?= uzdate($p['created_at']) ?></td>
      <td class="acts">
        <div class="row-actions">
          <a href="<?= page_url($p) ?>" target="_blank" class="btn sm gray" title="Saytda ko'rish">Ko'rish</a>
          <?php if (strpos((string)$p['content'], 'pmm-staff') !== false): ?>
            <a href="cards.php?page=<?= (int)$p['id'] ?>" class="btn sm gold" title="Sahifadagi kartalarni tahrirlash">Kartalar</a>
          <?php endif; ?>
          <a href="page-edit.php?id=<?= (int)$p['id'] ?>" class="btn sm" title="Ushbu sahifani tahrirlash">Tahrirlash</a>
          <form method="post" onsubmit="return confirm('«<?= h(addslashes($p['title'])) ?>» sahifasi o\'chirilsinmi? Bu amalni bekor qilib bo\'lmaydi.')">
            <?= csrf_field() ?>
            <input type="hidden" name="delete_id" value="<?= (int)$p['id'] ?>">
            <button class="btn sm red" title="Ushbu sahifani o'chirish">O'chirish</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="5" style="color:#94a3b8">Sahifa yo'q</td></tr><?php endif; ?>
  </table>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';

// O'qilgan deb belgilash
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_read'])) {
    csrf_check();
    db()->prepare('UPDATE messages SET is_read=1 WHERE id=?')->execute([(int)$_POST['mark_read']]);
    redirect('messages.php');
}
// O'chirish
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    db()->prepare('DELETE FROM messages WHERE id=?')->execute([(int)$_POST['delete_id']]);
    flash_set('Xabar o\'chirildi');
    redirect('messages.php');
}

$show = (int)($_GET['id'] ?? 0);
$rows = db()->query('SELECT * FROM messages ORDER BY created_at DESC')->fetchAll();

$active = 'messages';
$page_title = 'Xabarlar';
require __DIR__ . '/includes/header.php';
?>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<?php if ($show && ($msg = get_message($show))): ?>
  <div class="card msg-view">
    <div class="bar">
      <div class="bar-left"><a href="messages.php" class="btn gray sm">&larr; Orqaga</a></div>
      <div class="bar-right">
        <form method="post" style="display:inline">
          <?= csrf_field() ?>
          <input type="hidden" name="mark_read" value="<?= (int)$msg['id'] ?>">
          <button class="btn sm green" type="submit">O'qilgan deb belgilash</button>
        </form>
        <form method="post" style="display:inline" onsubmit="return confirm('O\'chirilsinmi?')">
          <?= csrf_field() ?>
          <input type="hidden" name="delete_id" value="<?= (int)$msg['id'] ?>">
          <button class="btn sm red">O'chirish</button>
        </form>
      </div>
    </div>
    <h2><?= h($msg['subject'] ?: '(mavzusiz)') ?></h2>
    <div class="msg-meta">
      <span><strong><?= h($msg['name']) ?></strong></span>
      <?php if ($msg['phone']): ?><span><?= h($msg['phone']) ?></span><?php endif; ?>
      <?php if ($msg['email']): ?><span><a href="mailto:<?= h($msg['email']) ?>"><?= h($msg['email']) ?></a></span><?php endif; ?>
      <span><?= uzdatetime($msg['created_at']) ?></span>
    </div>
    <div class="msg-body"><?= nl2br(h($msg['message'])) ?></div>
  </div>
<?php else: ?>
<div class="card">
  <table>
    <tr><th>Kimdan</th><th>Mavzu</th><th>Telefon</th><th>Holat</th><th>Sana</th><th style="width:150px">Amal</th></tr>
    <?php foreach ($rows as $m): ?>
    <tr class="<?= !$m['is_read'] ? 'unread' : '' ?>">
      <td><strong><?= h($m['name']) ?></strong><?php if (!$m['is_read']): ?><span class="pill sm">Yangi</span><?php endif; ?></td>
      <td><?= h($m['subject'] ?: '—') ?></td>
      <td><?= h($m['phone'] ?: '—') ?></td>
      <td><?= $m['is_read'] ? '<span class="tag gray">O\'qilgan</span>' : '<span class="tag green">Yangi</span>' ?></td>
      <td><?= uzdate($m['created_at']) ?></td>
      <td>
        <a href="messages.php?id=<?= (int)$m['id'] ?>" class="btn sm gray">O'qish</a>
        <form method="post" style="display:inline" onsubmit="return confirm('O\'chirilsinmi?')">
          <?= csrf_field() ?>
          <input type="hidden" name="delete_id" value="<?= (int)$m['id'] ?>">
          <button class="btn sm red">O'ch</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="6" style="color:#94a3b8">Xabarlar yo'q</td></tr><?php endif; ?>
  </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>

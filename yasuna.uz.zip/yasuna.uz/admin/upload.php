<?php
/**
 * Tez rasm yuklash (JSON) — «Kartalar» muharriridagi rasm tugmasi shu yerga yuboradi.
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Faqat POST']);
    exit;
}
csrf_check();

if (empty($_FILES['file']['name']) || ($_FILES['file']['error'] ?? 1) !== UPLOAD_ERR_OK) {
    echo json_encode(['ok' => false, 'error' => 'Fayl yuklanmadi'], JSON_UNESCAPED_UNICODE);
    exit;
}

[$ok, $res] = upload_image($_FILES['file']);
echo json_encode($ok
    ? ['ok' => true, 'name' => $res, 'url' => UPLOAD_URL . rawurlencode($res)]
    : ['ok' => false, 'error' => $res], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
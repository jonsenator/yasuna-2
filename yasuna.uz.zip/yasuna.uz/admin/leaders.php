<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';
require_once __DIR__ . '/../includes/leaders.php';
leaders_ensure_table();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    // O'chirish
    if (isset($_POST['delete_id'])) {
        $l = get_leader((int)$_POST['delete_id']);
        if ($l) {
            db()->prepare('DELETE FROM leaders WHERE id=?')->execute([(int)$l['id']]);
            flash_set('«' . $l['full_name'] . '» o\'chirildi');
        }
        redirect('leaders.php');
    }

    // Tartibni o'zgartirish (yuqoriga / pastga)
    if (isset($_POST['move_id'], $_POST['dir'])) {
        $rows = get_leaders(false);
        $ids  = array_map(fn($r) => (int)$r['id'], $rows);
        $i    = array_search((int)$_POST['move_id'], $ids, true);
        $j    = $_POST['dir'] === 'up' ? $i - 1 : $i + 1;
        if ($i !== false && isset($ids[$j])) {
            [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
            $up = db()->prepare('UPDATE leaders SET sort_order=? WHERE id=?');
            foreach ($ids as $n => $id) $up->execute([$n + 1, $id]);
        }
        redirect('leaders.php');
    }

    // Faol / nofaol
    if (isset($_POST['toggle_id'])) {
        db()->prepare('UPDATE leaders SET active = 1 - active WHERE id=?')->execute([(int)$_POST['toggle_id']]);
        redirect('leaders.php');
    }

    // Zaxiradan qaytarish
    if (isset($_POST['restore_page'])) {
        [$ok, $n] = leaders_restore_page((int)$_POST['restore_page']);
        flash_set($ok ? "Sahifa avvalgi holatiga qaytarildi. Ro'yxatdan $n ta kishi olib tashlandi."
                      : 'Bu sahifa uchun zaxira topilmadi.');
        redirect('leaders.php');
    }

    // Eski sahifadan import
    if (isset($_POST['import_page'])) {
        $n = leaders_import_from_page((int)$_POST['import_page']);
        flash_set($n ? "$n ta rahbar sahifadan ko'chirildi. Endi har birini shu yerdan tahrirlashingiz mumkin."
                     : 'Sahifada rahbar kartochkalari topilmadi.');
        redirect('leaders.php');
    }
}

$rows = get_leaders(false);

// [rahbariyat] belgisi qaysi sahifada turibdi?
$linked = db()->query("SELECT id, title, slug FROM pages WHERE content LIKE '%[rahbariyat]%'")->fetchAll();
// Eski (qo'lda yozilgan) kartochkali sahifalar
$legacy = db()->query("SELECT id, title FROM pages WHERE content LIKE '%pmm-person%'
                       AND (slug LIKE '%rahbariyat%' OR title LIKE '%rahbariyat%')")->fetchAll();
$backups = leaders_backups();

$active = 'leaders';
$page_title = 'Rahbariyat';
require __DIR__ . '/includes/header.php';
?>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<div class="bar">
  <div class="bar-left">
    <a href="leader-edit.php" class="btn">+ Yangi rahbar qo'shish</a>
  </div>
  <div class="bar-right">
    <?php foreach ($linked as $p): ?>
      <a href="<?= page_url($p) ?>" target="_blank" class="btn gray sm">Saytda ko'rish: <?= h($p['title']) ?> ↗</a>
    <?php endforeach; ?>
  </div>
</div>

<?php if ($backups): ?>
  <div class="hint ld-restore">
    <div>
      <strong>Zaxira nusxalar.</strong> Quyidagi sahifalar ko'chirishdan oldingi holatda saqlangan.
      «Qaytarish» bosilsa — sahifa matni avvalgidek tiklanadi va undan ko'chirilgan kishilar shu ro'yxatdan olib tashlanadi.
    </div>
    <div class="ld-restore-btns">
    <?php foreach ($backups as $p): ?>
      <form method="post" onsubmit="return confirm('«<?= h(addslashes($p['title'])) ?>» sahifasi avvalgi holatiga qaytarilsinmi?')">
        <?= csrf_field() ?>
        <input type="hidden" name="restore_page" value="<?= (int)$p['id'] ?>">
        <button class="btn sm red">«<?= h($p['title']) ?>» ni qaytarish</button>
      </form>
    <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

<?php if ($legacy): ?>
  <div class="hint ld-import">
    <div>
      <strong>Eski sahifa topildi.</strong> Quyidagi sahifada rahbarlar qo'lda (HTML) yozilgan.
      Bir tugma bilan ularni shu bo'limga ko'chiring — keyin har birini oddiy forma orqali tahrirlaysiz.
      Sahifaning eski matni zaxiraga saqlanadi.
    </div>
    <?php foreach ($legacy as $p): ?>
      <form method="post" onsubmit="return confirm('«<?= h(addslashes($p['title'])) ?>» sahifasidagi rahbarlar ko\'chirilsinmi?')">
        <?= csrf_field() ?>
        <input type="hidden" name="import_page" value="<?= (int)$p['id'] ?>">
        <button class="btn gold sm">«<?= h($p['title']) ?>» dan ko'chirish</button>
      </form>
    <?php endforeach; ?>
  </div>
<?php elseif (!$linked): ?>
  <div class="hint">
    💡 Rahbarlar saytda chiqishi uchun kerakli sahifa matniga (Sahifalar → tahrirlash) quyidagi belgini yozing:
    <code class="ld-code">[rahbariyat]</code> — kartochkalar aynan shu joyda chiqadi.
  </div>
<?php endif; ?>

<div class="card">
  <table>
    <tr>
      <th style="width:70px">Rasm</th><th>F.I.Sh. va lavozim</th><th>Qabul</th><th>Holat</th>
      <th style="width:90px">Tartib</th><th style="width:210px;text-align:right">Amal</th>
    </tr>
    <?php foreach ($rows as $i => $l): $img = leader_photo_url($l['photo']); ?>
    <tr>
      <td><?php if ($img): ?><img src="<?= h($img) ?>" class="ld-thumb" alt=""><?php else: ?><div class="ld-thumb noimg"><?= h(mb_substr($l['full_name'], 0, 1)) ?></div><?php endif; ?></td>
      <td>
        <a href="leader-edit.php?id=<?= (int)$l['id'] ?>" class="link"><?= h($l['full_name']) ?></a>
        <?php if ($l['is_head']): ?> <span class="tag gold">Rahbar</span><?php endif; ?>
        <div class="ld-sub"><?= h($l['position'] ?: '—') ?></div>
      </td>
      <td class="ld-sub">
        <?= h(trim(($l['reception_from'] ?? '') . ($l['reception_to'] ? ' – ' . $l['reception_to'] : ''))) ?: '—' ?><br>
        <?= h(str_replace(',', ', ', (string)$l['reception_days'])) ?>
      </td>
      <td>
        <form method="post">
          <?= csrf_field() ?><input type="hidden" name="toggle_id" value="<?= (int)$l['id'] ?>">
          <button class="tag <?= $l['active'] ? 'green' : 'gray' ?> ld-toggle" title="Bosib o'zgartiring"><?= $l['active'] ? 'Ko\'rinadi' : 'Yashirin' ?></button>
        </form>
      </td>
      <td>
        <div class="ld-move">
          <form method="post"><?= csrf_field() ?><input type="hidden" name="move_id" value="<?= (int)$l['id'] ?>"><input type="hidden" name="dir" value="up">
            <button class="btn sm gray" <?= $i === 0 ? 'disabled' : '' ?> title="Yuqoriga">↑</button></form>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="move_id" value="<?= (int)$l['id'] ?>"><input type="hidden" name="dir" value="down">
            <button class="btn sm gray" <?= $i === count($rows) - 1 ? 'disabled' : '' ?> title="Pastga">↓</button></form>
        </div>
      </td>
      <td class="acts">
        <div class="row-actions">
          <a href="leader-edit.php?id=<?= (int)$l['id'] ?>" class="btn sm">Tahrirlash</a>
          <form method="post" onsubmit="return confirm('«<?= h(addslashes($l['full_name'])) ?>» o\'chirilsinmi?')">
            <?= csrf_field() ?><input type="hidden" name="delete_id" value="<?= (int)$l['id'] ?>">
            <button class="btn sm red">O'chirish</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="6" style="color:#94a3b8;padding:26px 12px">Hozircha rahbar qo'shilmagan.</td></tr><?php endif; ?>
  </table>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
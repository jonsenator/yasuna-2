<?php
require_once __DIR__ . '/auth.php';

// Saqlash
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    csrf_check();
    $sid   = (int)($_POST['id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $sub   = trim($_POST['subtitle'] ?? '');
    $link  = trim($_POST['link'] ?? '');
    $order = (int)($_POST['sort_order'] ?? 0);
    $active= isset($_POST['active']) ? 1 : 0;
    $image = null;

    if ($sid) {
        $st = db()->prepare('SELECT image FROM slider WHERE id=?'); $st->execute([$sid]);
        $image = $st->fetchColumn() ?: null;
    }

    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        [$ok, $res] = upload_image($_FILES['image']);
        if ($ok) { if ($image) delete_upload($image); $image = $res; }
        else flash_set($res);
    }

    if ($title !== '') {
        if ($sid) {
            db()->prepare('UPDATE slider SET title=?, subtitle=?, image=?, link=?, sort_order=?, active=? WHERE id=?')
               ->execute([$title, $sub, $image, $link, $order, $active, $sid]);
            flash_set('Slayd yangilandi');
        } else {
            db()->prepare('INSERT INTO slider (title, subtitle, image, link, sort_order, active) VALUES (?,?,?,?,?,?)')
               ->execute([$title, $sub, $image, $link, $order, $active]);
            flash_set('Slayd qo\'shildi');
        }
    }
    redirect('slider.php');
}

// O'chirish
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    $st = db()->prepare('SELECT image FROM slider WHERE id=?'); $st->execute([(int)$_POST['delete_id']]);
    delete_upload($st->fetchColumn());
    db()->prepare('DELETE FROM slider WHERE id=?')->execute([(int)$_POST['delete_id']]);
    flash_set('Slayd o\'chirildi');
    redirect('slider.php');
}

$editId = (int)($_GET['edit'] ?? 0);
$edit = ['id'=>0,'title'=>'','subtitle'=>'','link'=>'','image'=>'','sort_order'=>0,'active'=>1];
if ($editId) {
    $st = db()->prepare('SELECT * FROM slider WHERE id=?'); $st->execute([$editId]);
    $edit = $st->fetch() ?: $edit;
}

$rows = db()->query('SELECT * FROM slider ORDER BY sort_order, id')->fetchAll();

$active = 'slider';
$page_title = 'Slayder boshqaruvi';
require __DIR__ . '/includes/header.php';
?>
<p class="hint">Bosh sahifadagi yuqori (hero) slayder shu yerda boshqariladi. Yaxshi natija uchun keng (1600×600) rasm tavsiya etiladi. Hajmi 3-5 ta slaydni saqlash ma'qul.</p>
<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<div class="two-col">
  <div class="card">
    <?php if ($rows): ?>
      <div class="slide-list">
        <?php foreach ($rows as $s): ?>
          <div class="sitem">
            <?php if ($s['image']): ?><img src="<?= UPLOAD_URL . h($s['image']) ?>" alt=""><?php else: ?><div class="sno">Rasm yo'q</div><?php endif; ?>
            <div class="sinfo">
              <strong><?= h($s['title']) ?></strong>
              <small><?= $s['active'] ? '<span class="tag green">Faol</span>' : '<span class="tag gray">O\'chiq</span>' ?> · Tartib: <?= (int)$s['sort_order'] ?></small>
            </div>
            <div class="sact">
              <a href="slider.php?edit=<?= (int)$s['id'] ?>" class="btn sm gray">Tahrir</a>
              <form method="post" style="display:inline" onsubmit="return confirm('O\'chirilsinmi?')">
                <?= csrf_field() ?>
                <input type="hidden" name="delete_id" value="<?= (int)$s['id'] ?>">
                <button class="btn sm red">O'ch</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p style="color:#94a3b8">Hozircha slayd yo'q. Chap tarafdagi formadan qo'shing.</p>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3 style="font-size:16px;margin-bottom:6px"><?= $edit['id'] ? 'Tahrirlash' : 'Yangi slayd' ?></h3>
    <form method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
      <label>Sarlavha *</label>
      <input type="text" name="title" value="<?= h($edit['title']) ?>" required>
      <label>Kichik matn (subtitle)</label>
      <input type="text" name="subtitle" value="<?= h($edit['subtitle']) ?>">
      <label>Havola (yangi tafsilotga)</label>
      <input type="text" name="link" value="<?= h($edit['link']) ?>" placeholder="/post.php?slug=...">
      <label>Rasm</label>
      <?php if ($edit['image']): ?><div class="prev-img"><img src="<?= UPLOAD_URL . h($edit['image']) ?>" alt=""></div><?php endif; ?>
      <input type="file" name="image" accept="image/*">
      <label>Tartib raqami</label>
      <input type="text" name="sort_order" value="<?= (int)$edit['sort_order'] ?>">
      <label style="display:flex;align-items:center;gap:8px;margin-top:12px">
        <input type="checkbox" name="active" <?= $edit['active']?'checked':'' ?> style="width:auto"> Faol
      </label>
      <div class="actions">
        <button class="btn" name="save" value="1">Saqlash</button>
        <?php if ($edit['id']): ?><a href="slider.php" class="btn gray">Bekor</a><?php endif; ?>
      </div>
    </form>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>

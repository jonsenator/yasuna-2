<?php
require_once __DIR__ . '/auth.php';

$posts_count = (int)db()->query('SELECT COUNT(*) FROM posts')->fetchColumn();
$cats_count  = (int)db()->query('SELECT COUNT(*) FROM categories')->fetchColumn();
$pages_count = (int)db()->query('SELECT COUNT(*) FROM pages')->fetchColumn();
$menu_count  = (int)db()->query('SELECT COUNT(*) FROM menus')->fetchColumn();
$slider_count= (int)db()->query('SELECT COUNT(*) FROM slider')->fetchColumn();
$msg_unread  = (int)db()->query('SELECT COUNT(*) FROM messages WHERE is_read=0')->fetchColumn();
$total_views = (int)db()->query('SELECT COALESCE(SUM(views),0) FROM posts')->fetchColumn();
$latest = db()->query('SELECT p.*, c.name AS cat FROM posts p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.created_at DESC LIMIT 5')->fetchAll();

$active = 'dashboard';
$page_title = 'Boshqaruv paneli';
require __DIR__ . '/includes/header.php';
?>

<div class="stats">
  <div class="stat"><div class="n"><?= $posts_count ?></div><div class="l">Yangiliklar</div><a class="mini" href="posts.php">Boshqarish</a></div>
  <div class="stat"><div class="n"><?= $pages_count ?></div><div class="l">Sahifalar</div><a class="mini" href="pages.php">Boshqarish</a></div>
  <div class="stat"><div class="n"><?= $menu_count ?></div><div class="l">Menyular</div><a class="mini" href="menus.php">Boshqarish</a></div>
  <div class="stat"><div class="n"><?= $slider_count ?></div><div class="l">Slaydlar</div><a class="mini" href="slider.php">Boshqarish</a></div>
  <div class="stat"><div class="n"><?= $msg_unread ?></div><div class="l">Yangi xabarlar</div><a class="mini" href="messages.php">O'qish</a></div>
  <div class="stat"><div class="n"><?= number_format($total_views) ?></div><div class="l">Jami ko'rishlar</div></div>
</div>

<div class="card" style="margin-top:24px">
  <div class="card-head">
    <h3>So'nggi yangiliklar</h3>
    <a href="post-edit.php" class="btn sm">+ Yangi</a>
  </div>
  <table>
    <tr><th>Sarlavha</th><th>Kategoriya</th><th>Holat</th><th>Ko'rishlar</th><th>Sana</th></tr>
    <?php foreach ($latest as $p): ?>
    <tr>
      <td><a href="post-edit.php?id=<?= (int)$p['id'] ?>" class="link"><?= h($p['title']) ?></a></td>
      <td><?= h($p['cat'] ?? '—') ?></td>
      <td><?= $p['status']==='published' ? '<span class="tag green">E\'lon</span>' : '<span class="tag gray">Qoralama</span>' ?></td>
      <td><?= (int)$p['views'] ?></td>
      <td><?= uzdate($p['created_at']) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$latest): ?><tr><td colspan="5" style="color:#94a3b8">Hozircha yangilik yo'q</td></tr><?php endif; ?>
  </table>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
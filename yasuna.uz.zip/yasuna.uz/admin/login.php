<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';

if (!empty($_SESSION['user_id'])) redirect('index.php');

$error = '';

// Parol tanlashdan himoya: bitta IP uchun 15 daqiqada 5 ta xato urinish
$lockFile = rtrim(sys_get_temp_dir() ?: '/tmp', '/') . '/yasuna_login_' . md5($_SERVER['REMOTE_ADDR'] ?? '') . '.json';
$att = @json_decode((string)@file_get_contents($lockFile), true) ?: ['n' => 0, 't' => 0];
if (time() - $att['t'] > 900) $att = ['n' => 0, 't' => time()];
$locked = $att['n'] >= 5;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $locked) {
    csrf_check();
    $error = 'Juda ko\'p xato urinish. ' . ceil((900 - (time() - $att['t'])) / 60) . ' daqiqadan keyin qayta urinib ko\'ring.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $st = db()->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute([$username]);
    $user = $st->fetch();
    if ($user && password_verify($password, $user['password'])) {
        @unlink($lockFile);
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        redirect('index.php');
    } else {
        $att['n']++;
        @file_put_contents($lockFile, json_encode($att), LOCK_EX);
        $error = 'Login yoki parol xato';
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kirish — Admin panel</title>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700;800&family=Public+Sans&display=swap" rel="stylesheet">
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:'Public Sans',system-ui,sans-serif}
  body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#072b1c,#0a5c36);}
  .box{width:360px;background:#fff;border-radius:16px;padding:34px 30px;box-shadow:0 24px 70px rgba(0,0,0,.45);border-top:5px solid #c9a227}
  .logo{width:54px;height:54px;border-radius:50%;background:radial-gradient(circle at 30% 28%,#173f2a,#0a5c36);display:grid;place-items:center;margin:0 auto 14px;color:#e6c14a;font-family:'Manrope';font-weight:800;font-size:20px;box-shadow:inset 0 0 0 3px rgba(201,162,39,.5)}
  h1{font-family:'Manrope';font-size:20px;text-align:center;color:#12222b;margin-bottom:3px}
  p.sub{text-align:center;color:#5b6b74;font-size:13px;margin-bottom:24px}
  label{display:block;font-size:13px;color:#334155;margin:12px 0 6px;font-weight:600}
  input{width:100%;padding:11px 13px;border:1px solid #d9e2db;border-radius:9px;font-size:14px;outline:none}
  input:focus{border-color:#0a5c36;box-shadow:0 0 0 3px rgba(10,92,54,.12)}
  button{width:100%;margin-top:20px;padding:12px;background:#0a5c36;color:#fff;border:none;border-radius:9px;font-size:15px;font-weight:700;cursor:pointer;transition:.2s}
  button:hover{background:#0d7a48}
  .err{background:#fee2e2;color:#7f1d1d;padding:9px 12px;border-radius:8px;font-size:13px;margin-bottom:14px;text-align:center}
</style>
</head>
<body>
  <form class="box" method="post">
    <div class="logo">PMM</div>
    <h1>Admin panel</h1>
    <p class="sub">yasuna.uz — boshqaruv tizimi</p>
    <?= csrf_field() ?>
    <?php if ($error): ?><div class="err"><?= h($error) ?></div><?php endif; ?>
    <label>Login</label>
    <input type="text" name="username" autofocus required>
    <label>Parol</label>
    <input type="password" name="password" required>
    <button type="submit">Kirish</button>
  </form>
</body>
</html>
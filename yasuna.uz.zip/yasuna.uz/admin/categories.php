<?php
// Kategoriyalar endi "Menyular" bo'limi orqali boshqariladi (bir menyu = bir bo'lim).
require_once __DIR__ . '/auth.php';
redirect('menus.php');
<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';
require_once __DIR__ . '/../includes/leaders.php';
leaders_ensure_table();

$id = (int)($_GET['id'] ?? 0);
$L = [
    'id' => 0, 'full_name' => '', 'position' => '', 'phone' => '', 'email' => '', 'photo' => '',
    'reception_from' => '', 'reception_to' => '', 'reception_days' => '',
    'career_intro' => '', 'career' => '[]', 'duties' => '', 'is_head' => 0, 'active' => 1,
];
if ($id) {
    $L = get_leader($id) ?: $L;
    if (!$L['id']) redirect('leaders.php');
}
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $time = fn($v) => preg_match('~^\d{2}:\d{2}$~', (string)$v) ? $v : null;

    $data = [
        'full_name'      => trim($_POST['full_name'] ?? ''),
        'position'       => trim($_POST['position'] ?? ''),
        'phone'          => trim($_POST['phone'] ?? ''),
        'email'          => trim($_POST['email'] ?? ''),
        'reception_from' => $time($_POST['reception_from'] ?? ''),
        'reception_to'   => $time($_POST['reception_to'] ?? ''),
        'reception_days' => implode(',', array_values(array_intersect(LEADER_DAYS, (array)($_POST['days'] ?? [])))),
        'career_intro'   => trim($_POST['career_intro'] ?? ''),
        'duties'         => trim($_POST['duties'] ?? ''),
        'is_head'        => isset($_POST['is_head']) ? 1 : 0,
        'active'         => isset($_POST['active']) ? 1 : 0,
    ];

    // Mehnat faoliyati qatorlari
    $career = [];
    foreach ((array)($_POST['career_t'] ?? []) as $k => $t) {
        $t = trim((string)$t);
        $y = trim((string)($_POST['career_y'][$k] ?? ''));
        if ($t !== '') $career[] = ['y' => $y, 't' => $t];
    }
    $data['career'] = json_encode($career, JSON_UNESCAPED_UNICODE);

    if ($data['full_name'] === '') $errors[] = 'F.I.Sh. kiritilmagan';
    if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email noto\'g\'ri';

    // Rasm: 1) kompyuterdan yuklash  2) saytdagi rasmlardan tanlash  3) tashqi havola
    $oldPhoto = $L['photo'] ?: null;
    $photo    = $oldPhoto;
    $pick     = trim($_POST['photo_pick'] ?? '');
    $url      = trim($_POST['photo_url'] ?? '');

    if (!empty($_POST['remove_photo'])) $photo = null;

    if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        [$ok, $res] = upload_image($_FILES['photo']);
        if ($ok) $photo = $res; else $errors[] = $res;
    } elseif ($pick !== '') {
        if ($name = valid_library_image($pick)) $photo = $name;
        else $errors[] = 'Tanlangan rasm serverda topilmadi';
    } elseif ($url !== '') {
        if ($u = valid_image_url($url)) $photo = $u;
        else $errors[] = 'Rasm havolasi noto\'g\'ri (http:// yoki https:// bilan boshlanishi kerak)';
    }
    $data['photo'] = $photo;

    if (!$errors) {
        $cols = array_keys($data);
        if ($id) {
            $set = implode(', ', array_map(fn($c) => "$c=?", $cols));
            db()->prepare("UPDATE leaders SET $set WHERE id=?")->execute([...array_values($data), $id]);
            flash_set('«' . $data['full_name'] . '» ma\'lumotlari saqlandi');
        } else {
            $data['sort_order'] = (int)db()->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM leaders')->fetchColumn();
            $cols = array_keys($data);
            db()->prepare('INSERT INTO leaders (' . implode(',', $cols) . ') VALUES (' . rtrim(str_repeat('?,', count($cols)), ',') . ')')
               ->execute(array_values($data));
            flash_set('«' . $data['full_name'] . '» qo\'shildi');
        }
        // Eski rasm serverdan o'chirilmaydi — u "Saytdagi rasmlar" ro'yxatida qoladi va boshqa joyda ishlatilishi mumkin
        redirect('leaders.php');
    }
    $L = array_merge($L, $data, ['photo' => $oldPhoto]);
}

$career = leader_career($L);
if (!$career) $career = [['y' => '', 't' => '']];
$days   = array_filter(explode(',', (string)$L['reception_days']));
$img    = leader_photo_url($L['photo']);

$active = 'leaders';
$page_title = $id ? 'Rahbarni tahrirlash' : 'Yangi rahbar';
require __DIR__ . '/includes/header.php';
?>
<?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>

<form method="post" enctype="multipart/form-data" class="ld-form" id="ldForm">
  <?= csrf_field() ?>

  <div class="ld-grid">
    <!-- ===== Chap ustun ===== -->
    <div class="ld-col">

      <section class="card ld-sec">
        <h3 class="ld-h"><span>1</span> Asosiy ma'lumotlar</h3>
        <label>Familiya, ism, sharif *</label>
        <input type="text" name="full_name" value="<?= h($L['full_name']) ?>" required placeholder="Masalan: Oripova Nozima Shuxratovna">
        <label>Lavozimi</label>
        <input type="text" name="position" value="<?= h($L['position']) ?>" placeholder="Masalan: Markaz direktori">
      </section>

      <section class="card ld-sec">
        <h3 class="ld-h"><span>2</span> Aloqa va fuqarolarni qabul qilish</h3>
        <div class="f2">
          <div><label>Telefon</label><input type="text" name="phone" value="<?= h($L['phone']) ?>" placeholder="+998 99 561-12-82"></div>
          <div><label>Email <small>(ixtiyoriy)</small></label><input type="email" name="email" value="<?= h($L['email']) ?>" placeholder="ism@yasuna.uz"></div>
        </div>
        <label>Qabul vaqti</label>
        <div class="ld-time">
          <input type="time" name="reception_from" value="<?= h($L['reception_from']) ?>">
          <span>—</span>
          <input type="time" name="reception_to" value="<?= h($L['reception_to']) ?>">
        </div>
        <label>Qabul kunlari</label>
        <div class="ld-days">
          <?php foreach (LEADER_DAYS as $d): ?>
            <label class="ld-day"><input type="checkbox" name="days[]" value="<?= $d ?>" <?= in_array($d, $days, true) ? 'checked' : '' ?>><span><?= $d ?></span></label>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="card ld-sec">
        <h3 class="ld-h"><span>3</span> Mehnat faoliyati</h3>
        <label>Qisqacha matn <small>(ixtiyoriy)</small></label>
        <textarea name="career_intro" rows="2" placeholder="Masalan: 17.09.2024 dan hozirgacha markaz direktori lavozimida faoliyat yuritib kelmoqda."><?= h($L['career_intro']) ?></textarea>

        <label>Faoliyat bosqichlari</label>
        <p class="ld-note">Yil yoki davrni chap katakka, ish joyi va lavozimni o'ng katakka yozing. Yil bo'sh qolsa — oddiy band bo'lib chiqadi.</p>
        <div class="ld-rows" id="careerRows">
          <?php foreach ($career as $r): ?>
            <div class="ld-row">
              <input type="text" name="career_y[]" value="<?= h($r['y'] ?? '') ?>" placeholder="Yil (ixtiyoriy)" class="y">
              <input type="text" name="career_t[]" value="<?= h($r['t'] ?? '') ?>" placeholder="Viloyat xalq ta'limi boshqarmasi metodisti" class="t">
              <div class="ld-rbtn">
                <button type="button" data-act="up" title="Yuqoriga">↑</button>
                <button type="button" data-act="down" title="Pastga">↓</button>
                <button type="button" data-act="del" title="O'chirish" class="del">✕</button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="ld-rowbar">
          <button type="button" class="btn sm" id="addRow">+ Qator qo'shish</button>
          <details class="ld-bulk">
            <summary>Matndan tez to'ldirish</summary>
            <p class="ld-note">Har bir bosqichni yangi qatordan yozing, yilni ikki nuqta bilan ajrating:<br><code>2002: Qarshi serjantlar tayyorlash maktabi</code></p>
            <textarea id="bulkText" rows="5"></textarea>
            <button type="button" class="btn sm gold" id="bulkBtn">Qatorlarga qo'shish</button>
          </details>
        </div>
      </section>

      <section class="card ld-sec">
        <h3 class="ld-h"><span>4</span> Asosiy vazifalari</h3>
        <p class="ld-note">Har bir vazifani yangi qatordan yozsangiz — saytda ro'yxat bo'lib chiqadi. Bitta qator bo'lsa — oddiy matn.</p>
        <textarea name="duties" rows="6" placeholder="Hududiy markaz faoliyatiga umumiy rahbarlik qilish&#10;Xodimlarni lavozimga tayinlash va ozod etish"><?= h($L['duties']) ?></textarea>
      </section>
    </div>

    <!-- ===== O'ng ustun ===== -->
    <aside class="ld-side">
      <section class="card ld-sec">
        <h3 class="ld-h"><span>5</span> Rasm</h3>
        <div class="ld-photo" id="photoBox">
          <img src="<?= h($img ?: '') ?>" alt="" id="photoPrev" <?= $img ? '' : 'hidden' ?>>
          <div class="ph-empty" id="photoEmpty" <?= $img ? 'hidden' : '' ?>>Rasm yo'q</div>
          <span class="ph-src" id="photoSrc" <?= $img ? '' : 'hidden' ?>><?= $img ? (preg_match('~^https?://~i', (string)$L['photo']) ? 'Tashqi havola' : 'Joriy rasm') : '' ?></span>
        </div>

        <div class="mp-tabs" role="tablist">
          <button type="button" class="mp-tab" data-src="file" title="Kompyuterdan yuklash"><b>💻</b>Kompyuterdan</button>
          <button type="button" class="mp-tab" data-src="lib" title="Saytdagi rasmlardan tanlash"><b>🖼</b>Saytdan</button>
          <button type="button" class="mp-tab" data-src="url" title="Tashqi havola (URL)"><b>🔗</b>Havola</button>
        </div>

        <input type="file" name="photo" accept="image/*" id="photoInput" hidden>
        <input type="hidden" name="photo_pick" id="photoPick">
        <div class="mp-url" id="urlBox" hidden>
          <input type="text" name="photo_url" id="photoUrl" placeholder="https://qashqadaryopmm.uz/.../rasm.jpg"
                 value="<?= preg_match('~^https?://~i', (string)$L['photo']) ? h($L['photo']) : '' ?>" data-initial="<?= preg_match('~^https?://~i', (string)$L['photo']) ? h($L['photo']) : '' ?>">
          <small id="urlMsg">Rasm manzilini qo'ying — pastda ko'rinadi.</small>
        </div>

        <p class="ld-note">Tik (portret) rasm tavsiya etiladi, masalan 400×500.</p>
        <label class="ld-check" id="removeWrap" <?= $img ? '' : 'hidden' ?>><input type="checkbox" name="remove_photo" value="1" id="removePhoto"> Rasmni olib tashlash</label>
      </section>

      <section class="card ld-sec">
        <h3 class="ld-h"><span>6</span> Ko'rinish</h3>
        <label class="ld-check"><input type="checkbox" name="active" <?= $L['active'] ? 'checked' : '' ?>> Saytda ko'rinsin</label>
        <label class="ld-check"><input type="checkbox" name="is_head" <?= $L['is_head'] ? 'checked' : '' ?>> Birinchi rahbar (oltin ramka bilan ajratiladi)</label>
      </section>

      <div class="ld-save">
        <button class="btn" type="submit">Saqlash</button>
        <a href="leaders.php" class="btn gray">Bekor qilish</a>
      </div>
    </aside>
  </div>
</form>

<template id="rowTpl">
  <div class="ld-row">
    <input type="text" name="career_y[]" placeholder="Yil (ixtiyoriy)" class="y">
    <input type="text" name="career_t[]" placeholder="Ish joyi va lavozimi" class="t">
    <div class="ld-rbtn">
      <button type="button" data-act="up" title="Yuqoriga">↑</button>
      <button type="button" data-act="down" title="Pastga">↓</button>
      <button type="button" data-act="del" title="O'chirish" class="del">✕</button>
    </div>
  </div>
</template>

<script>
(function () {
  var box = document.getElementById('careerRows');
  var tpl = document.getElementById('rowTpl');

  function addRow(y, t) {
    var row = tpl.content.firstElementChild.cloneNode(true);
    row.querySelector('.y').value = y || '';
    row.querySelector('.t').value = t || '';
    box.appendChild(row);
    return row;
  }

  document.getElementById('addRow').addEventListener('click', function () {
    addRow().querySelector('.y').focus();
  });

  box.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-act]');
    if (!b) return;
    var row = b.closest('.ld-row');
    if (b.dataset.act === 'up' && row.previousElementSibling) box.insertBefore(row, row.previousElementSibling);
    if (b.dataset.act === 'down' && row.nextElementSibling) box.insertBefore(row.nextElementSibling, row);
    if (b.dataset.act === 'del') {
      var filled = row.querySelector('.y').value || row.querySelector('.t').value;
      if (!filled || confirm('Bu qator o‘chirilsinmi?')) {
        row.remove();
        if (!box.children.length) addRow();
      }
    }
  });

  // Enter bosilganda forma yuborilmasin — yangi qator ochilsin
  box.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && e.target.classList.contains('t')) {
      e.preventDefault();
      var row = e.target.closest('.ld-row');
      var n = addRow();
      box.insertBefore(n, row.nextElementSibling);
      n.querySelector('.y').focus();
    }
  });

  document.getElementById('bulkBtn').addEventListener('click', function () {
    var ta = document.getElementById('bulkText');
    var lines = ta.value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
    if (!lines.length) return;
    // bo'sh qatorlarni olib tashlaymiz
    Array.prototype.slice.call(box.children).forEach(function (r) {
      if (!r.querySelector('.y').value && !r.querySelector('.t').value) r.remove();
    });
    lines.forEach(function (l) {
      l = l.replace(/^[-•*–]\s*/, '');
      var m = l.match(/^([^:]{1,25}):\s*(.+)$/);
      if (m) addRow(m[1].trim(), m[2].trim()); else addRow('', l);
    });
    ta.value = '';
    ta.closest('details').open = false;
  });

})();

// ===== Rasm: kompyuter / sayt kutubxonasi / tashqi havola =====
(function () {
  var inp  = document.getElementById('photoInput'),
      pick = document.getElementById('photoPick'),
      url  = document.getElementById('photoUrl'),
      urlBox = document.getElementById('urlBox'),
      urlMsg = document.getElementById('urlMsg'),
      prev = document.getElementById('photoPrev'),
      empty = document.getElementById('photoEmpty'),
      srcLbl = document.getElementById('photoSrc'),
      rm = document.getElementById('removePhoto');

  function show(src, label) {
    prev.src = src; prev.hidden = false; empty.hidden = true;
    srcLbl.textContent = label; srcLbl.hidden = false;
    rm.checked = false;
  }
  // Bitta manba tanlanganda qolganlari tozalanadi
  function clearOthers(keep) {
    if (keep !== 'file') inp.value = '';
    if (keep !== 'lib')  pick.value = '';
    if (keep !== 'url')  url.value = '';
  }

  document.querySelectorAll('.mp-tab').forEach(function (b) {
    b.addEventListener('click', function () {
      var s = b.dataset.src;
      urlBox.hidden = s !== 'url';
      document.querySelectorAll('.mp-tab').forEach(function (x) { x.classList.toggle('on', x === b); });
      if (s === 'file') inp.click();
      if (s === 'lib') MediaPicker.open(function (item) {
        clearOthers('lib'); pick.value = item.name; show(item.url, 'Saytdan: ' + item.name);
      });
      if (s === 'url') url.focus();
    });
  });

  inp.addEventListener('change', function () {
    if (!inp.files[0]) return;
    clearOthers('file');
    show(URL.createObjectURL(inp.files[0]), 'Kompyuterdan: ' + inp.files[0].name);
  });

  var t;
  url.addEventListener('input', function () {
    clearTimeout(t);
    t = setTimeout(function () {
      var v = url.value.trim();
      if (!v) { urlMsg.textContent = 'Rasm manzilini qo\u2018ying \u2014 pastda ko\u2018rinadi.'; urlMsg.className = ''; return; }
      if (!/^https?:\/\//i.test(v)) { urlMsg.textContent = 'Havola http:// yoki https:// bilan boshlanishi kerak'; urlMsg.className = 'bad'; return; }
      var test = new Image();
      test.onload = function () {
        clearOthers('url'); show(v, 'Tashqi havola');
        urlMsg.textContent = '\u2713 Rasm topildi (' + test.naturalWidth + '\u00d7' + test.naturalHeight + ')'; urlMsg.className = 'ok';
      };
      test.onerror = function () { urlMsg.textContent = 'Bu havoladan rasm ochilmadi — manzilni tekshiring'; urlMsg.className = 'bad'; };
      test.src = v;
    }, 400);
  });

  rm.addEventListener('change', function () {
    if (rm.checked) { clearOthers(''); prev.hidden = true; empty.hidden = false; srcLbl.hidden = true; }
  });
})();
</script>
<script>window.MEDIA_URL = 'media.php';</script>
<script src="<?= BASE_URL ?>/assets/js/media-picker.js?v=1"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
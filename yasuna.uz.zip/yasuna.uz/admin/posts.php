<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/queries.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    $st = db()->prepare('SELECT image FROM posts WHERE id = ?');
    $st->execute([(int)$_POST['delete_id']]);
    if ($img = $st->fetchColumn()) delete_upload($img);
    db()->prepare('DELETE FROM posts WHERE id = ?')->execute([(int)$_POST['delete_id']]);
    flash_set('Yangilik o\'chirildi');
    redirect('posts.php');
}

$catFilter = (int)($_GET['cat'] ?? 0);
$statusFilter = trim($_GET['status'] ?? '');
$q = trim($_GET['q'] ?? '');

$where = []; $params = [];
if ($catFilter) { $where[] = 'p.category_id = ?'; $params[] = $catFilter; }
if ($statusFilter === 'draft') $where[] = "p.status='draft'";
elseif ($statusFilter === 'published') $where[] = "p.status='published'";
if ($q !== '') { $where[] = 'p.title LIKE ?'; $params[] = '%'.$q.'%'; }
$wh = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$st = db()->prepare("SELECT p.*, c.name AS cat FROM posts p LEFT JOIN categories c ON c.id=p.category_id $wh ORDER BY p.created_at DESC");
$st->execute($params);
$rows = $st->fetchAll();
$cats = db()->query('SELECT id,name FROM categories ORDER BY sort_order,name')->fetchAll();

$active = 'posts';
$page_title = 'Yangiliklar';
require __DIR__ . '/includes/header.php';
?>
<div class="bar">
  <div class="bar-left">
    <a href="post-edit.php" class="btn">+ Yangi qo'shish</a>
  </div>
  <form class="bar-right" method="get">
    <input type="search" name="q" placeholder="Qidirish…" value="<?= h($q) ?>" class="i-sm">
    <select name="cat" class="i-sm">
      <option value="0">Barcha kategoriyalar</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $catFilter===(int)$c['id']?'selected':'' ?>><?= h($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" class="i-sm">
      <option value="">Barcha holatlar</option>
      <option value="published" <?= $statusFilter==='published'?'selected':'' ?>>E'lon qilingan</option>
      <option value="draft" <?= $statusFilter==='draft'?'selected':'' ?>>Qoralama</option>
    </select>
    <button class="btn gray sm">Filtrlash</button>
  </form>
</div>

<?php if ($f = flash_get()): ?><div class="flash"><?= h($f) ?></div><?php endif; ?>

<div class="card">
  <table>
    <tr><th>Rasm</th><th>Sarlavha</th><th>Kategoriya</th><th>Holat</th><th>Ko'rishlar</th><th>Sana</th><th style="width:270px;text-align:right">Amal</th></tr>
    <?php foreach ($rows as $p): ?>
    <tr>
      <td style="width:70px"><?php if ($p['image']): ?><img src="<?= UPLOAD_URL . h($p['image']) ?>" class="timg" alt=""><?php else: ?><div class="timg noimg">—</div><?php endif; ?></td>
      <td><a href="post-edit.php?id=<?= (int)$p['id'] ?>" class="link"><?= h($p['title']) ?></a></td>
      <td><?= h($p['cat'] ?? '—') ?></td>
      <td><?= $p['status']==='published' ? '<span class="tag green">E\'lon</span>' : '<span class="tag gray">Qoralama</span>' ?></td>
      <td><?= (int)$p['views'] ?></td>
      <td><?= uzdate($p['created_at']) ?></td>
      <td class="acts">
        <div class="row-actions">
          <a href="<?= post_url($p) ?>" target="_blank" class="btn sm gray" title="Saytda ko'rish">Ko'rish</a>
          <a href="post-edit.php?id=<?= (int)$p['id'] ?>" class="btn sm" title="Ushbu yangilikni tahrirlash">Tahrirlash</a>
          <form method="post" onsubmit="return confirm('«<?= h(addslashes($p['title'])) ?>» o\'chirilsinmi? Bu amalni bekor qilib bo\'lmaydi.')">
            <?= csrf_field() ?>
            <input type="hidden" name="delete_id" value="<?= (int)$p['id'] ?>">
            <button class="btn sm red" title="Ushbu yangilikni o'chirish">O'chirish</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="7" style="color:#94a3b8">Hech qanday yangilik topilmadi</td></tr><?php endif; ?>
  </table>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>

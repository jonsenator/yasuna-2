<?php
/**
 * yasuna.uz — Asosiy konfiguratsiya
 * Ma'lumotlar bazasi sozlamalari va sayt sozlamalari shu yerda.
 */

// ==== Ma'lumotlar bazasi (aaPanel'da yaratgan DB ma'lumotlari) ====
define('DB_HOST', getenv('YASUNA_DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('YASUNA_DB_NAME') ?: 'sql_yasuna_uz');
define('DB_USER', getenv('YASUNA_DB_USER') ?: 'sql_yasuna_uz');
define('DB_PASS', getenv('YASUNA_DB_PASS') ?: 'd2df173034003');
define('DB_CHARSET', 'utf8mb4');

// ==== Sessiya ====
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
date_default_timezone_set('Asia/Tashkent');

// ==== BASE_URL avtomatik aniqlash (localhost / hosting da ishlaydi) ====
if (!defined('BASE_URL')) {
    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
           || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'
           || (($_SERVER['SERVER_PORT'] ?? '') == 443);
    $scheme = $https ? 'https' : 'http';
    $host   = preg_replace('~[^a-zA-Z0-9.\-:]~', '', $_SERVER['HTTP_HOST'] ?? '') ?: 'yasuna.uz';
    $base   = $scheme . '://' . $host;

    // Ayrim yechimlarda sub-katalogda turishi mumkin
    $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    // faqat bir bosqich chiqarib tashlaymiz (index.php/admin ichidagi fayllar uchun)
    if (preg_match('#/admin/?$#', $scriptDir) || preg_match('#/admin#', $scriptDir)) {
        $scriptDir = preg_replace('#/admin$#', '', $scriptDir);
    }
    define('BASE_URL', $base . $scriptDir);
}

// ==== Fayl papkalari ====
define('UPLOAD_DIR', __DIR__ . '/assets/uploads/');
define('UPLOAD_URL', BASE_URL . '/assets/uploads/');
define('ADMIN_URL',  BASE_URL . '/admin');

// Konstanta aniqlangani uchun admin tarmoqida ham ishlaydi
define('IS_ADMIN', strpos($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') !== false);
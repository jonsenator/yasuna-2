<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';

$slug = trim($_GET['slug'] ?? '');
$cat  = $slug !== '' ? get_category_by_slug($slug) : null;

if (!$cat) {
    http_response_code(404);
    $meta_title = 'Topilmadi';
    require __DIR__ . '/includes/header.php';
    echo '<section class="wrap section"><div class="empty"><h3>Bo\'lim topilmadi</h3><a class="btn-cta" href="' . BASE_URL . '/">Bosh sahifaga &rarr;</a></div></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$perPage = 12;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;
$posts   = get_posts_by_category((int)$cat['id'], $perPage, $offset);
$totalC  = count_posts_by_category((int)$cat['id']);
$pages   = max(1, (int)ceil($totalC / $perPage));

$meta_title = $cat['name'] . ' — ' . setting('site_name', 'PMM');
$meta_desc  = $cat['description'] ?: $meta_title;
require __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="wrap">
    <div class="breadcrumb">
      <a href="<?= BASE_URL ?>/">Bosh sahifa</a>
      <?php $pc = $cat['parent_id'] ? get_category_by_id((int)$cat['parent_id']) : null;
        if ($pc): ?><span>/</span><a href="<?= category_url($pc) ?>"><?= h($pc['name']) ?></a><?php endif; ?>
      <span>/</span><span><?= h($cat['name']) ?></span>
    </div>
    <h1><?= h($cat['name']) ?></h1>
    <?php if (!empty($cat['description'])): ?><p class="page-sub"><?= h($cat['description']) ?></p><?php endif; ?>
  </div>
</div>

<section class="wrap section">
  <?php if ($posts): ?>
    <div class="grid">
      <?php foreach ($posts as $p): $img = post_image_url($p['image']); ?>
        <a class="card reveal" href="<?= post_url($p) ?>">
          <div class="thumb">
            <?php if ($img): ?><img src="<?= h($img) ?>" alt="<?= h($p['title']) ?>" loading="lazy"><?php else: ?><div class="noimg">PMM</div><?php endif; ?>
            <?php if (!empty($p['cat'])): ?><span class="badge"><?= h($p['cat']) ?></span><?php endif; ?>
          </div>
          <div class="body">
            <div class="date"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg><?= uzdate($p['created_at']) ?></div>
            <h3><?= h($p['title']) ?></h3>
            <p><?= h(make_excerpt($p)) ?></p>
            <span class="readmore">Batafsil &rarr;</span>
          </div>
        </a>
      <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a href="?slug=<?= urlencode($slug) ?>&page=<?= $page-1 ?>">&lsaquo;</a><?php endif; ?>
        <?php for ($n=1;$n<=$pages;$n++): ?>
          <?php if ($n===$page): ?><span class="cur"><?= $n ?></span>
          <?php else: ?><a href="?slug=<?= urlencode($slug) ?>&page=<?= $n ?>"><?= $n ?></a><?php endif; ?>
        <?php endfor; ?>
        <?php if ($page < $pages): ?><a href="?slug=<?= urlencode($slug) ?>&page=<?= $page+1 ?>">&rsaquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div class="empty"><h3>Bu bo'limda hozircha yangilik yo'q</h3><a class="btn-cta" href="<?= BASE_URL ?>/">Bosh sahifaga &rarr;</a></div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>

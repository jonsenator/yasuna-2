<?php
/**
 * Umumiy yordamchi funksiyalar (XSS, URL, sana, fayl, va h.k.)
 */

// ---------- XSS himoyasi ----------
function h($s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// ---------- Slug (URL uchun, lotin+kirill) ----------
function slugify(string $text): string {
    $text = mb_strtolower(trim($text), 'UTF-8');
    // O'zbekcha tutuq belgilari (o', g', ъ) — olib tashlanadi: "O'zbekiston" -> "ozbekiston"
    $text = str_replace(["'", '`', "\u{2018}", "\u{2019}", "\u{201B}", "\u{02BB}", "\u{02BC}", "\u{2032}"], '', $text);
    $map = [
        "o\xE2\x80\xBB" => 'o', "g\xE2\x80\xBB" => 'g',
        "\xE2\x80\xB2" => '', "\xCA\xBC" => '', "\xE2\x80\x99" => '',
        "\xD0\xB0"=>'a',"\xD0\xB1"=>'b',"\xD0\xB2"=>'v',"\xD0\xB3"=>'g',"\xD0\xB4"=>'d',
        "\xD0\xB5"=>'e',"\xD0\xB6"=>'j',"\xD0\xB7"=>'z',"\xD0\xB8"=>'i',"\xD0\xB9"=>'y',
        "\xD0\xBA"=>'k',"\xD0\xBB"=>'l',"\xD0\xBC"=>'m',"\xD0\xBD"=>'n',"\xD0\xBE"=>'o',
        "\xD0\xBF"=>'p',"\xD1\x80"=>'r',"\xD1\x81"=>'s',"\xD1\x82"=>'t',"\xD1\x83"=>'u',
        "\xD1\x84"=>'f',"\xD1\x85"=>'x',"\xD1\x86"=>'ts',"\xD1\x87"=>'ch',"\xD1\x88"=>'sh',
        "\xD1\x89"=>'sh',"\xD1\x8A"=>'',"\xD1\x8C"=>'',"\xD1\x8B"=>'i',"\xD1\x8D"=>'e',
        "\xD1\x8E"=>'yu',"\xD1\x8F"=>'ya',
        "\xD2\x93"=>'g',"\xD2\x9B"=>'q',"\xD2\xB3"=>'h',"\xD1\x9E"=>'o',
    ];
    $text = strtr($text, $map);
    $text = preg_replace('~[^a-z0-9]+~u', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? $text : 'n-' . time();
}

// ---------- Redirect ----------
function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

// ---------- CSRF ----------
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}
function csrf_check(): void {
    $sent = (string)($_POST['csrf'] ?? '');
    $real = (string)($_SESSION['csrf'] ?? '');
    if ($real === '' || !hash_equals($real, $sent)) {
        http_response_code(419);
        exit('CSRF xato — sahifani yangilang va qayta urinib ko\'ring.');
    }
}

// ---------- Sana (uz) ----------
function uzdate($dt): string {
    $months = [1=>'Yanvar',2=>'Fevral',3=>'Mart',4=>'Aprel',5=>'May',6=>'Iyun',
               7=>'Iyul',8=>'Avgust',9=>'Sentabr',10=>'Oktabr',11=>'Noyabr',12=>'Dekabr'];
    $t = is_numeric($dt) ? $dt : strtotime($dt);
    return (int)date('d', $t) . ' ' . $months[(int)date('n', $t)] . ', ' . date('Y', $t);
}
function uzdatetime($dt): string {
    return uzdate($dt) . ', ' . date('H:i', is_numeric($dt) ? $dt : strtotime($dt));
}

// ---------- Flash xabar ----------
function flash_set(string $msg): void { $_SESSION['flash'] = $msg; }
function flash_get(): string {
    if (!empty($_SESSION['flash'])) { $m = $_SESSION['flash']; unset($_SESSION['flash']); return $m; }
    return '';
}

// ---------- Fayl yuklash ----------
function upload_image(array $file): array {
    // returns [ok, name|error]
    if (empty($file['name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return [false, 'Rasm tanlanmagan'];
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp','gif'], true)) {
        return [false, 'Rasm formati noto\'g\'ri (jpg, jpeg, png, webp, gif)'];
    }
    if (($file['size'] ?? 0) > 10 * 1024 * 1024) {
        return [false, 'Rasm hajmi 10 MB dan oshmasligi kerak'];
    }
    if (@getimagesize($file['tmp_name']) === false) {
        return [false, 'Yuklangan fayl rasm emas'];
    }
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);
    $newName = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $newName)) {
        return [false, 'Rasm saqlashda xatolik'];
    }
    return [true, $newName];
}

function delete_upload(?string $name): void {
    if ($name) @unlink(UPLOAD_DIR . $name);
}

// ---------- Rich text / xavfsiz HTML ----------
/**
 * Admin matnini ko'rsatishda foydalaniladi.
 * Xavfli teglar/skriptlar tozalanadi, o'zgaruvchan teglar ruxsat etiladi.
 */
function safe_html(?string $html): string {
    if ($html === null || $html === '') return '';

    // ---- 1. Xavfsizlik: skript, style, iframe va on* atributlarini olib tashlash
    $html = preg_replace('~<script\b[^>]*>.*?</script>~is', '', $html);
    $html = preg_replace('~<style\b[^>]*>.*?</style>~is', '', $html);
    $html = preg_replace('~on\w+\s*=\s*(".*?"|\'.*?\'|[^\s>]*)~i', '', $html);
    $html = preg_replace('~javascript\s*:~i', '', $html);

    // ---- 2. Matnni to'g'ri paragraflarga ajratish
    return autop_html($html);
}

/**
 * Blok teglarga o'ralmagan "yalang'och" matnni <p> ga o'raydi.
 *
 * Muammo: admin muharriridan kelgan matnda ba'zi jumlalar hech qanday
 * tegga o'ralmagan bo'lib, faqat yangi qator (\n) bilan ajratilgan bo'ladi.
 * HTML'da \n oddiy bo'shliqqa aylanadi — natijada jumlalar qo'shilib ketadi.
 * Bu funksiya shunday matn bo'laklarini topib <p> ichiga oladi.
 */
function autop_html(string $html): string {
    // Blok teglar — bular o'z qatorini oladi, ichiga <p> qo'yilmaydi
    $block = 'address|article|aside|blockquote|details|div|dl|dd|dt|fieldset|figcaption|figure|footer|form|h1|h2|h3|h4|h5|h6|header|hr|li|main|nav|ol|p|pre|section|table|tbody|td|tfoot|th|thead|tr|ul';

    // Teglar va matnni bo'laklarga ajratamiz
    $parts = preg_split('~(<[^>]+>)~', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);

    $out    = '';
    $buffer = '';
    $depth  = 0;   // nechta blok teg ichidamiz

    // To'plangan yalang'och matnni <p> ga o'rab chiqarish
    $flush = function () use (&$buffer, &$out) {
        $t = trim(preg_replace('~\s+~u', ' ', $buffer));
        $buffer = '';
        if ($t === '') return;
        // Faqat teg qoldig'i bo'lsa (masalan yolg'iz <br>) — o'ramaymiz
        if (trim(strip_tags($t)) === '' && stripos($t, '<img') === false) return;
        $out .= '<p>' . $t . '</p>';
    };

    foreach ($parts as $part) {
        if ($part === '') continue;

        // ---- Bu teg emas, oddiy matn ----
        if ($part[0] !== '<') {
            if ($depth > 0) {
                $out .= $part;          // blok ichida — tegmaymiz
            } else {
                // Bo'sh qator (\n\n) — yangi paragraf boshlanishi
                $chunks = preg_split("~\n[ \t]*\n~", $part);
                foreach ($chunks as $ci => $chunk) {
                    if ($ci > 0) $flush();   // bo'sh qatorda paragrafni yopamiz
                    $buffer .= $chunk;
                }
            }
            continue;
        }

        // ---- Bu teg ----
        $isBlock = (bool)preg_match('~^</?(?:' . $block . ')\b~i', $part);
        $isClose = str_starts_with($part, '</');
        $isSelf  = (bool)preg_match('~/>$~', $part)
                || (bool)preg_match('~^<(?:br|hr|img|input|meta|link|source)\b~i', $part);

        if ($isBlock && !$isSelf) {
            if ($isClose) {
                $depth = max(0, $depth - 1);
                $out .= $part;
            } else {
                $flush();               // blok boshlanishidan oldin buferni yopamiz
                $out .= $part;
                $depth++;
            }
            continue;
        }

        // Inline teg (<strong>, <span>, <a>, <br>, <img> ...)
        if ($depth > 0) {
            $out .= $part;
        } else {
            $buffer .= $part;
        }
    }
    $flush();

    // Tozalash
    $out = preg_replace('~<p>\s*</p>~i', '', $out);
    $out = preg_replace('~(<br\s*/?>\s*){3,}~i', '<br><br>', $out);
    $out = preg_replace('~<br\s*/?>\s*(</p>)~i', '\\1', $out);

    return $out;
}

// ---------- Rasm manbalari (kutubxona / tashqi havola) ----------
/** Kutubxonadan tanlangan fayl nomini tekshiradi: faqat assets/uploads ichidagi mavjud rasm */
function valid_library_image(string $name): ?string {
    $name = basename(trim($name));
    if ($name === '' || $name[0] === '.') return null;
    if (!in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), ['jpg','jpeg','png','webp','gif'], true)) return null;
    return is_file(UPLOAD_DIR . $name) ? $name : null;
}

/** Tashqi rasm havolasini tekshiradi (faqat http/https) */
function valid_image_url(string $url): ?string {
    $url = trim($url);
    if ($url === '' || mb_strlen($url) > 255) return null;
    if (!filter_var($url, FILTER_VALIDATE_URL)) return null;
    $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
    return in_array($scheme, ['http', 'https'], true) ? $url : null;
}

/** Fayl saytning boshqa joyida ishlatilyaptimi? (o'chirishdan oldin tekshirish uchun) */
function upload_in_use(string $name, string $exceptTable = '', int $exceptId = 0): bool {
    if ($name === '' || preg_match('~[/:]~', $name)) return true; // tashqi havola — o'chirilmaydi
    $like = '%' . $name . '%';
    $checks = [
        ['posts',   "SELECT COUNT(*) FROM posts WHERE (image = ? OR content LIKE ?) AND id <> ?", [$name, $like]],
        ['slider',  "SELECT COUNT(*) FROM slider WHERE image = ? AND id <> ?", [$name]],
        ['pages',   "SELECT COUNT(*) FROM pages WHERE content LIKE ? AND id <> ?", [$like]],
        ['leaders', "SELECT COUNT(*) FROM leaders WHERE photo = ? AND id <> ?", [$name]],
    ];
    foreach ($checks as [$table, $sql, $params]) {
        try {
            $params[] = $table === $exceptTable ? $exceptId : 0;
            $st = db()->prepare($sql);
            $st->execute($params);
            if ((int)$st->fetchColumn() > 0) return true;
        } catch (Throwable $e) { /* jadval yo'q bo'lishi mumkin */ }
    }
    return false;
}

// ---------- Sayt logotipi ----------
/**
 * Logotip manzili: 1) Sozlamalar → Logotip (site_logo)  2) assets/logo.png fayli  3) yo'q (null)
 */
function site_logo_url(): ?string {
    $v = trim((string)setting('site_logo'));
    if ($v !== '') {
        if (preg_match('~^https?://~i', $v)) return $v;
        if (is_file(UPLOAD_DIR . basename($v))) return UPLOAD_URL . rawurlencode(basename($v));
    }
    $f = __DIR__ . '/assets/logo.png';
    return is_file($f) ? BASE_URL . '/assets/logo.png?v=' . filemtime($f) : null;
}
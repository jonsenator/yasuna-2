<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';

$q    = trim($_GET['q'] ?? '');
$perPage = 12;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;
$posts = [];
$total = 0;
$pages = 1;
if ($q !== '') {
    $posts = search_posts($q, $perPage, $offset);
    $total = count_search_posts($q);
    $pages = max(1, (int)ceil($total / $perPage));
}

$meta_title = 'Qidiruv — ' . setting('site_name', 'PMM');
require __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="wrap">
    <div class="breadcrumb"><a href="<?= BASE_URL ?>/">Bosh sahifa</a><span>/</span><span>Qidiruv</span></div>
    <h1>Qidiruv natijalari</h1>
  </div>
</div>

<div class="wrap section">
  <form action="<?= BASE_URL ?>/search.php" method="get" class="search-form big">
    <input type="search" name="q" placeholder="Qidirish…" value="<?= h($q) ?>">
    <button type="submit">Qidirish</button>
  </form>

  <?php if ($q === ''): ?>
    <div class="empty"><h3>Qidiruv so'zini kiriting</h3></div>
  <?php elseif (!$posts): ?>
    <div class="empty"><h3>"<?= h($q) ?>" bo'yicha hech narsa topilmadi</h3></div>
  <?php else: ?>
    <p class="result-info">"<?= h($q) ?>" bo'yicha <?= $total ?> ta natija topildi.</p>
    <div class="grid">
      <?php foreach ($posts as $p): $img = post_image_url($p['image']); ?>
        <a class="card reveal" href="<?= post_url($p) ?>">
          <div class="thumb">
            <?php if ($img): ?><img src="<?= h($img) ?>" alt="<?= h($p['title']) ?>" loading="lazy"><?php else: ?><div class="noimg">PMM</div><?php endif; ?>
            <?php if (!empty($p['cat'])): ?><span class="badge"><?= h($p['cat']) ?></span><?php endif; ?>
          </div>
          <div class="body">
            <div class="date"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg><?= uzdate($p['created_at']) ?></div>
            <h3><?= h($p['title']) ?></h3>
            <p><?= h(make_excerpt($p)) ?></p>
            <span class="readmore">Batafsil &rarr;</span>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <?php if ($pages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a href="?q=<?= urlencode($q) ?>&page=<?= $page-1 ?>">&lsaquo;</a><?php endif; ?>
        <?php for ($n=1;$n<=$pages;$n++): ?>
          <?php if ($n===$page): ?><span class="cur"><?= $n ?></span>
          <?php else: ?><a href="?q=<?= urlencode($q) ?>&page=<?= $n ?>"><?= $n ?></a><?php endif; ?>
        <?php endfor; ?>
        <?php if ($page < $pages): ?><a href="?q=<?= urlencode($q) ?>&page=<?= $page+1 ?>">&rsaquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

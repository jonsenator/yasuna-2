<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';

$sent = false; $errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '')      $errors[] = 'Ismingizni kiriting.';
    if ($message === '')   $errors[] = 'Xabar matnini kiriting.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email noto\'g\'ri.';

    if (mb_strlen($name) > 128 || mb_strlen($email) > 128 || mb_strlen($phone) > 64
        || mb_strlen($subject) > 255 || mb_strlen($message) > 5000) {
        $errors[] = 'Maydonlardan biri juda uzun.';
    }
    // Spam himoyasi: yashirin maydon (botlar to'ldiradi) + 60 soniyada bitta xabar
    $isBot = trim($_POST['website'] ?? '') !== '';
    if (!$errors && !$isBot && time() - (int)($_SESSION['contact_last'] ?? 0) < 60) {
        $errors[] = 'Iltimos, keyingi xabarni biroz kutib yuboring.';
    }

    if (!$errors && $isBot) {
        $sent = true; // botga "yuborildi" deb ko'rsatamiz, bazaga yozmaymiz
    } elseif (!$errors) {
        $_SESSION['contact_last'] = time();
        $st = db()->prepare('INSERT INTO messages (name, email, phone, subject, message) VALUES (?,?,?,?,?)');
        $st->execute([$name, $email, $phone, $subject, $message]);
        $sent = true;
    }
}

$meta_title = 'Bog\'lanish — ' . setting('site_name', 'PMM');
require __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="wrap">
    <div class="breadcrumb"><a href="<?= BASE_URL ?>/">Bosh sahifa</a><span>/</span><span>Bog'lanish</span></div>
    <h1>Biz bilan bog'laning</h1>
  </div>
</div>

<div class="wrap contact-page">
  <div class="contact-info">
    <h3>Bog'lanish ma'lumotlari</h3>
    <div class="cinfo-row">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0Z"/><circle cx="12" cy="10" r="3"/></svg>
      <div><strong>Manzil</strong><span><?= h(setting('address')) ?></span></div>
    </div>
    <div class="cinfo-row">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/></svg>
      <div><strong>Telefon</strong><a href="tel:<?= h(preg_replace('/\s+/','',setting('phone'))) ?>"><?= h(setting('phone')) ?></a></div>
    </div>
    <div class="cinfo-row">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>
      <div><strong>Email</strong><a href="mailto:<?= h(setting('email')) ?>"><?= h(setting('email')) ?></a></div>
    </div>
    <div class="cinfo-row">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
      <div><strong>Ish vaqti</strong><span><?= h(setting('working_hours')) ?></span></div>
    </div>
  </div>

  <div class="contact-form">
    <?php if ($sent): ?>
      <div class="flash ok">Xabaringiz qabul qilindi. Rahmat!</div>
    <?php else: ?>
      <?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>
      <form method="post">
        <?= csrf_field() ?>
        <div style="position:absolute;left:-9999px" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
        <div class="f2">
          <div><label>Ismingiz *</label><input type="text" name="name" required value="<?= h($_POST['name'] ?? '') ?>"></div>
          <div><label>Telefon</label><input type="text" name="phone" value="<?= h($_POST['phone'] ?? '') ?>"></div>
        </div>
        <div class="f2">
          <div><label>Email</label><input type="email" name="email" value="<?= h($_POST['email'] ?? '') ?>"></div>
          <div><label>Mavzu</label><input type="text" name="subject" value="<?= h($_POST['subject'] ?? '') ?>"></div>
        </div>
        <label>Xabar *</label>
        <textarea name="message" rows="6" required><?= h($_POST['message'] ?? '') ?></textarea>
        <button class="btn-cta" type="submit">Yuborish &rarr;</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
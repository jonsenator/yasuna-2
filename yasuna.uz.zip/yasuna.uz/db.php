<?php
require_once __DIR__ . '/config.php';

/**
 * PDO ulanish (singleton)
 */
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            exit('Ma\'lumotlar bazasiga ulanishda xatolik. Sozlamalarni tekshiring. (' . DB_NAME . ')');
        }
    }
    return $pdo;
}

/**
 * Sozlama o'qish (bitta ulanishda bir marta yuklaydi)
 */
function setting(string $key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query('SELECT skey, svalue FROM settings') as $r) {
                $cache[$r['skey']] = $r['svalue'];
            }
        } catch (Throwable $e) {
            // jadval hali mavjud emas (install'dan oldin)
        }
    }
    return $cache[$key] ?? $default;
}

/**
 * Sozlama saqlash (yoki yangilash)
 */
function save_setting(string $key, $value): void {
    $st = db()->prepare('INSERT INTO settings (skey, svalue) VALUES (?,?)
                         ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)');
    $st->execute([$key, (string)$value]);
}

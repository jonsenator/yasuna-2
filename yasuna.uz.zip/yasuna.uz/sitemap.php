<?php
// Oddiy XML sitemap (SEO)
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';

header('Content-Type: application/xml; charset=utf-8');
$posts = db()->query("SELECT slug, updated_at FROM posts WHERE status='published' ORDER BY created_at DESC")->fetchAll();
$cats  = db()->query("SELECT slug FROM categories")->fetchAll();
$pages = db()->query("SELECT slug, updated_at FROM pages WHERE status='published'")->fetchAll();
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
$last = date('c');
echo "  <url><loc>" . BASE_URL . "/</loc><lastmod>{$last}</lastmod><changefreq>daily</changefreq><priority>1.0</priority></url>\n";
foreach ($posts as $p) {
    $m = $p['updated_at'] ? date('c', strtotime($p['updated_at'])) : $last;
    echo "  <url><loc>" . BASE_URL . "/post.php?slug=" . urlencode($p['slug']) . "</loc><lastmod>{$m}</lastmod><priority>0.8</priority></url>\n";
}
foreach ($cats as $c) {
    echo "  <url><loc>" . BASE_URL . "/category.php?slug=" . urlencode($c['slug']) . "</loc><priority>0.6</priority></url>\n";
}
foreach ($pages as $p) {
    echo "  <url><loc>" . BASE_URL . "/page.php?slug=" . urlencode($p['slug']) . "</loc><priority>0.5</priority></url>\n";
}
echo "</urlset>\n";

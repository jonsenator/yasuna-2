<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';
require_once __DIR__ . '/includes/leaders.php';
require_once __DIR__ . '/includes/emblem.php';
require_once __DIR__ . '/includes/cardlinks.php';
require_once __DIR__ . '/includes/conferences.php';

$slug = trim($_GET['slug'] ?? '');
$pg   = $slug !== '' ? get_page_by_slug($slug) : null;

if (!$pg) {
    http_response_code(404);
    $meta_title = 'Topilmadi';
    require __DIR__ . '/includes/header.php';
    echo '<section class="wrap section"><div class="empty"><h3>Sahifa topilmadi</h3><a class="btn-cta" href="' . BASE_URL . '/">Bosh sahifaga &rarr;</a></div></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$meta_title = $pg['title'] . ' — ' . setting('site_name', 'PMM');
require __DIR__ . '/includes/header.php';

if ($slug === 'ilmiy-amaliy-konferensiya') {
    render_conferences_page();
    require __DIR__ . '/includes/footer.php';
    exit;
}
?>

<div class="page-head">
  <div class="wrap">
    <div class="breadcrumb"><a href="<?= BASE_URL ?>/">Bosh sahifa</a><span>/</span><span><?= h($pg['title']) ?></span></div>
    <h1><?= h($pg['title']) ?></h1>
  </div>
</div>

<div class="wrap">
  <?php
  $body = apply_leaders_shortcode(apply_card_links(safe_html($pg['content'])));
  $emb  = page_wants_emblem((string)$pg['content']);
  if ($emb) $body = apply_emblem_banner($body, $pg['title']);
?>
  <div class="static-body<?= $emb ? ' has-emb' : '' ?><?= $emb && gerb_image_url() ? ' has-gerb' : '' ?>"<?= $emb ? gerb_style_attr() : '' ?>><?= $body ?></div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
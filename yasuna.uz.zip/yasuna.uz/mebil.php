<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LDSP Mebel Konstruktori — 3D tahrir va Kroy</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;
       background:#eef1f5;color:#1c2431;line-height:1.5;padding:14px}
  .wrap{max-width:1240px;margin:0 auto}
  header{background:linear-gradient(135deg,#7b4b28,#a8703f);color:#fff;padding:20px 24px;
         border-radius:14px;margin-bottom:16px;box-shadow:0 4px 16px rgba(0,0,0,.12)}
  header h1{font-size:22px;font-weight:700}
  header p{opacity:.92;font-size:13px;margin-top:4px}
  .grid{display:grid;grid-template-columns:320px 1fr;gap:16px;align-items:start}
  @media(max-width:900px){.grid{grid-template-columns:1fr}}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,.07);margin-bottom:16px}
  .card h2{font-size:15px;text-transform:uppercase;letter-spacing:.5px;color:#7b4b28;
           margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #f0e6dc}
  label{display:block;font-size:12px;font-weight:600;color:#54607a;margin:10px 0 4px}
  input,select{width:100%;padding:8px 10px;border:1.5px solid #d7dde7;border-radius:8px;
               font-size:14px;font-family:inherit;background:#fff}
  input:focus,select:focus{outline:none;border-color:#a8703f}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
  .chk{display:flex;align-items:center;gap:8px;margin:10px 0;font-size:13px;font-weight:600;color:#54607a}
  .chk input{width:auto;transform:scale(1.2)}
  button{width:100%;padding:11px;border:none;border-radius:9px;font-size:14px;font-weight:700;
         cursor:pointer;font-family:inherit;transition:.15s}
  .btn-kroy{background:linear-gradient(135deg,#2d7d5a,#3fa876);color:#fff;font-size:17px;
            padding:15px;margin-top:12px;box-shadow:0 3px 10px rgba(45,125,90,.3)}
  .btn-kroy:hover{filter:brightness(1.08)}
  .btn-add{background:#7b4b28;color:#fff;margin-top:10px}
  .btn-add:hover{background:#9a5f33}
  .btn-sm{background:#eef1f5;color:#54607a;padding:7px;font-size:12px;margin-top:8px}
  .btn-sm:hover{background:#dde3ec}
  .btn-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th{background:#f5f7fa;padding:8px 6px;text-align:left;font-size:11px;text-transform:uppercase;
     color:#54607a;border-bottom:2px solid #e2e8f0;white-space:nowrap}
  td{padding:7px 6px;border-bottom:1px solid #eef1f5}
  tr:hover td{background:#fafbfd}
  .tag{display:inline-block;padding:2px 7px;border-radius:5px;font-size:10px;font-weight:700}
  .t-korpus{background:#e3edf9;color:#1e5a9e}.t-fasad{background:#fdeee0;color:#a8600f}
  .t-polka{background:#e6f6ec;color:#1e7a4a}.t-hdf{background:#f0eaf7;color:#6b3fa0}
  .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(128px,1fr));gap:10px;margin-bottom:16px}
  .stat{background:#fff;border-radius:11px;padding:13px;box-shadow:0 2px 8px rgba(0,0,0,.07);
        border-left:4px solid #a8703f}
  .stat .v{font-size:21px;font-weight:800;font-variant-numeric:tabular-nums}
  .stat .l{font-size:11px;color:#7b8698;text-transform:uppercase;font-weight:600;margin-top:2px}
  .item{background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:9px;padding:9px 11px;
        margin-bottom:7px;display:flex;justify-content:space-between;align-items:center;gap:8px}
  .item.sel{border-color:#7b4b28;background:#fdf6f0}
  .item .nm{font-size:13px;font-weight:700}
  .item .ds{font-size:11px;color:#7b8698}
  .item .x{background:#fee;color:#c33;border:none;border-radius:6px;width:26px;height:26px;
           cursor:pointer;font-weight:900;font-size:15px;flex:none;line-height:1}
  .empty{text-align:center;color:#9aa5b5;font-size:13px;padding:22px 10px}
  .sheet-box{margin-bottom:16px}
  .sheet-title{font-size:12px;font-weight:700;color:#54607a;margin-bottom:5px}
  svg{width:100%;height:auto;background:#f5f7fa;border-radius:8px;border:1px solid #e2e8f0;display:block}
  .note{font-size:11px;color:#7b8698;margin-top:10px;line-height:1.6}
  .hide{display:none}
  .legend{display:flex;gap:12px;flex-wrap:wrap;font-size:11px;color:#54607a;margin-bottom:8px}
  .legend i{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:4px;vertical-align:-1px}
  #stage{position:relative;border-radius:10px;overflow:hidden;
         background:linear-gradient(180deg,#f7f9fc 0%,#e7ecf3 62%,#dbe2ec 100%);
         border:1px solid #dde3ec;cursor:grab;touch-action:none;user-select:none}
  #stage.drag{cursor:grabbing}
  #stage.over{cursor:pointer}
  #cv{display:block;width:100%}
  #badge{position:absolute;right:10px;top:9px;font-size:11px;font-weight:700;color:#7b4b28;
         background:rgba(255,255,255,.88);padding:4px 9px;border-radius:6px;pointer-events:none}
  #tip{position:absolute;left:10px;bottom:8px;font-size:11px;
       background:rgba(255,255,255,.85);padding:4px 9px;border-radius:6px;pointer-events:none;color:#5a6478}
  .vbar{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:9px}
  .vb{width:auto;padding:6px 11px;font-size:12px;background:#eef1f5;color:#54607a;border-radius:8px}
  .vb:hover{background:#dde3ec}.vb.on{background:#7b4b28;color:#fff}
  .vopt{display:flex;gap:14px;flex-wrap:wrap;margin-top:10px}
  .vopt .chk{margin:0;font-size:12px}
  #stage:fullscreen{width:100vw;height:100vh;border-radius:0;border:none}
  #stage:-webkit-full-screen{width:100vw;height:100vh;border-radius:0}
  #fsbtn{position:absolute;left:10px;top:9px;width:auto;padding:6px 11px;font-size:13px;
         background:rgba(255,255,255,.9);color:#54607a;border-radius:8px;font-weight:700;
         box-shadow:0 1px 4px rgba(0,0,0,.12)}
  #fsbtn:hover{background:#fff}
  #selbar{display:none;align-items:center;gap:8px;flex-wrap:wrap;margin-top:10px;
          background:#fff7ec;border:1.5px solid #f0c99a;border-radius:9px;padding:9px 12px}
  #selbar.on{display:flex}
  #selbar .sn{font-size:13px;font-weight:800;color:#7b4b28}
  #selbar .sd{font-size:12px;color:#8a6a4a;font-variant-numeric:tabular-nums}
  .sb{width:auto;padding:6px 12px;font-size:12.5px;border-radius:7px}
  .sb-del{background:#d64545;color:#fff}.sb-del:hover{background:#e05a5a}
  .sb-add{background:#2f9e6e;color:#fff}.sb-add:hover{background:#38b57f}
  .sb-open{background:#2f7fd6;color:#fff}.sb-open:hover{background:#4a95e0}
  .sb-off{background:#eef1f5;color:#54607a}.sb-off:hover{background:#dde3ec}
  .qbar{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-top:10px;
       background:#f6f8fb;border:1px solid #e2e8f0;border-radius:9px;padding:8px 11px}
  .qbar b{min-width:20px;text-align:center;font-size:15px;color:#1c2431}
  .ql{font-size:12px;font-weight:700;color:#54607a}
  .qb{width:auto;padding:5px 12px;font-size:14px;background:#7b4b28;color:#fff;border-radius:7px}
  .qb:hover{background:#9a5f33}
  .qsep{width:1px;height:20px;background:#d7dde7;margin:0 5px}
  .help{background:#f0f7ff;border:1px solid #cfe3f7;border-radius:9px;padding:10px 12px;
        font-size:12px;color:#2c5580;margin-top:10px;line-height:1.7}
  @media print{body{background:#fff;padding:0}.no-print{display:none!important}
    .grid{grid-template-columns:1fr}.card{box-shadow:none;border:1px solid #ddd;page-break-inside:avoid}}
</style>
</head>
<body>
<div class="wrap">

<header>
  <h1>🪚 LDSP Mebel Konstruktori</h1>
  <p>3D shaklni ushlab tahrirlang — cheklaridan torting, bo'ling, eshik qo'shing — so'ng kroy qiling</p>
</header>

<div class="grid">

  <div class="no-print">
    <div class="card">
      <h2>Material</h2>
      <div class="row">
        <div><label>List eni (mm)</label><input type="number" id="sheetW" value="2750"></div>
        <div><label>List bo'yi (mm)</label><input type="number" id="sheetH" value="1830"></div>
      </div>
      <div class="row">
        <div><label>LDSP qalinligi</label><input type="number" id="thk" value="16"></div>
        <div><label>Arra keni</label><input type="number" id="kerf" value="4"></div>
      </div>
      <div class="row">
        <div><label>1 list narxi</label><input type="number" id="priceSheet" value="450000"></div>
        <div><label>Kromka 1 m</label><input type="number" id="priceEdge" value="3000"></div>
      </div>
      <div class="chk"><input type="checkbox" id="grain">
        <label for="grain" style="margin:0">Tekstura yo'nalishini saqlash</label></div>
    </div>

    <div class="card">
      <h2>O'lchamlar</h2>
      <label>Mebel turi</label>
      <select id="type" onchange="onType()">
        <option value="wardrobe">Kiyim shkafi</option>
        <option value="base">Oshxona tumbasi (pastki)</option>
        <option value="upper">Oshxona javoni (yuqori)</option>
        <option value="bookcase">Kitob javoni</option>
        <option value="desk">Yozuv / oshxona stoli</option>
        <option value="drawerbox">Tumba (yashikli)</option>
        <option value="custom">➕ O'z detalim</option>
      </select>

      <div id="paramBlock">
        <label>Nomi</label><input type="text" id="name" value="Kiyim shkafi">
        <div class="row3">
          <div><label>Eni</label><input type="number" id="W" value="800"></div>
          <div><label>Balandlik</label><input type="number" id="H" value="2100"></div>
          <div><label>Chuqurlik</label><input type="number" id="D" value="550"></div>
        </div>
        <div class="row3">
          <div><label>Polka (bo'limda)</label><input type="number" id="shelves" value="4"></div>
          <div><label>Eshik</label><input type="number" id="doors" value="2"></div>
          <div><label>Yashik</label><input type="number" id="drawers" value="0"></div>
        </div>
        <div class="row">
          <div><label>Bo'luvchi</label><input type="number" id="divs" value="0"></div>
          <div><label>Nechta dona</label><input type="number" id="qty" value="1"></div>
        </div>
        <div class="chk"><input type="checkbox" id="back" checked>
          <label for="back" style="margin:0">Orqa devor (HDF)</label></div>
        <div class="chk"><input type="checkbox" id="sokol" checked>
          <label for="sokol" style="margin:0">Sokol / oyoq tagligi</label></div>
      </div>

      <div id="customBlock" class="hide">
        <label>Detal nomi</label><input type="text" id="cName" value="Polka">
        <div class="row3">
          <div><label>Uzunlik</label><input type="number" id="cL" value="800"></div>
          <div><label>Kenglik</label><input type="number" id="cW" value="400"></div>
          <div><label>Soni</label><input type="number" id="cQ" value="2"></div>
        </div>
        <label>Kromka (uzun / qisqa)</label>
        <div class="row">
          <div><select id="cE1"><option value="0">0 uzun</option><option value="1">1 uzun</option>
               <option value="2" selected>2 uzun</option></select></div>
          <div><select id="cE2"><option value="0">0 qisqa</option><option value="1">1 qisqa</option>
               <option value="2">2 qisqa</option></select></div>
        </div>
      </div>
      <button class="btn-add" onclick="addItem()">+ Ro'yxatga qo'shish</button>
    </div>

    <div class="card">
      <h2>Loyiha ro'yxati</h2>
      <div id="items"></div>
      <div class="btn-row">
        <button class="btn-sm" onclick="clearAll()">🗑 Tozalash</button>
        <button class="btn-sm" onclick="saveProj()">💾 Saqlash</button>
      </div>
    </div>
  </div>

  <div>
    <div class="card">
      <h2>🧊 3D konstruktor</h2>
      <select id="viewSel" onchange="onSel()" style="margin-bottom:10px">
        <option value="-1">⚙️ Yangi mebel (tahrirlanmoqda)</option>
      </select>
      <div class="vbar no-print">
        <button class="vb" onclick="setView(-0.62,0.3)">🧊 3D</button>
        <button class="vb" onclick="setView(0,0.02)">▢ Old</button>
        <button class="vb" onclick="setView(-1.5708,0.02)">◨ Yon</button>
        <button class="vb" onclick="setView(0,1.35)">⬓ Tepa</button>
        <button class="vb" onclick="zoomBy(1.18)">➕</button>
        <button class="vb" onclick="zoomBy(0.85)">➖</button>
        <button class="vb" id="spinBtn" onclick="toggleSpin()">▶ Aylantirish</button>
        <button class="vb" onclick="toggleFS()">⛶ To'liq ekran</button>
      </div>
      <div id="stage">
        <canvas id="cv"></canvas>
        <button id="fsbtn" onclick="toggleFS()">⛶</button>
        <div id="badge"></div>
        <div id="tip">🖱 Bo'sh joyni surib aylantiring</div>
      </div>

      <div id="selbar" class="no-print">
        <span class="sn" id="selName">—</span>
        <span class="sd" id="selDim"></span>
        <span style="flex:1"></span>
        <span id="selBtns"></span>
        <button class="sb sb-off" onclick="setSel(null)">Bekor qilish</button>
      </div>

      <div class="qbar no-print">
        <span class="ql">Eshik</span>
        <button class="qb" onclick="setDoors(WORK.doors-1)">−</button>
        <b id="qDoors">2</b>
        <button class="qb" onclick="setDoors(WORK.doors+1)">+</button>
        <span class="qsep"></span>
        <span class="ql">Yashik</span>
        <button class="qb" onclick="setDrawers(WORK.drawers-1)">−</button>
        <b id="qDraw">0</b>
        <button class="qb" onclick="setDrawers(WORK.drawers+1)">+</button>
        <span class="qsep"></span>
        <span class="ql">Bo'lim</span>
        <button class="qb" onclick="splitEven()">⊞ Bo'lish</button>
        <b id="qSec">1</b>
        <span class="qsep"></span>
        <button class="qb" onclick="openAllDoors()">🚪 Eshiklarni ochish</button>
      </div>

      <div class="help no-print">
        <b>🟠 To'q sariq nuqtalarni torting</b> — eni, balandlik, chuqurlik o'zgaradi.<br>
        <b>🟢 Yashil ➕</b> — o'sha bo'limga polka qo'shadi &nbsp;·&nbsp;
        <b>🔵 Ko'k ➕</b> — mebelni ikkiga bo'ladi (bo'luvchi)<br>
        <b>🟣 Siyoh ➕/➖</b> — eshik soni &nbsp;·&nbsp;
        <b>🔴 Qizil ✕</b> — o'sha polka yoki bo'luvchini o'chiradi<br>
        <b>Detalni to'g'ridan-to'g'ri ushlab suring</b> — surganda o'lchami ko'rinib turadi.<br>
        <b>🚪 Eshikni bosing</b> — ochiladi/yopiladi. Ushlab sursangiz kerakli burchakka qo'yasiz.
        Yashikni ham bosib chiqarasiz.
      </div>

      <div class="vopt no-print">
        <div class="chk"><input type="checkbox" id="vDoors" checked onchange="draw()">
          <label for="vDoors" style="margin:0">Eshiklar</label></div>
        <div class="chk"><input type="checkbox" id="vBack" checked onchange="draw()">
          <label for="vBack" style="margin:0">Orqa devor</label></div>
        <div class="chk"><input type="checkbox" id="vDim" checked onchange="draw()">
          <label for="vDim" style="margin:0">O'lchamlar</label></div>
        <div class="chk"><input type="checkbox" id="vHandle" checked onchange="draw()">
          <label for="vHandle" style="margin:0">Ruchkalar</label></div>
        <div class="chk"><input type="checkbox" id="vCtrl" checked onchange="draw()">
          <label for="vCtrl" style="margin:0">Tahrir tugmalari</label></div>
      </div>

      <button class="btn-kroy no-print" onclick="calc()">✂️ KROY QILISH — materiallarni hisoblash</button>
    </div>

    <div id="out">
      <div class="card"><div class="empty">
        3D shaklni tahrirlang, so'ng <b>✂️ KROY QILISH</b> tugmasini bosing.
      </div></div>
    </div>
  </div>

</div>
</div>

<script>
/* ================= PRESETLAR ================= */
const PRESETS={
  wardrobe:{name:"Kiyim shkafi",W:800,H:2100,D:550,shelves:4,doors:2,drawers:0,divs:0,back:1,sokol:1},
  base:{name:"Oshxona tumbasi",W:600,H:850,D:560,shelves:1,doors:1,drawers:0,divs:0,back:1,sokol:1},
  upper:{name:"Oshxona javoni",W:600,H:720,D:320,shelves:2,doors:1,drawers:0,divs:0,back:1,sokol:0},
  bookcase:{name:"Kitob javoni",W:800,H:1800,D:300,shelves:5,doors:0,drawers:0,divs:0,back:1,sokol:1},
  desk:{name:"Yozuv stoli",W:1200,H:750,D:600,shelves:1,doors:0,drawers:0,divs:1,back:0,sokol:0},
  drawerbox:{name:"Yashikli tumba",W:450,H:700,D:500,shelves:0,doors:0,drawers:3,divs:0,back:1,sokol:1}
};
let ITEMS=[], WORK=null, SYNC=false;
function g(id){return document.getElementById(id)}
function v(id){return parseFloat(g(id).value)||0}
function iv(id){return Math.round(v(id))}
function gc(id){return g(id).checked}
const clamp=(x,a,b)=>x<a?a:(x>b?b:x);
const snap=x=>Math.round(x/5)*5;   // 5 mm ga yaxlitlash

/* ====== MODEL: bo'limlar va polkalar massiv ko'rinishida ====== */
function evenList(n,a,b){const r=[];for(let i=1;i<=n;i++)r.push(Math.round(a+(b-a)*i/(n+1)));return r}

function makeWork(type){
  if(type==='custom')
    return {type:'custom',name:g('cName').value||'Detal',L:iv('cL'),B:iv('cW'),
            q:Math.max(1,iv('cQ')),e1:+g('cE1').value,e2:+g('cE2').value};
  const t=Math.max(4,iv('thk'));
  const o={type,name:g('name').value||'Mebel',W:iv('W'),H:iv('H'),D:iv('D'),
    doors:Math.max(0,iv('doors')),drawers:Math.max(0,iv('drawers')),
    qty:Math.max(1,iv('qty')),back:gc('back'),sokol:gc('sokol'),divPos:[],secShelves:[],
    doorOpen:[],drawOpen:[]};
  const nd=Math.max(0,iv('divs')), ns=Math.max(0,iv('shelves'));
  o.divPos=evenList(nd,t,o.W-t);
  const y0=(o.sokol&&type!=='desk'?100:0)+t, y1=o.H-t;
  for(let i=0;i<=nd;i++) o.secShelves.push(evenList(ns,y0,y1));
  return o;
}
/* eski/localStorage yozuvlarini yangi formatga keltirish */
function normItem(it){
  if(it.type==='custom')return it;
  const t=Math.max(4,iv('thk'));
  if(!Array.isArray(it.divPos)) it.divPos=evenList(Math.max(0,it.divs|0),t,it.W-t);
  if(!Array.isArray(it.secShelves)){
    const y0=(it.sokol&&it.type!=='desk'?100:0)+t,y1=it.H-t;
    it.secShelves=[];
    for(let i=0;i<=it.divPos.length;i++) it.secShelves.push(evenList(Math.max(0,it.shelves|0),y0,y1));
  }
  while(it.secShelves.length<it.divPos.length+1) it.secShelves.push([]);
  it.secShelves.length=it.divPos.length+1;
  if(!Array.isArray(it.doorOpen)) it.doorOpen=[];
  if(!Array.isArray(it.drawOpen)) it.drawOpen=[];
  return it;
}
/* bo'lim chegaralari: [[x0,x1],...] ichki yuzalar */
function sections(it,t){
  const s=[];let left=t;
  it.divPos.forEach(x=>{s.push([left,x-t/2]);left=x+t/2});
  s.push([left,it.W-t]);
  return s;
}
/* eshik oralig'i: bo'luvchilarga mos kelsa - har bo'limga bitta */
function doorSpans(it){
  if(it.doors<=0)return [];
  const n=it.doors, out=[];
  if(n===it.divPos.length+1){
    const e=[0,...it.divPos,it.W];
    for(let i=0;i<n;i++) out.push([e[i]+3,e[i+1]-3]);
  } else {
    const dw=(it.W-3*(n+1))/n;
    for(let i=0;i<n;i++){const x=3+i*(dw+3);out.push([x,x+dw])}
  }
  return out;
}
function drawerZoneTop(it,t){
  if(it.drawers<=0)return (it.sokol&&it.type!=='desk'?100:0)+t;
  const s=(it.sokol&&it.type!=='desk')?100:0;
  const zone=(it.type==='drawerbox')?it.H-s-2*t:Math.min(it.H*0.5,it.drawers*180);
  return s+t+zone;
}

/* ================= DETALLAR (kroy uchun) ================= */
function buildParts(it,t){
  const P=[],W=it.W,H=it.H,D=it.D;
  const add=(nm,L,B,q,e1,e2,cat)=>{if(L>0.5&&B>0.5&&q>0)
    P.push({nm,L:Math.round(L),B:Math.round(B),q,e1,e2,cat})};
  const inner=W-2*t;
  if(it.type==='desk'){
    add('Stol usti',W,D,1,2,2,'korpus');
    add('Yon oyoq',H-t,D-20,2,2,1,'korpus');
    it.divPos.forEach(()=>add("O'rta bo'luvchi",H-t,D-20,1,2,1,'korpus'));
    add("Bog'lovchi tsarga",inner,120,2,1,0,'korpus');
    sections(it,t).forEach(([a,b])=>{
      const w=b-a; it.secShelves[sections(it,t).findIndex(s=>s[0]===a)];
    });
    const secs=sections(it,t);
    secs.forEach((s,i)=>{const w=s[1]-s[0];
      (it.secShelves[i]||[]).forEach(()=>add('Polka',w,D-50,1,1,0,'polka'))});
  } else {
    add('Yon devor',H,D,2,2,1,'korpus');
    add('Tepa panel',inner,D,1,1,1,'korpus');
    add('Past panel',inner,D,1,1,1,'korpus');
    const s0=(it.sokol?100:0);
    it.divPos.forEach(()=>add("Vertikal bo'luvchi",H-s0-2*t,D-20,1,1,1,'korpus'));
    const secs=sections(it,t);
    secs.forEach((sc,i)=>{const w=sc[1]-sc[0];
      (it.secShelves[i]||[]).forEach(()=>add('Polka',w-2,D-30,1,1,0,'polka'))});
    if(it.sokol) add('Sokol (old)',inner,100,1,1,0,'korpus');
  }
  doorSpans(it).forEach(([a,b])=>{
    const yb=Math.max((it.sokol&&it.type!=='desk'?100:0)+3, drawerZoneTop(it,t));
    add('Fasad (eshik)',H-3-yb,b-a,1,2,2,'fasad');
  });
  if(it.drawers>0){
    const s=(it.sokol&&it.type!=='desk')?100:0;
    const zone=(it.type==='drawerbox')?H-s-2*t:Math.min(H*0.5,it.drawers*180);
    const fh=zone/it.drawers-4, fw=W-6;
    add('Yashik fasadi',fw,fh,it.drawers,2,2,'fasad');
    const bd=D-80,bw=inner-26;
    add('Yashik yoni',bd,fh-40,it.drawers*2,1,0,'korpus');
    add('Yashik old/orqa',bw-2*t,fh-40,it.drawers*2,1,0,'korpus');
    add('Yashik tagi (HDF)',bw,bd,it.drawers,0,0,'hdf');
  }
  if(it.back) add('Orqa devor (HDF)',W,H,1,0,0,'hdf');
  return P;
}

/* ================= 3D GEOMETRIYA ================= */
function build3D(it,t){
  const B=[],W=it.W,H=it.H,D=it.D;
  const add=(x,y,z,w,h,d,cat,nm,meta)=>{if(w>.4&&h>.4&&d>.4)
    B.push({x,y,z,w,h,d,cat,nm,meta})};
  const showD=gc('vDoors'),showB=gc('vBack'),showHnd=gc('vHandle');
  if(it.type==='custom'){ add(0,0,0,it.L,it.B,t,'polka',it.name); return {B,W:it.L,H:it.B,D:t}; }
  const inner=W-2*t, s=(it.sokol&&it.type!=='desk')?100:0;
  const secs=sections(it,t);

  if(it.type==='desk'){
    add(0,H-t,0,W,t,D,'top','Stol usti');
    add(0,0,10,t,H-t,D-20,'korpus','Yon oyoq');
    add(W-t,0,10,t,H-t,D-20,'korpus','Yon oyoq');
    it.divPos.forEach((x,i)=>add(x-t/2,0,10,t,H-t,D-20,'korpus',"Bo'luvchi",{sel:{kind:'div',idx:i}}));
    add(t,H-t-120,0,inner,120,t,'korpus','Tsarga');
    add(t,H-t-120,D-t,inner,120,t,'korpus','Tsarga');
    secs.forEach((sc,i)=>(it.secShelves[i]||[]).forEach((y,j)=>
      add(sc[0],y,10,sc[1]-sc[0],t,D-50,'polka','Polka',{sel:{kind:'shelf',sec:i,idx:j}})));
  } else {
    add(0,0,0,t,H,D,'korpus','Yon devor');
    add(W-t,0,0,t,H,D,'korpus','Yon devor');
    add(t,H-t,0,inner,t,D,'top','Tepa panel');
    add(t,s,0,inner,t,D,'korpus','Past panel');
    if(s) add(t,0,0,inner,s,t,'korpus','Sokol');
    it.divPos.forEach((x,i)=>add(x-t/2,s+t,0,t,H-s-2*t,D-20,'korpus',"Bo'luvchi",{sel:{kind:'div',idx:i}}));
    secs.forEach((sc,i)=>(it.secShelves[i]||[]).forEach((y,j)=>
      add(sc[0]+1,y,0,sc[1]-sc[0]-2,t,D-30,'polka','Polka',{sel:{kind:'shelf',sec:i,idx:j}})));
    if(it.back&&showB) add(0,0,D-3,W,H,3,'hdf','Orqa devor');
  }
  if(it.drawers>0&&showD){
    const zone=(it.type==='drawerbox')?H-s-2*t:Math.min(H*0.5,it.drawers*180);
    const fh=zone/it.drawers-4,fw=W-6;
    const dop=it.drawOpen||[];
    for(let i=0;i<it.drawers;i++){
      const y=s+t+i*(fh+4);
      const out=(dop[i]||0)*(D-90);          // chiqish masofasi
      add(3,y,-t-out,fw,fh,t,'fasad','Yashik fasadi',{sel:{kind:'drawer',idx:i}});
      if(showHnd) add(W/2-70,y+fh-45,-t-14-out,140,16,14,'metal','Ruchka');
      if(out>8){ // chiqqan yashikning yon devorlari
        const bw=inner-26,bd=D-80,bh=fh-40;
        add(t+13,y+8,-out+10,10,bh,bd,'korpus','Yashik yoni');
        add(W-t-23,y+8,-out+10,10,bh,bd,'korpus','Yashik yoni');
        add(t+13,y+8,-out+bd+4,bw,bh,10,'korpus','Yashik orqa');
        add(t+13,y+8,-out+10,bw,10,bd,'hdf','Yashik tagi');
      }
    }
  }
  if(showD){
    const yb=Math.max(s+3,drawerZoneTop(it,t)), dh=H-3-yb;
    const oa=it.doorOpen||[];
    /* burilgan (ochilgan) qutini 8 burchak bilan qo'shish */
    const CORN=[[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
    const addRot=(X,Y,Z,hx,phi,cat,nm,meta)=>{
      const cs=Math.cos(phi),sn=Math.sin(phi);
      const cor=CORN.map(([ix,iy,iz])=>{
        const dx=X[ix]-hx, dz=Z[iz];
        return [hx+dx*cs-dz*sn, Y[iy], dx*sn+dz*cs];
      });
      let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,z0=1e9,z1=-1e9;
      cor.forEach(c=>{if(c[0]<x0)x0=c[0];if(c[0]>x1)x1=c[0];
        if(c[1]<y0)y0=c[1];if(c[1]>y1)y1=c[1];
        if(c[2]<z0)z0=c[2];if(c[2]>z1)z1=c[2]});
      B.push({x:x0,y:y0,z:z0,w:x1-x0,h:y1-y0,d:z1-z0,cat,nm,meta,corners:cor});
    };
    doorSpans(it).forEach(([a,b],i)=>{
      const deg=oa[i]||0;
      const left=(i%2===0);
      const hx=left?a:b, sgn=left?1:-1;
      const phi=-sgn*deg*Math.PI/180;
      addRot([a,b],[yb,yb+dh],[-t,0],hx,phi,'fasad','Fasad',{sel:{kind:'door',idx:i}});
      if(showHnd){
        const hpx=(left&&it.doors>1)?b-52:(it.doors>1?a+36:b-52);
        addRot([hpx,hpx+16],[yb+dh/2-70,yb+dh/2+70],[-t-14,-t],hx,phi,'metal','Ruchka',null);
      }
    });
  }
  return {B,W,H,D};
}

/* ================= RENDER ================= */
let yaw=-0.62,pitch=0.30,zoom=1,spinId=null;
const COL3={korpus:'#d9b88b',top:'#c8a068',polka:'#e2c69e',fasad:'#c39a63',hdf:'#8d7256',metal:'#9aa4b0'};
const LIGHT=(()=>{const l=[0.38,0.82,0.42],m=Math.hypot(...l);return l.map(a=>a/m)})();
function rotv(p){
  const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
  const x=p[0]*cy-p[2]*sy, z=p[0]*sy+p[2]*cy, y=p[1];
  return [x, y*cp-z*sp, y*sp+z*cp];
}
function shade(hex,f){
  const n=parseInt(hex.slice(1),16);
  return `rgb(${Math.min(255,Math.round((n>>16)*f))},${Math.min(255,Math.round(((n>>8)&255)*f))},${Math.min(255,Math.round((n&255)*f))})`;
}
function sortBoxes(BS,CAM,proj){
  const n=BS.length;
  const bb=BS.map(b=>{
    let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
    for(let i=0;i<8;i++){
      const p=proj(i&1?b.x+b.w:b.x, i&2?b.y+b.h:b.y, i&4?b.z+b.d:b.z);
      if(p[0]<x0)x0=p[0]; if(p[0]>x1)x1=p[0];
      if(p[1]<y0)y0=p[1]; if(p[1]>y1)y1=p[1];
    }
    return{x0,x1,y0,y1};
  });
  const axis=[['x','w',0],['y','h',1],['z','d',2]];
  function front(A,B){
    let yes=false,no=false;
    for(const[k,sz,ci]of axis){
      const a0=A[k],a1=A[k]+A[sz],b0=B[k],b1=B[k]+B[sz],c=CAM[ci];
      if(a1<=b0+0.01){ if(c<=a1)yes=true; else if(c>=b0)no=true; }
      else if(b1<=a0+0.01){ if(c>=a0)yes=true; else if(c<=b1)no=true; }
    }
    if(yes&&no) return null;
    if(yes) return true;
    if(no) return false;
    return null;
  }
  const dep=Array.from({length:n},()=>[]),indeg=new Int32Array(n);
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
    const A=bb[i],B=bb[j];
    if(A.x1<B.x0-0.5||B.x1<A.x0-0.5||A.y1<B.y0-0.5||B.y1<A.y0-0.5)continue;
    const r=front(BS[i],BS[j]);
    if(r===true){dep[i].push(j);indeg[i]++}
    else if(r===false){dep[j].push(i);indeg[j]++}
  }
  const d2=b=>{const x=b.x+b.w/2-CAM[0],y=b.y+b.h/2-CAM[1],z=b.z+b.d/2-CAM[2];return x*x+y*y+z*z};
  const done=new Uint8Array(n),out=[],left=new Set([...Array(n).keys()]);
  while(left.size){
    let best=-1,bd=-1;
    for(const i of left) if(indeg[i]===0){const d=d2(BS[i]);if(d>bd){bd=d;best=i}}
    if(best<0) for(const i of left){const d=d2(BS[i]);if(d>bd){bd=d;best=i}}
    left.delete(best);done[best]=1;out.push(best);
    for(let i=0;i<n;i++) if(!done[i]&&dep[i].length){
      const k=dep[i].indexOf(best); if(k>=0){dep[i].splice(k,1);indeg[i]--}
    }
  }
  return out.map((i,k)=>{BS[i]._o=k;return BS[i]});
}

/* ================= TAHRIR TUGMALARI ================= */
let CTRLS=[], DRAG=null, PROJ=null;
let SEL=null;        // {kind:'shelf'|'div'|'door'|'drawer', sec, idx}
let PDRAG=null, MOVED=false;   // detalni to'g'ridan-to'g'ri sudrash
let PICK=[];         // bosish uchun: {poly, meta, depth}
function sameSel(a,b){
  if(!a||!b)return false;
  return a.kind===b.kind && (a.sec|0)===(b.sec|0) && (a.idx|0)===(b.idx|0);
}
function ctl(o){CTRLS.push(o);return o}

function draw(){
  const cv=g('cv'),ctx=cv.getContext('2d');
  const CW=cv.clientWidth||600, CH=parseInt(cv.style.height)||430;
  ctx.clearRect(0,0,CW,CH);
  CTRLS=[];
  const it=WORK; if(!it)return;
  const t=Math.max(4,iv('thk'));
  const M=build3D(it,t);
  const W=M.W,H=M.H,D=M.D;
  if(!(W>0&&H>0))return;
  g('badge').textContent=(it.name||'Mebel')+' · '+Math.round(W)+'×'+Math.round(H)+'×'+Math.round(D)+' mm';

  const cx0=W/2,cy0=H/2,cz0=-D/2;
  const radius=0.5*Math.hypot(W,H,D)||100, dist=radius*3.4;
  const S=Math.min(CW,CH)*0.345/radius*zoom, ox=CW/2, oy=CH/2+CH*0.04;
  function proj(x,y,z){
    const p=rotv([x-cx0,y-cy0,-z-cz0]);
    const k=dist/Math.max(dist-p[2],dist*0.15);
    return [ox+p[0]*S*k, oy-p[1]*S*k, p[2]];
  }
  PROJ=proj;
  PICK=[];
  const cyw=Math.cos(yaw),syw=Math.sin(yaw),cpw=Math.cos(pitch),spw=Math.sin(pitch);
  const CAM=[cx0+dist*cpw*syw, cy0+dist*spw, D/2-dist*cpw*cyw];

  /* pol soyasi */
  const pad=Math.max(W,D)*0.10;
  const sh=[[-pad,0,-pad],[W+pad,0,-pad],[W+pad,0,D+pad],[-pad,0,D+pad]].map(p=>proj(p[0],p[1],p[2]));
  ctx.beginPath();ctx.moveTo(sh[0][0],sh[0][1]);
  for(let i=1;i<4;i++)ctx.lineTo(sh[i][0],sh[i][1]);
  ctx.closePath();ctx.fillStyle='rgba(60,70,90,.10)';ctx.fill();

  /* yuzalar */
  const ORDER=sortBoxes(M.B,CAM,proj);
  const FACES=[];
  const IDX=[[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[0,1,5,4],[3,7,6,2]];
  for(const b of ORDER){
    const X=[b.x,b.x+b.w],Y=[b.y,b.y+b.h],Z=[b.z,b.z+b.d];
    const c=b.corners||[[X[0],Y[0],Z[0]],[X[1],Y[0],Z[0]],[X[1],Y[1],Z[0]],[X[0],Y[1],Z[0]],
             [X[0],Y[0],Z[1]],[X[1],Y[0],Z[1]],[X[1],Y[1],Z[1]],[X[0],Y[1],Z[1]]];
    const pr=c.map(p=>proj(p[0],p[1],p[2]));
    const ctr=b.corners
      ? [c.reduce((s2,q)=>s2+q[0],0)/8,c.reduce((s2,q)=>s2+q[1],0)/8,c.reduce((s2,q)=>s2+q[2],0)/8]
      : [b.x+b.w/2,b.y+b.h/2,b.z+b.d/2];
    for(const f of IDX){
      const q=[pr[f[0]],pr[f[1]],pr[f[2]],pr[f[3]]];
      const fc=[(c[f[0]][0]+c[f[2]][0])/2,(c[f[0]][1]+c[f[2]][1])/2,(c[f[0]][2]+c[f[2]][2])/2];
      const outw=[fc[0]-ctr[0],fc[1]-ctr[1],-(fc[2]-ctr[2])];
      const vp=rotv([fc[0]-cx0,fc[1]-cy0,-fc[2]-cz0]);
      const nv=rotv(outw), nm=Math.hypot(...nv)||1;
      const nn=[nv[0]/nm,nv[1]/nm,nv[2]/nm];
      const toCam=[-vp[0],-vp[1],dist-vp[2]], tm=Math.hypot(...toCam)||1;
      if((nn[0]*toCam[0]+nn[1]*toCam[1]+nn[2]*toCam[2])/tm<=0.001) continue;
      const lit=Math.max(0,nn[0]*LIGHT[0]+nn[1]*LIGHT[1]+nn[2]*LIGHT[2]);
      const selm=b.meta&&b.meta.sel;
      const isSel=selm&&sameSel(selm,SEL);
      let base=COL3[b.cat]||'#ccc';
      if(isSel) base='#ff9d3c';
      else if(SEL&&selm) base=base;
      FACES.push({q,ord:b._o,z:(q[0][2]+q[1][2]+q[2][2]+q[3][2])/4,
                  sel:selm||null,isSel:!!isSel,
                  col:shade(base,0.52+0.58*lit)});
      if(selm) PICK.push({q,ord:b._o,sel:selm,nm:b.nm,box:b});
    }
  }
  FACES.sort((a,b)=>a.ord-b.ord||a.z-b.z);
  ctx.lineJoin='round';
  for(const f of FACES){
    ctx.beginPath();ctx.moveTo(f.q[0][0],f.q[0][1]);
    for(let i=1;i<4;i++)ctx.lineTo(f.q[i][0],f.q[i][1]);
    ctx.closePath();ctx.fillStyle=f.col;ctx.fill();
    if(f.isSel){ctx.strokeStyle='#c2410c';ctx.lineWidth=2.6}
    else{ctx.strokeStyle='rgba(60,42,24,.55)';ctx.lineWidth=0.9}
    ctx.stroke();
  }

  /* --- sudralayotgan detalning jonli o'lchami --- */
  if(SEL){
    const t3=tt(), secs3=sections(it,t3);
    let txt=null, anchor=null;
    if(SEL.kind==='shelf'){
      const arr=it.secShelves[SEL.sec]||[], y=arr[SEL.idx];
      if(y!==undefined){
        const sc=secs3[SEL.sec]||[0,0];
        const wmm=Math.round(sc[1]-sc[0]-2), dmm=Math.round(D-30);
        txt=[wmm+' × '+dmm+' mm', 'balandlik: '+Math.round(y)+' mm'];
        anchor=proj((sc[0]+sc[1])/2, y+t3, D*0.15);
      }
    } else if(SEL.kind==='div'){
      const x=it.divPos[SEL.idx];
      if(x!==undefined){
        const hmm=Math.round(H-((it.sokol&&it.type!=='desk')?100:0)-2*t3);
        txt=[hmm+' × '+Math.round(D-20)+' mm', 'chapdan: '+Math.round(x)+' mm'];
        anchor=proj(x, H*0.62, D*0.15);
      }
    } else if(SEL.kind==='door'){
      const sp2=doorSpans(it)[SEL.idx];
      if(sp2){
        const yb=Math.max(((it.sokol&&it.type!=='desk')?100:0)+3, drawerZoneTop(it,t3));
        const deg=(it.doorOpen||[])[SEL.idx]||0;
        txt=[Math.round(sp2[1]-sp2[0])+' × '+Math.round(H-3-yb)+' mm',
             deg>0?('ochilgan: '+Math.round(deg)+'°'):'yopiq — bosing yoki suring'];
        anchor=proj((sp2[0]+sp2[1])/2, yb+(H-3-yb)*0.62, -t3*2);
      }
    } else if(SEL.kind==='drawer'){
      const s4=(it.sokol&&it.type!=='desk')?100:0;
      const zone=(it.type==='drawerbox')?H-s4-2*t3:Math.min(H*0.5,it.drawers*180);
      const fh=zone/it.drawers-4;
      const f=(it.drawOpen||[])[SEL.idx]||0;
      txt=[Math.round(W-6)+' × '+Math.round(fh)+' mm',
           f>0.05?('chiqqan: '+Math.round(f*100)+'%'):'yopiq — bosing yoki suring'];
      anchor=proj(W/2, s4+t3+SEL.idx*(fh+4)+fh*0.6, -t3*2);
    }
    if(txt&&anchor){
      ctx.save();
      ctx.font='bold 13px Arial';
      const w1=ctx.measureText(txt[0]).width;
      ctx.font='11px Arial';
      const w2=ctx.measureText(txt[1]).width;
      const bw=Math.max(w1,w2)+18, bh=38;
      let bx=anchor[0]-bw/2, by=anchor[1]-bh-14;
      bx=Math.max(4,Math.min(CW-bw-4,bx)); by=Math.max(4,Math.min(CH-bh-4,by));
      ctx.fillStyle='rgba(28,36,49,.93)';
      if(ctx.roundRect){ctx.beginPath();ctx.roundRect(bx,by,bw,bh,8);ctx.fill()}
      else ctx.fillRect(bx,by,bw,bh);
      ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillStyle='#ffb168';ctx.font='bold 13px Arial';
      ctx.fillText(txt[0],bx+bw/2,by+13);
      ctx.fillStyle='#c9d3e0';ctx.font='11px Arial';
      ctx.fillText(txt[1],bx+bw/2,by+27);
      ctx.restore();
    }
  }

  /* o'lchamlar */
  if(gc('vDim')){
    const off=Math.max(W,H,D)*0.13;
    dim(ctx,proj(0,-off*0.55,0),proj(W,-off*0.55,0),Math.round(W)+' mm');
    dim(ctx,proj(-off*1.6,0,0),proj(-off*1.6,H,0),Math.round(H)+' mm');
    if(D>t*2) dim(ctx,proj(W+off*0.5,-off*0.3,0),proj(W+off*0.5,-off*0.3,D),Math.round(D)+' mm');
  }

  /* ---- tahrir tugmalari ---- */
  if(gc('vCtrl')&&it.type!=='custom'){
    const axisPx=(a,ax)=>{
      const p0=proj(a[0],a[1],a[2]), e=4;
      const p1=proj(a[0]+ax[0]*e,a[1]+ax[1]*e,a[2]+ax[2]*e);
      return {sx:(p1[0]-p0[0])/e, sy:(p1[1]-p0[1])/e, px:p0[0], py:p0[1]};
    };
    const t2=t;
    /* o'lcham tortish nuqtalari */
    const gap=Math.max(W,H,D)*0.05;
    const hW=axisPx([W+gap,H*0.5,D/2],[1,0,0]);
    ctl({x:hW.px,y:hW.py,r:15,kind:'size',col:'#f08c2e',icon:'↔',tip:'Enini torting',
         ax:hW,get:()=>WORK.W,set:mm=>setW(clamp(snap(mm),200,4000))});
    const hH=axisPx([W*0.5,H+gap,D/2],[0,1,0]);
    ctl({x:hH.px,y:hH.py,r:15,kind:'size',col:'#f08c2e',icon:'↕',tip:'Balandlikni torting',
         ax:hH,get:()=>WORK.H,set:mm=>setH(clamp(snap(mm),200,3000))});
    const hD=axisPx([W+gap*0.8,gap*0.3,D+gap*0.8],[0,0,1]);
    ctl({x:hD.px,y:hD.py,r:15,kind:'size',col:'#f08c2e',icon:'↔',tip:'Chuqurlikni torting',
         ax:hD,get:()=>WORK.D,set:mm=>setD(clamp(snap(mm),100,900))});

    const s=(it.sokol&&it.type!=='desk')?100:0;
    const y0=s+t2, y1=H-t2, secs=sections(it,t2);
    // Eshiklar yopiq bo'lsa ichki detallar ko'rinmaydi -> ularning tugmasi ham kerak emas
    const innerVisible = !(gc('vDoors') && it.doors>0);

    if(innerVisible){
    /* bo'luvchilar: surish + o'chirish */
    it.divPos.forEach((x,i)=>{
      const a=axisPx([x,y1+gap*0.42,0],[1,0,0]);
      ctl({x:a.px,y:a.py,r:13,kind:'div',col:'#2f7fd6',icon:'↔',tip:"Bo'luvchini suring",
           own:{kind:'div',idx:i},ax:a,get:()=>WORK.divPos[i],set:mm=>moveDiv(i,mm)});
      const p=proj(x,y1+gap*0.42,-t2*3);
      ctl({x:p[0],y:p[1],r:11,kind:'btn',col:'#d64545',icon:'✕',tip:"Bo'luvchini o'chirish",
           own:{kind:'div',idx:i},click:()=>delDiv(i)});
    });
    /* polkalar: surish + o'chirish, va bo'limga qo'shish */
    secs.forEach((sc,i)=>{
      const mid=(sc[0]+sc[1])/2;
      (it.secShelves[i]||[]).forEach((y,j)=>{
        const a=axisPx([sc[0]+16,y,-t2*3],[0,1,0]);
        ctl({x:a.px,y:a.py,r:12,kind:'sh',col:'#2f9e6e',icon:'↕',tip:'Polkani suring',
             own:{kind:'shelf',sec:i,idx:j},
             ax:a,get:()=>WORK.secShelves[i][j],set:mm=>moveShelf(i,j,mm)});
        const p=proj(sc[1]-16,y,-t2*3);
        ctl({x:p[0],y:p[1],r:11,kind:'btn',col:'#d64545',icon:'✕',tip:"Polkani o'chirish",
             own:{kind:'shelf',sec:i,idx:j},click:()=>delShelf(i,j)});
      });
      const pa=proj(mid,(y0+y1)/2,-t2*3);
      ctl({x:pa[0],y:pa[1],r:15,kind:'btn',col:'#2f9e6e',icon:'+',tip:'Shu bo\'limga polka qo\'shish',
           click:()=>addShelf(i)});
      const pd=proj(mid,y0+(y1-y0)*0.16,-t2*3);
      ctl({x:pd[0],y:pd[1],r:13,kind:'btn',col:'#2f7fd6',icon:'|',tip:'Shu joydan bo\'lish',
           click:()=>addDiv(mid)});
    });
    }
    // Detal tanlangan bo'lsa: faqat unga tegishli tugmalar yorqin, qolgani xira
    CTRLS.forEach(c=>{
      c.dim = SEL ? !(c.own && sameSel(c.own,SEL)) : false;
    });
    CTRLS.slice().sort((a,b)=>(a.dim?0:1)-(b.dim?0:1)).forEach(c=>{
      const al=c.dim?0.20:1;
      ctx.save();ctx.globalAlpha=al;
      ctx.beginPath();ctx.arc(c.x,c.y,c.r,0,6.284);
      ctx.fillStyle=(DRAG&&DRAG.c===c)?'#fff':c.col;
      ctx.fill();
      ctx.lineWidth=2.4;ctx.strokeStyle=(DRAG&&DRAG.c===c)?c.col:'rgba(255,255,255,.92)';ctx.stroke();
      ctx.fillStyle=(DRAG&&DRAG.c===c)?c.col:'#fff';
      ctx.font='bold '+Math.round(c.r*1.15)+'px Arial';
      ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(c.icon,c.x,c.y+0.5);
      ctx.restore();
    });
  }
}
function dim(ctx,a,b,txt){
  ctx.save();
  ctx.strokeStyle='#7b4b28';ctx.lineWidth=1.3;ctx.setLineDash([5,4]);
  ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();
  ctx.setLineDash([]);
  [a,b].forEach(p=>{ctx.beginPath();ctx.arc(p[0],p[1],2.6,0,6.3);ctx.fillStyle='#7b4b28';ctx.fill()});
  const mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;
  ctx.font='bold 12px Arial';
  const w=ctx.measureText(txt).width+10;
  ctx.fillStyle='rgba(255,255,255,.92)';ctx.fillRect(mx-w/2,my-9,w,18);
  ctx.fillStyle='#7b4b28';ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText(txt,mx,my);
  ctx.restore();
}

/* ================= TAHRIR AMALLARI ================= */
function tt(){return Math.max(4,iv('thk'))}
function afterEdit(){
  syncToInputs();updQ();
  if(SEL){ // tanlov hali mavjudmi?
    const t=tt();
    let alive=true;
    if(SEL.kind==='shelf') alive=!!(WORK.secShelves[SEL.sec]||[])[SEL.idx];
    else if(SEL.kind==='div') alive=SEL.idx<WORK.divPos.length;
    else if(SEL.kind==='door') alive=SEL.idx<WORK.doors;
    else if(SEL.kind==='drawer') alive=SEL.idx<WORK.drawers;
    if(!alive){SEL=null;g('selbar').classList.remove('on')}
    else setSel(SEL);
  }
  draw();save();
}
function setW(w){
  const t=tt(),old=WORK.W;WORK.W=w;
  WORK.divPos=WORK.divPos.map(x=>clamp(Math.round(x*(w-2*t)/Math.max(1,old-2*t)),t+30,w-t-30))
              .sort((a,b)=>a-b);
  afterEdit();
}
function setH(h){
  const t=tt(),s=(WORK.sokol&&WORK.type!=='desk')?100:0;
  const o0=s+t,o1=WORK.H-t,n0=s+t,n1=h-t;
  WORK.H=h;
  WORK.secShelves=WORK.secShelves.map(a=>a.map(y=>
    clamp(Math.round(n0+(y-o0)*(n1-n0)/Math.max(1,o1-o0)),n0+20,n1-20)).sort((p,q)=>p-q));
  afterEdit();
}
function setD(d){WORK.D=d;afterEdit()}
function moveDiv(i,mm){
  const t=tt();
  const lo=(i>0?WORK.divPos[i-1]:t)+60, hi=(i<WORK.divPos.length-1?WORK.divPos[i+1]:WORK.W-t)-60;
  WORK.divPos[i]=clamp(snap(mm),lo,hi);
  afterEdit();
}
function addDiv(x){
  const t=tt();
  if(WORK.W-2*t<180)return;
  const i=WORK.divPos.filter(p=>p<x).length;
  const lo=(i>0?WORK.divPos[i-1]:t)+60, hi=(i<WORK.divPos.length?WORK.divPos[i]:WORK.W-t)-60;
  if(hi<=lo)return;
  WORK.divPos.splice(i,0,clamp(Math.round(x),lo,hi));
  WORK.secShelves.splice(i,0,(WORK.secShelves[i]||[]).slice());
  afterEdit();
}
function delDiv(i){
  if(SEL&&SEL.kind==='div'&&SEL.idx===i){SEL=null;g('selbar').classList.remove('on')}
  WORK.divPos.splice(i,1);
  const a=WORK.secShelves[i]||[],b=WORK.secShelves[i+1]||[];
  WORK.secShelves.splice(i,2,a.length>=b.length?a:b);
  afterEdit();
}
function addShelf(sec){
  const t=tt(),s=(WORK.sokol&&WORK.type!=='desk')?100:0;
  const y0=s+t,y1=WORK.H-t;
  const arr=(WORK.secShelves[sec]||[]).slice().sort((a,b)=>a-b);
  let bg=0,by=(y0+y1)/2,prev=y0;
  [...arr,y1].forEach(y=>{if(y-prev>bg){bg=y-prev;by=(prev+y)/2}prev=y});
  if(bg<60)return;
  arr.push(Math.round(by));arr.sort((a,b)=>a-b);
  WORK.secShelves[sec]=arr;
  afterEdit();
}
function delShelf(sec,j){
  WORK.secShelves[sec].splice(j,1);
  if(SEL&&SEL.kind==='shelf'&&SEL.sec===sec&&SEL.idx===j){SEL=null;g('selbar').classList.remove('on')}
  afterEdit();
}
function moveShelf(sec,j,mm){
  const t=tt(),s=(WORK.sokol&&WORK.type!=='desk')?100:0;
  WORK.secShelves[sec][j]=clamp(snap(mm),s+t+20,WORK.H-t-20);
  afterEdit();
}
function setDoors(n){WORK.doors=clamp(n|0,0,8);afterEdit()}
function setDrawers(n){WORK.drawers=clamp(n|0,0,8);afterEdit()}

function updQ(){
  if(!WORK||WORK.type==='custom')return;
  const d=g('qDoors'),w=g('qDraw'),c=g('qSec');
  if(d)d.textContent=WORK.doors;
  if(w)w.textContent=WORK.drawers;
  if(c)c.textContent=WORK.divPos.length+1;
}
/* mebelni teng bo'limlarga bo'lish */
function splitEven(){
  const t=tt(), n=WORK.divPos.length+2;   // bitta ko'paytiramiz
  if((WORK.W-2*t)/n<120){alert('Bo\'lim juda tor bo\'lib qoladi');return}
  const step=(WORK.W-2*t)/n, pos=[];
  for(let i=1;i<n;i++)pos.push(Math.round(t+step*i));
  const keep=(WORK.secShelves[0]||[]).slice();
  WORK.divPos=pos;
  WORK.secShelves=pos.map(()=>keep.slice()).concat([keep.slice()]);
  afterEdit();
}
function syncToInputs(){
  if(WORK.type==='custom')return;
  SYNC=true;
  g('W').value=WORK.W;g('H').value=WORK.H;g('D').value=WORK.D;
  g('doors').value=WORK.doors;g('drawers').value=WORK.drawers;
  g('divs').value=WORK.divPos.length;
  g('shelves').value=Math.max(...WORK.secShelves.map(a=>a.length),0);
  g('name').value=WORK.name;
  SYNC=false;
}

/* ================= INTERAKTIV ================= */
function hit(mx,my){
  for(let i=CTRLS.length-1;i>=0;i--){
    const c=CTRLS[i];
    if((mx-c.x)**2+(my-c.y)**2<=(c.r+4)**2)return c;
  }
  return null;
}
/* Tanlangan detalni to'g'ridan-to'g'ri sudrash uchun o'q va chegaralar */
function dragSpec(sel){
  if(!sel||!WORK||WORK.type==='custom')return null;
  const t=tt(), s0=(WORK.sokol&&WORK.type!=='desk')?100:0;
  if(sel.kind==='shelf'){
    const arr=WORK.secShelves[sel.sec]||[];
    if(arr[sel.idx]===undefined)return null;
    return {axis:[0,1,0], at:()=>[0,arr[sel.idx],0],
      get:()=>arr[sel.idx], set:mm=>moveShelf(sel.sec,sel.idx,mm),
      lo:s0+t+20, hi:WORK.H-t-20, unit:'balandlik'};
  }
  if(sel.kind==='div'){
    if(WORK.divPos[sel.idx]===undefined)return null;
    const lo=(sel.idx>0?WORK.divPos[sel.idx-1]:t)+60;
    const hi=(sel.idx<WORK.divPos.length-1?WORK.divPos[sel.idx+1]:WORK.W-t)-60;
    return {axis:[1,0,0], at:()=>[WORK.divPos[sel.idx],0,0],
      get:()=>WORK.divPos[sel.idx], set:mm=>moveDiv(sel.idx,mm),
      lo,hi, unit:'chapdan'};
  }
  if(sel.kind==='door'){
    return {axis:'door', get:()=>(WORK.doorOpen[sel.idx]||0),
      set:d=>setDoorOpen(sel.idx,d), lo:0, hi:110, unit:'ochilish'};
  }
  if(sel.kind==='drawer'){
    return {axis:'drawer', get:()=>(WORK.drawOpen[sel.idx]||0),
      set:d=>setDrawOpen(sel.idx,d), lo:0, hi:1, unit:'chiqish'};
  }
  return null;
}
function setDoorOpen(i,deg){
  WORK.doorOpen=WORK.doorOpen||[];
  WORK.doorOpen[i]=clamp(Math.round(deg),0,110);
  afterEdit();
}
function setDrawOpen(i,f){
  WORK.drawOpen=WORK.drawOpen||[];
  WORK.drawOpen[i]=clamp(f,0,1);
  afterEdit();
}
function openAllDoors(){
  const any=(WORK.doorOpen||[]).some(d=>d>5);
  WORK.doorOpen=[];
  for(let i=0;i<WORK.doors;i++) WORK.doorOpen[i]=any?0:95;
  afterEdit();
}
function toggleDoor(i){ setDoorOpen(i,(WORK.doorOpen[i]||0)>5?0:95) }
function toggleDrawer(i){ setDrawOpen(i,(WORK.drawOpen[i]||0)>0.05?0:1) }
function ptInQuad(q,x,y){
  let c=false;
  for(let i=0,j=3;i<4;j=i++){
    const xi=q[i][0],yi=q[i][1],xj=q[j][0],yj=q[j][1];
    if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)c=!c;
  }
  return c;
}
/* eng ustki (oxirgi chizilgan) detalni topish */
function pickPart(mx,my){
  let best=null;
  for(const f of PICK){
    if(!ptInQuad(f.q,mx,my))continue;
    if(!best||f.ord>best.ord)best=f;
  }
  return best;
}
function selLabel(sel){
  if(!sel)return['—',''];
  const t=tt();
  if(sel.kind==='shelf'){
    const secs=sections(WORK,t), sc=secs[sel.sec]||[0,0];
    const y=(WORK.secShelves[sel.sec]||[])[sel.idx];
    return ['Polka','bo\'lim '+(sel.sec+1)+' · '+Math.round(sc[1]-sc[0]-2)+' mm eni · balandlik '+Math.round(y)+' mm'];
  }
  if(sel.kind==='div') return ["Vertikal bo'luvchi",'pozitsiya '+Math.round(WORK.divPos[sel.idx])+' mm'];
  if(sel.kind==='door'){
    const d=doorSpans(WORK)[sel.idx]||[0,0];
    return ['Fasad (eshik) #'+(sel.idx+1),Math.round(d[1]-d[0])+' mm eni'];
  }
  if(sel.kind==='drawer') return ['Yashik fasadi #'+(sel.idx+1),WORK.drawers+' yashikdan biri'];
  return ['Detal',''];
}
function setSel(sel){
  SEL=sel;
  const bar=g('selbar');
  if(!sel){bar.classList.remove('on');draw();return}
  const[nm,ds]=selLabel(sel);
  g('selName').textContent=nm;
  g('selDim').textContent=ds;
  let b='';
  if(sel.kind==='shelf')
    b='<button class="sb sb-add" onclick="addShelf('+sel.sec+')">➕ Yana polka</button>'+
      '<button class="sb sb-del" onclick="delShelf('+sel.sec+','+sel.idx+');setSel(null)">🗑 Polkani o\'chirish</button>';
  else if(sel.kind==='div')
    b='<button class="sb sb-add" onclick="splitEven()">⊞ Yana bo\'lish</button>'+
      '<button class="sb sb-del" onclick="delDiv('+sel.idx+');setSel(null)">🗑 Bo\'luvchini o\'chirish</button>';
  else if(sel.kind==='door'){
    const op=(WORK.doorOpen||[])[sel.idx]||0;
    b='<button class="sb sb-open" onclick="toggleDoor('+sel.idx+')">'+
        (op>5?'🚪 Yopish':'🚪 Ochish')+'</button>'+
      '<button class="sb sb-off" onclick="openAllDoors()">🚪 Hammasini ochish</button>'+
      '<button class="sb sb-add" onclick="setDoors(WORK.doors+1)">➕ Eshik</button>'+
      '<button class="sb sb-del" onclick="setDoors(WORK.doors-1);setSel(null)">🗑 Kamaytirish</button>';
  }
  else if(sel.kind==='drawer'){
    const op=(WORK.drawOpen||[])[sel.idx]||0;
    b='<button class="sb sb-open" onclick="toggleDrawer('+sel.idx+')">'+
        (op>0.05?'📥 Yopish':'📤 Chiqarish')+'</button>'+
      '<button class="sb sb-add" onclick="setDrawers(WORK.drawers+1)">➕ Yashik</button>'+
      '<button class="sb sb-del" onclick="setDrawers(WORK.drawers-1);setSel(null)">🗑 Kamaytirish</button>';
  }
  g('selBtns').innerHTML=b;
  bar.classList.add('on');
  draw();
}
function relPos(e){
  const r=g('cv').getBoundingClientRect();
  return [e.clientX-r.left, e.clientY-r.top];
}
(function bind(){
  const st=g('stage');let rot=false,lx=0,ly=0;
  st.addEventListener('pointerdown',e=>{
    const [mx,my]=relPos(e); const c=hit(mx,my);
    st.setPointerCapture(e.pointerId);
    if(c && !c.dim){
      if(c.kind==='btn'){c.click();return}
      DRAG={c,x0:mx,y0:my,v0:c.get()};draw();return;
    }
    // detalni bosish / sudrash
    const hitP=pickPart(mx,my);
    if(hitP){
      if(!sameSel(hitP.sel,SEL)) setSel(hitP.sel);
      const sp=dragSpec(hitP.sel);
      if(sp){
        let ax=null;
        if(sp.axis==='door'||sp.axis==='drawer'){
          ax={sx:1,sy:0};   // gorizontal surish
          const q=hitP.q, c0=[q.reduce((a,b)=>a+b[0],0)/4,q.reduce((a,b)=>a+b[1],0)/4];
          PDRAG={sel:hitP.sel,sp,x0:mx,y0:my,v0:sp.get(),mode:sp.axis,c0};
        } else {
          const p0=PROJ(...sp.at());
          const e=6, A2=sp.axis;
          const p1=PROJ(sp.at()[0]+A2[0]*e, sp.at()[1]+A2[1]*e, sp.at()[2]+A2[2]*e);
          ax={sx:(p1[0]-p0[0])/e, sy:(p1[1]-p0[1])/e};
          PDRAG={sel:hitP.sel,sp,x0:mx,y0:my,v0:sp.get(),mode:'lin',ax};
        }
        MOVED=false;
        st.classList.add('drag');
        return;
      }
      return;
    }
    setSel(null);
    rot=true;lx=e.clientX;ly=e.clientY;st.classList.add('drag');
  });
  st.addEventListener('pointermove',e=>{
    const [mx,my]=relPos(e);
    if(DRAG){
      const c=DRAG.c,dx=mx-DRAG.x0,dy=my-DRAG.y0;
      const den=c.ax.sx*c.ax.sx+c.ax.sy*c.ax.sy;
      if(den>1e-9) c.set(DRAG.v0+0.45*(dx*c.ax.sx+dy*c.ax.sy)/den);
      return;
    }
    if(PDRAG){
      const dx=mx-PDRAG.x0, dy=my-PDRAG.y0;
      if(Math.abs(dx)+Math.abs(dy)>3) MOVED=true;
      if(PDRAG.mode==='lin'){
        const a=PDRAG.ax, den=a.sx*a.sx+a.sy*a.sy;
        if(den>1e-9) PDRAG.sp.set(PDRAG.v0+0.45*(dx*a.sx+dy*a.sy)/den);
      } else if(PDRAG.mode==='door'){
        PDRAG.sp.set(PDRAG.v0+dx*0.55);
      } else {
        PDRAG.sp.set(PDRAG.v0+dx*0.006);
      }
      return;
    }
    if(rot){
      yaw+=(e.clientX-lx)*0.0095; pitch+=(e.clientY-ly)*0.0075;
      pitch=Math.max(-1.45,Math.min(1.45,pitch));
      lx=e.clientX;ly=e.clientY;draw();return;
    }
    const c=hit(mx,my);
    if(c&&!c.dim){st.classList.add('over');g('tip').textContent='👉 '+c.tip;return}
    const hp=pickPart(mx,my);
    st.classList.toggle('over',!!hp);
    g('tip').textContent=hp?('👉 '+hp.nm+' — bosib tanlang')
      :'🖱 Detalni bosing · bo\'sh joyni surib aylantiring';
  });
  const up=()=>{
    if(PDRAG){
      if(!MOVED){ // sudralmadi -> bosish deb hisoblaymiz
        if(PDRAG.sel.kind==='door') toggleDoor(PDRAG.sel.idx);
        else if(PDRAG.sel.kind==='drawer') toggleDrawer(PDRAG.sel.idx);
      }
      PDRAG=null;MOVED=false;draw();
    }
    if(DRAG){DRAG=null;draw()}
    rot=false;st.classList.remove('drag');
  };
  st.addEventListener('pointerup',up);st.addEventListener('pointercancel',up);
  st.addEventListener('wheel',e=>{e.preventDefault();
    zoom*=e.deltaY<0?1.11:0.9;zoom=Math.max(0.3,Math.min(6,zoom));draw()},{passive:false});
  window.addEventListener('resize',resize);
})();
function resize(){
  const cv=g('cv'),st=g('stage');
  const fs=document.fullscreenElement===st||document.webkitFullscreenElement===st;
  const w=st.clientWidth||600;
  const h=fs?(st.clientHeight||window.innerHeight):Math.max(340,Math.min(500,Math.round(w*0.70)));
  const dpr=window.devicePixelRatio||1;
  cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);
  cv.style.width=w+'px';cv.style.height=h+'px';
  cv.getContext('2d').setTransform(dpr,0,0,dpr,0,0);
  draw();
}
function toggleFS(){
  const el=g('stage');
  const isFS=document.fullscreenElement||document.webkitFullscreenElement;
  if(!isFS){
    const rq=el.requestFullscreen||el.webkitRequestFullscreen||el.msRequestFullscreen;
    if(rq)rq.call(el); else alert('Brauzer to\'liq ekranni qo\'llamaydi');
  } else {
    const ex=document.exitFullscreen||document.webkitExitFullscreen;
    if(ex)ex.call(document);
  }
}
['fullscreenchange','webkitfullscreenchange'].forEach(ev=>
  document.addEventListener(ev,()=>{setTimeout(resize,60)}));
function setView(y,p){yaw=y;pitch=p;draw()}
function zoomBy(f){zoom=Math.max(0.3,Math.min(6,zoom*f));draw()}
function toggleSpin(){
  const b=g('spinBtn');
  if(spinId){cancelAnimationFrame(spinId);spinId=null;b.textContent='▶ Aylantirish';b.classList.remove('on');return}
  b.textContent='⏸ To\'xtatish';b.classList.add('on');
  const loop=()=>{yaw+=0.009;draw();spinId=requestAnimationFrame(loop)};
  spinId=requestAnimationFrame(loop);
}

/* ================= RASKROY ================= */
function nest(parts,SW,SH,kerf,grain){
  const list=[];
  parts.forEach(p=>{for(let i=0;i<p.q;i++)list.push({nm:p.nm,L:p.L,B:p.B,cat:p.cat})});
  list.sort((a,b)=>Math.max(b.L,b.B)-Math.max(a.L,a.B)||b.L*b.B-a.L*a.B);
  const sheets=[];
  for(const it of list){
    let done=false;
    for(const sh of sheets){if(place(sh,it,kerf,grain)){done=true;break}}
    if(!done){const sh={free:[{x:0,y:0,w:SW,h:SH}],parts:[]};
      if(!place(sh,it,kerf,grain))sh.over=true;sheets.push(sh)}
  }
  return sheets;
}
function place(sh,it,k,grain){
  const opts=grain?[[it.L,it.B,0]]:[[it.L,it.B,0],[it.B,it.L,1]];
  let best=null;
  for(const f of sh.free)for(const[w,h,r]of opts){
    if(w<=f.w+0.01&&h<=f.h+0.01){const sc=Math.min(f.w-w,f.h-h);
      if(!best||sc<best.s)best={f,w,h,r,s:sc}}}
  if(!best)return false;
  const{f,w,h,r}=best;
  sh.parts.push({nm:it.nm,x:f.x,y:f.y,w,h,rot:r,cat:it.cat});
  sh.free.splice(sh.free.indexOf(f),1);
  if(f.w-w-k>0)sh.free.push({x:f.x+w+k,y:f.y,w:f.w-w-k,h:h});
  if(f.h-h-k>0)sh.free.push({x:f.x,y:f.y+h+k,w:f.w,h:f.h-h-k});
  return true;
}

function calc(){
  const t=tt(),SW=iv('sheetW'),SH=iv('sheetH'),kerf=iv('kerf'),grain=gc('grain');
  const pS=v('priceSheet'),pE=v('priceEdge');
  const use=ITEMS.slice();
  if(WORK&&!use.includes(WORK)) use.push(WORK);
  if(!use.length){g('out').innerHTML='<div class="card"><div class="empty">Mebel yo\'q.</div></div>';return}
  let all=[];
  use.forEach(it0=>{
    const it=normItem(it0);
    if(it.type==='custom')
      all.push({src:it.name,nm:it.name,L:it.L,B:it.B,q:it.q,e1:it.e1,e2:it.e2,cat:'korpus'});
    else buildParts(it,t).forEach(p=>all.push({src:it.name,...p,q:p.q*(it.qty||1)}));
  });
  const map={};
  all.forEach(p=>{const k=p.src+'|'+p.nm+'|'+p.L+'|'+p.B;if(map[k])map[k].q+=p.q;else map[k]={...p}});
  const parts=Object.values(map);
  const ldsp=parts.filter(p=>p.cat!=='hdf');
  let areaL=0,areaH=0,edge=0;
  parts.forEach(p=>{const a=p.L*p.B*p.q/1e6;
    if(p.cat==='hdf')areaH+=a;else areaL+=a;
    edge+=((p.e1||0)*p.L+(p.e2||0)*p.B)*p.q/1000});
  const sheets=nest(ldsp,SW,SH,kerf,grain),nSheet=sheets.length;
  const used=nSheet?(areaL/(nSheet*SW*SH/1e6)*100):0;
  const hdfSheets=Math.ceil(areaH/(2.75*1.83))||0;
  const totPart=parts.reduce((s,p)=>s+p.q,0);
  const cost=nSheet*pS+edge*pE;

  let h=`<div class="stats">
    <div class="stat"><div class="v">${nSheet}</div><div class="l">LDSP list (${SW}×${SH})</div></div>
    <div class="stat"><div class="v">${areaL.toFixed(2)}</div><div class="l">m² LDSP</div></div>
    <div class="stat"><div class="v">${used.toFixed(1)}%</div><div class="l">Foydalanish</div></div>
    <div class="stat"><div class="v">${edge.toFixed(1)}</div><div class="l">metr kromka</div></div>
    <div class="stat"><div class="v">${totPart}</div><div class="l">jami detal</div></div>
    <div class="stat"><div class="v">${hdfSheets}</div><div class="l">HDF list (${areaH.toFixed(2)} m²)</div></div>
  </div>`;
  h+=`<div class="card"><h2>💰 Xarajat</h2><table>
    <tr><td>LDSP: ${nSheet} list × ${fmt(pS)}</td><td style="text-align:right"><b>${fmt(nSheet*pS)}</b></td></tr>
    <tr><td>Kromka: ${edge.toFixed(1)} m × ${fmt(pE)}</td><td style="text-align:right"><b>${fmt(edge*pE)}</b></td></tr>
    <tr><td style="font-size:15px"><b>JAMI (furnitura/ish haqisiz)</b></td>
    <td style="text-align:right;font-size:16px;color:#7b4b28"><b>${fmt(cost)} so'm</b></td></tr></table>
    <div class="note">⚠️ Furnitura, HDF va ish haqi alohida. Kromkani +10% zapas bilan oling ≈ <b>${(edge*1.1).toFixed(1)} m</b>.</div></div>`;
  h+=`<div class="card"><h2>📋 Detallar ro'yxati</h2><table>
    <tr><th>#</th><th>Mebel</th><th>Detal</th><th>Uzunlik</th><th>Kenglik</th><th>Soni</th><th>m²</th><th>Kromka</th><th>Tur</th></tr>`;
  parts.forEach((p,i)=>{
    const ed=[];if(p.e1)ed.push(p.e1+'×'+p.L);if(p.e2)ed.push(p.e2+'×'+p.B);
    h+=`<tr><td>${i+1}</td><td style="font-size:11px;color:#7b8698">${p.src}</td>
      <td><b>${p.nm}</b></td><td>${p.L}</td><td>${p.B}</td><td><b>${p.q}</b></td>
      <td>${(p.L*p.B*p.q/1e6).toFixed(3)}</td><td style="font-size:11px">${ed.join(' + ')||'—'}</td>
      <td><span class="tag t-${p.cat}">${p.cat}</span></td></tr>`});
  h+=`</table><div class="note">Kromka: <b>2×800</b> = 800 mm tomonga 2 ta. Qalinlik ${t} mm hisobga olingan.</div></div>`;
  h+=`<div class="card"><h2>✂️ Kroy sxemasi</h2><div class="legend">
    <span><i style="background:#93c5fd"></i>Korpus</span><span><i style="background:#fcd9a8"></i>Fasad</span>
    <span><i style="background:#a7e3c0"></i>Polka</span><span><i style="background:#e9e2f5"></i>Bo'sh</span></div>`;
  const COL={korpus:'#93c5fd',fasad:'#fcd9a8',polka:'#a7e3c0',hdf:'#c9b8e8'};
  sheets.forEach((sh,i)=>{
    const sc=1000/SW,vh=SH*sc;let ua=0;
    let svg=`<svg viewBox="0 0 1000 ${vh.toFixed(0)}"><rect width="1000" height="${vh}" fill="#f3eef8" stroke="#c4b5d8"/>`;
    sh.parts.forEach(p=>{ua+=p.w*p.h;
      const x=p.x*sc,y=p.y*sc,w=p.w*sc,hh=p.h*sc;
      const fs=Math.max(7,Math.min(13,Math.min(w/6,hh/2.6)));
      svg+=`<rect x="${x}" y="${y}" width="${w}" height="${hh}" fill="${COL[p.cat]||'#ddd'}" stroke="#334155" stroke-width="1.2"/>`;
      if(w>42&&hh>17){svg+=`<text x="${x+w/2}" y="${y+hh/2-1}" font-size="${fs}" text-anchor="middle" fill="#1c2431" font-weight="700" font-family="Arial">${p.w}×${p.h}</text>`;
        if(hh>34)svg+=`<text x="${x+w/2}" y="${y+hh/2+fs+1}" font-size="${fs*0.82}" text-anchor="middle" fill="#475569" font-family="Arial">${p.nm}${p.rot?' ↻':''}</text>`}});
    svg+=`</svg>`;
    h+=`<div class="sheet-box"><div class="sheet-title">List ${i+1}/${nSheet} — ${SW}×${SH} mm — ${(ua/(SW*SH)*100).toFixed(1)}% — ${sh.parts.length} detal</div>${svg}</div>`});
  h+=`<div class="note">↻ — detal 90° burilgan. Arra keni ${kerf} mm hisobga olingan.</div></div>`;
  h+=`<div class="card no-print"><div class="btn-row">
      <button class="btn-sm" onclick="window.print()">🖨 Chop etish / PDF</button>
      <button class="btn-sm" onclick="expCSV()">📄 CSV yuklab olish</button></div></div>`;
  g('out').innerHTML=h;window.LAST=parts;
  g('out').scrollIntoView({behavior:'smooth',block:'start'});
}
function fmt(n){return Math.round(n).toLocaleString('ru-RU')}

/* ================= RO'YXAT ================= */
function onType(){
  const t=g('type').value,cu=t==='custom';
  g('paramBlock').classList.toggle('hide',cu);
  g('customBlock').classList.toggle('hide',!cu);
  if(!cu){const p=PRESETS[t];SYNC=true;
    g('name').value=p.name;g('W').value=p.W;g('H').value=p.H;g('D').value=p.D;
    g('shelves').value=p.shelves;g('doors').value=p.doors;g('drawers').value=p.drawers;
    g('divs').value=p.divs;g('back').checked=!!p.back;g('sokol').checked=!!p.sokol;SYNC=false;}
  g('viewSel').value='-1';
  WORK=makeWork(t);draw();
}
function onSel(){
  const i=parseInt(g('viewSel').value);
  if(i>=0&&ITEMS[i]){WORK=normItem(ITEMS[i]);
    if(WORK.type!=='custom'){SYNC=true;g('type').value=WORK.type;SYNC=false;
      g('paramBlock').classList.remove('hide');g('customBlock').classList.add('hide');}
    syncToInputs();
  } else WORK=makeWork(g('type').value);
  render();draw();
}
function addItem(){
  const cp=JSON.parse(JSON.stringify(WORK));
  ITEMS.push(cp);
  WORK=makeWork(g('type').value);
  g('viewSel').value='-1';
  render();draw();save();
}
function render(){
  const el=g('items');
  const cur=parseInt(g('viewSel').value);
  el.innerHTML=ITEMS.length?ITEMS.map((it0,i)=>{
    const it=normItem(it0);
    const d=it.type==='custom'?`${it.L}×${it.B} mm · ${it.q} dona`
      :`${it.W}×${it.H}×${it.D} · ${it.secShelves.reduce((s,a)=>s+a.length,0)} polka · `+
       `${it.divPos.length+1} bo'lim · ${it.doors} eshik`+(it.drawers?` · ${it.drawers} yashik`:'')+
       (it.qty>1?` · ×${it.qty}`:'');
    return `<div class="item${i===cur?' sel':''}" onclick="pick(${i})">
      <div><div class="nm">${it.name}</div><div class="ds">${d}</div></div>
      <button class="x" onclick="event.stopPropagation();del(${i})">×</button></div>`}).join('')
    :'<div class="empty">Hozircha bo\'sh</div>';
  const sel=g('viewSel');const keep=sel.value;
  sel.innerHTML='<option value="-1">⚙️ Yangi mebel (tahrirlanmoqda)</option>'+
    ITEMS.map((it,i)=>`<option value="${i}">${i+1}. ${it.name}</option>`).join('');
  sel.value=(ITEMS[keep]!==undefined)?keep:'-1';
}
function pick(i){g('viewSel').value=String(i);onSel()}
function del(i){
  const cur=parseInt(g('viewSel').value);
  ITEMS.splice(i,1);
  if(cur===i){g('viewSel').value='-1';WORK=makeWork(g('type').value)}
  render();draw();save();
}
function clearAll(){if(confirm('Ro\'yxat tozalansinmi?')){ITEMS=[];g('viewSel').value='-1';
  WORK=makeWork(g('type').value);render();draw();save();
  g('out').innerHTML='<div class="card"><div class="empty">Ro\'yxat bo\'sh.</div></div>'}}
function save(){try{localStorage.setItem('mebel3',JSON.stringify(ITEMS))}catch(e){}}
function saveProj(){save();alert('Loyiha saqlandi ✔')}
function load(){try{const d=localStorage.getItem('mebel3');if(d)ITEMS=JSON.parse(d)||[]}catch(e){ITEMS=[]}}
function expCSV(){
  if(!window.LAST)return;
  let c='\uFEFFN;Mebel;Detal;Uzunlik;Kenglik;Soni;m2;Kromka uzun;Kromka qisqa\n';
  window.LAST.forEach((p,i)=>{c+=`${i+1};${p.src};${p.nm};${p.L};${p.B};${p.q};${(p.L*p.B*p.q/1e6).toFixed(3)};${p.e1||0};${p.e2||0}\n`});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([c],{type:'text/csv;charset=utf-8'}));
  a.download='kroy.csv';a.click();
}

/* forma -> model */
['name','W','H','D','shelves','doors','drawers','divs','back','sokol','qty','thk',
 'cName','cL','cW','cQ','cE1','cE2'].forEach(id=>{
  const e=g(id);if(!e)return;
  const f=()=>{if(SYNC)return;
    const keepName=g('type').value!=='custom';
    WORK=makeWork(g('type').value);
    const i=parseInt(g('viewSel').value);
    if(i>=0&&ITEMS[i]){ITEMS[i]=WORK;render()}
    draw();save()};
  e.addEventListener('input',f);e.addEventListener('change',f);
});

load();WORK=makeWork('wardrobe');render();onType();updQ();resize();
</script>
</body>
</html>

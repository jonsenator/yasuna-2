// ===== Mobil menyu =====
(function(){
  var burger = document.querySelector('.burger');
  var nav = document.querySelector('.mainnav');
  if (burger && nav){
    burger.addEventListener('click', function(){
      nav.classList.toggle('open');
      burger.classList.toggle('active');
      document.body.classList.toggle('no-scroll', nav.classList.contains('open'));
    });
  }
  // Bosilmaydigan menyu: sahifa tepaga sakramasin
  document.querySelectorAll('.mainnav a.no-link').forEach(function(a){
    a.addEventListener('click', function(e){ e.preventDefault(); });
  });
  // Mobil menyu tashqarisiga bosilsa — yopiladi
  document.addEventListener('click', function(e){
    if (nav && nav.classList.contains('open') && !nav.contains(e.target) && !burger.contains(e.target)){
      nav.classList.remove('open'); burger.classList.remove('active');
      document.body.classList.remove('no-scroll');
    }
  });
  // Mobilda dropdown ochish (istalgan chuqurlikda: 2-, 3-daraja)
  document.querySelectorAll('.mainnav .has-sub > a').forEach(function(a){
    a.addEventListener('click', function(e){
      if (window.innerWidth <= 760){
        var li = a.parentElement;
        var href = a.getAttribute('href') || '';
        // Bosiladigan havola bo'lsa: birinchi bosishda ochamiz, ikkinchisida o'tamiz
        var justLink = href && href !== '#' && li.classList.contains('open-sub');
        if (!justLink){
          e.preventDefault();
          e.stopPropagation();
          li.classList.toggle('open-sub');
        }
      }
    });
  });
})();

// ===== Qidiruv paneli =====
(function(){
  var t = document.querySelector('.search-toggle');
  var p = document.getElementById('searchPanel');
  if (t && p){
    t.addEventListener('click', function(e){
      e.stopPropagation();
      p.classList.toggle('open');
      t.classList.toggle('active');
      if (p.classList.contains('open')) p.querySelector('input').focus();
    });
    document.addEventListener('click', function(e){
      if (p.classList.contains('open') && !p.contains(e.target) && !t.contains(e.target)){
        p.classList.remove('open'); t.classList.remove('active');
      }
    });
  }
})();

// ===== Hero slayder =====
(function(){
  var slider = document.querySelector('.slider');
  if (!slider) return;
  var slides = slider.querySelectorAll('.slide');
  var dots = slider.querySelectorAll('.dots button');
  if (slides.length <= 1) return;
  var i = 0, timer;

  function show(n){
    slides[i].classList.remove('active');
    if (dots[i]) dots[i].classList.remove('active');
    i = (n + slides.length) % slides.length;
    slides[i].classList.add('active');
    if (dots[i]) dots[i].classList.add('active');
  }
  function next(){ show(i+1); }
  function prev(){ show(i-1); }
  function restart(){ clearInterval(timer); timer = setInterval(next, 6000); }

  var nb = slider.querySelector('.slider-btn.next');
  var pb = slider.querySelector('.slider-btn.prev');
  if (nb) nb.addEventListener('click', function(){ next(); restart(); });
  if (pb) pb.addEventListener('click', function(){ prev(); restart(); });
  dots.forEach(function(d, idx){
    d.addEventListener('click', function(){ show(idx); restart(); });
  });

  // touch swipe
  var x0 = null;
  slider.addEventListener('touchstart', function(e){ x0 = e.touches[0].clientX; }, {passive:true});
  slider.addEventListener('touchend', function(e){
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 40){ dx < 0 ? next() : prev(); restart(); }
    x0 = null;
  }, {passive:true});

  restart();
})();

// ===== Ko'rinish (reveal) animatsiya =====
(function(){
  var els = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)){ els.forEach(function(e){e.classList.add('in');}); return; }
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if (en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); }
    });
  }, {threshold: .12});
  els.forEach(function(e){ io.observe(e); });
})();

// ===== Rahbariyat: Mehnat faoliyati / Vazifalari tablari =====
(function(){
  document.querySelectorAll('[data-tabs]').forEach(function(w){
    var tabs = w.querySelectorAll('[role=tab]');
    function open(i){
      tabs.forEach(function(t, j){
        t.setAttribute('aria-selected', j === i ? 'true' : 'false');
        var p = document.getElementById(t.getAttribute('aria-controls'));
        if (p) p.hidden = j !== i;
      });
    }
    tabs.forEach(function(t, i){ t.addEventListener('click', function(){ open(i); }); });
    open(0);
  });
})();
/* ============================================================
   yasuna.uz — Saytdagi rasmlardan tanlash oynasi
   Ishlatish:  MediaPicker.open(function (item) { item.name, item.url });
   Ro'yxat manbasi: window.MEDIA_URL (admin/media.php)
   ============================================================ */
window.MediaPicker = (function () {
  'use strict';
  var modal, grid, search, info, chooseBtn, cb, selected = null, items = [], timer;

  function fmtSize(b) {
    return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
  }
  function fmtDate(t) {
    var d = new Date(t * 1000);
    return ('0' + d.getDate()).slice(-2) + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + d.getFullYear();
  }

  function build() {
    modal = document.createElement('div');
    modal.className = 'mp-modal';
    modal.hidden = true;
    modal.innerHTML =
      '<div class="mp-dialog" role="dialog" aria-modal="true" aria-label="Saytdagi rasmlar">' +
        '<div class="mp-head">' +
          '<h3>Saytdagi rasmlar</h3>' +
          '<input type="search" class="mp-search" placeholder="Fayl nomi bo‘yicha qidirish…">' +
          '<button type="button" class="mp-x" aria-label="Yopish">✕</button>' +
        '</div>' +
        '<div class="mp-grid"></div>' +
        '<div class="mp-foot">' +
          '<span class="mp-info">Rasmni tanlang</span>' +
          '<button type="button" class="btn gray mp-cancel">Bekor qilish</button>' +
          '<button type="button" class="btn mp-choose" disabled>Tanlash</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(modal);

    grid = modal.querySelector('.mp-grid');
    search = modal.querySelector('.mp-search');
    info = modal.querySelector('.mp-info');
    chooseBtn = modal.querySelector('.mp-choose');

    modal.addEventListener('click', function (e) { if (e.target === modal) close(); });
    modal.querySelector('.mp-x').addEventListener('click', close);
    modal.querySelector('.mp-cancel').addEventListener('click', close);
    chooseBtn.addEventListener('click', choose);
    document.addEventListener('keydown', function (e) { if (!modal.hidden && e.key === 'Escape') close(); });
    search.addEventListener('input', function () {
      clearTimeout(timer);
      timer = setTimeout(function () { load(search.value.trim()); }, 250);
    });
    grid.addEventListener('click', function (e) {
      var el = e.target.closest('.mp-item');
      if (!el) return;
      select(+el.dataset.i);
    });
    grid.addEventListener('dblclick', function (e) {
      var el = e.target.closest('.mp-item');
      if (el) { select(+el.dataset.i); choose(); }
    });
  }

  function select(i) {
    selected = items[i];
    grid.querySelectorAll('.mp-item').forEach(function (x) { x.classList.toggle('sel', +x.dataset.i === i); });
    info.textContent = selected.name + ' · ' + fmtSize(selected.size) + ' · ' + fmtDate(selected.time);
    chooseBtn.disabled = false;
  }

  function render() {
    if (!items.length) {
      grid.innerHTML = '<div class="mp-empty">Rasm topilmadi</div>';
      return;
    }
    grid.innerHTML = items.map(function (it, i) {
      return '<button type="button" class="mp-item" data-i="' + i + '" title="' + it.name.replace(/"/g, '&quot;') + '">' +
               '<img src="' + it.url + '" alt="" loading="lazy">' +
               '<span>' + it.name.replace(/</g, '&lt;') + '</span>' +
             '</button>';
    }).join('');
  }

  function load(q) {
    grid.innerHTML = '<div class="mp-empty">Yuklanmoqda…</div>';
    selected = null; chooseBtn.disabled = true; info.textContent = 'Rasmni tanlang';
    fetch((window.MEDIA_URL || 'media.php') + '?q=' + encodeURIComponent(q || ''), { credentials: 'same-origin' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (d) { items = d.items || []; render(); })
      .catch(function () { grid.innerHTML = '<div class="mp-empty">Ro‘yxatni olib bo‘lmadi. Sahifani yangilab ko‘ring.</div>'; });
  }

  function choose() {
    if (!selected) return;
    var s = selected, f = cb;
    close();
    if (f) f(s);
  }

  function open(callback) {
    if (!modal) build();
    cb = callback;
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    search.value = '';
    load('');
    setTimeout(function () { search.focus(); }, 50);
  }

  function close() {
    modal.hidden = true;
    document.body.style.overflow = '';
  }

  return { open: open, close: close };
})();
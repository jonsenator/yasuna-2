/* ============================================================
   yasuna.uz — Vizual matn muharriri (WYSIWYG)
   Tashqi kutubxona kerak emas. contenteditable asosida.
   Ishlatish:  <textarea class="editor"> yonida avtomatik ishga tushadi
   ============================================================ */
(function () {
  'use strict';

  var TA = document.querySelector('textarea.editor');
  if (!TA) return;

  // Eski oddiy panelni olib tashlaymiz (agar bo'lsa)
  var oldBar = document.querySelector('.editor-toolbar');
  if (oldBar) oldBar.parentNode.removeChild(oldBar);

  // ---------- Tuzilma yaratish ----------
  var wrap = document.createElement('div');
  wrap.className = 'wys';

  var bar = document.createElement('div');
  bar.className = 'wys-bar';

  var area = document.createElement('div');
  area.className = 'wys-area';
  area.setAttribute('contenteditable', 'true');
  area.setAttribute('spellcheck', 'false');

  var src = document.createElement('textarea');
  src.className = 'wys-src';
  src.style.display = 'none';

  TA.parentNode.insertBefore(wrap, TA);
  wrap.appendChild(bar);
  wrap.appendChild(area);
  wrap.appendChild(src);
  TA.style.display = 'none';

  area.innerHTML = TA.value || '';

  // ---------- Tugmalar ----------
  var BTNS = [
    { t: 'B',  cmd: 'bold',            title: 'Qalin (Ctrl+B)', css: 'font-weight:800' },
    { t: 'I',  cmd: 'italic',          title: 'Qiya (Ctrl+I)',  css: 'font-style:italic' },
    { t: 'U',  cmd: 'underline',       title: 'Tagi chizilgan', css: 'text-decoration:underline' },
    { sep: 1 },
    { t: 'H2', block: 'h2',            title: 'Katta sarlavha' },
    { t: 'H3', block: 'h3',            title: 'O\u2018rta sarlavha' },
    { t: '\u00B6', block: 'p',         title: 'Oddiy xatboshi' },
    { sep: 1 },
    { t: '\u2022 Ro\u2018yxat', cmd: 'insertUnorderedList', title: 'Belgili ro\u2018yxat' },
    { t: '1. Ro\u2018yxat', cmd: 'insertOrderedList',       title: 'Raqamli ro\u2018yxat' },
    { sep: 1 },
    { t: 'Havola', act: 'link',   title: 'Havola qo\u2018shish' },
    { t: 'Rasm',   act: 'img',    title: 'Rasm qo\u2018shish (URL)' },
    { t: 'Jadval', act: 'table',  title: 'Jadval qo\u2018shish' },
    { sep: 1 },
    { t: 'Tozalash', act: 'clean', title: 'Formatni tozalash', cls: 'warn' }
  ];

  // PMM maxsus bloklari
  var BLOCKS = [
    { t: 'Kirish matni',  act: 'lead',     title: 'Yashil fonli kirish matni' },
    { t: 'Yorliq',        act: 'kicker',   title: 'Oltin yorliq (Markaz haqida)' },
    { t: 'Vaqt lentasi',  act: 'timeline', title: 'Yillar bo\u2018yicha tarix' },
    { t: '+ Yil',         act: 'tlitem',   title: 'Lentaga yangi yil qo\u2018shish' },
    { t: 'Rekvizitlar',   act: 'facts',    title: 'Nom \u2014 qiymat jadvali' },
    { t: '+ Qator',       act: 'factrow',  title: 'Rekvizitga qator qo\u2018shish' },
    { t: 'Eslatma',       act: 'note',     title: 'Oltin ta\u2019kid bloki' },
    { t: 'Statistika',    act: 'stats',    title: 'Raqamli kataklar' },
    { t: '2 ustun',       act: 'cols',     title: 'Matn + yon panel' }
  ];

  function mkBtn(b, group) {
    if (b.sep) {
      var s = document.createElement('span');
      s.className = 'wys-sep';
      return s;
    }
    var el = document.createElement('button');
    el.type = 'button';
    el.textContent = b.t;
    el.title = b.title || b.t;
    if (b.css) el.setAttribute('style', b.css);
    if (b.cls) el.className = b.cls;
    if (group) el.className = (el.className ? el.className + ' ' : '') + 'blk';
    el.addEventListener('mousedown', function (e) { e.preventDefault(); });
    el.addEventListener('click', function () { run(b); });
    return el;
  }

  BTNS.forEach(function (b) { bar.appendChild(mkBtn(b)); });

  // Ikkinchi qator — PMM bloklari
  var bar2 = document.createElement('div');
  bar2.className = 'wys-bar wys-bar2';
  var lbl = document.createElement('span');
  lbl.className = 'wys-lbl';
  lbl.textContent = 'Bloklar:';
  bar2.appendChild(lbl);
  BLOCKS.forEach(function (b) { bar2.appendChild(mkBtn(b, true)); });

  // O'ng tomonda — HTML rejimi
  var right = document.createElement('span');
  right.className = 'wys-right';
  var srcBtn = document.createElement('button');
  srcBtn.type = 'button';
  srcBtn.className = 'src';
  srcBtn.textContent = 'HTML kodi';
  srcBtn.title = 'HTML kodini ko\u2018rish / tahrirlash';
  srcBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
  srcBtn.addEventListener('click', toggleSrc);
  right.appendChild(srcBtn);
  bar2.appendChild(right);

  wrap.insertBefore(bar2, area);

  // ---------- Amallar ----------
  function exec(c, v) { document.execCommand(c, false, v || null); area.focus(); }

  function run(b) {
    if (b.cmd)   { exec(b.cmd); return; }
    if (b.block) { exec('formatBlock', '<' + b.block + '>'); return; }

    switch (b.act) {
      case 'link':
        var u = prompt('Havola manzili (URL):', 'https://');
        if (u) exec('createLink', u);
        break;

      case 'img':
        var i = prompt('Rasm manzili (URL):', 'https://yasuna.uz/assets/uploads/');
        if (i) ins('<img src="' + esc(i) + '" alt="">');
        break;

      case 'table':
        var r = parseInt(prompt('Necha qator?', '3'), 10);
        var c = parseInt(prompt('Necha ustun?', '2'), 10);
        if (!r || !c || r < 1 || c < 1) break;
        var t = '<table><tr>';
        for (var x = 0; x < c; x++) t += '<th>Sarlavha</th>';
        t += '</tr>';
        for (var y = 0; y < r; y++) {
          t += '<tr>';
          for (var z = 0; z < c; z++) t += '<td>Matn</td>';
          t += '</tr>';
        }
        ins(t + '</table><p><br></p>');
        break;

      case 'clean':
        exec('removeFormat');
        break;

      case 'lead':
        ins('<p class="pmm-lead">Kirish matnini shu yerga yozing.</p>');
        break;

      case 'kicker':
        ins('<span class="pmm-kicker">Markaz haqida</span>');
        break;

      case 'timeline':
        ins('<div class="pmm-timeline">'
          + tl('1952', 'Shu yilda sodir bo\u2018lgan voqea matni.')
          + tl('2024', 'Keyingi bosqich matni.')
          + '</div><p><br></p>');
        break;

      case 'tlitem':
        var tline = closest(area, 'pmm-timeline');
        if (tline) {
          tline.insertAdjacentHTML('beforeend', tl('2026', 'Yangi bosqich matni.'));
          sync();
        } else {
          alert('Avval kursorni "Vaqt lentasi" ichiga qo\u2018ying.');
        }
        break;

      case 'facts':
        ins('<div class="pmm-facts">'
          + fr('To\u2018liq nomi', 'Qashqadaryo viloyati pedagogik mahorat markazi')
          + fr('Manzil', 'Qarshi shahri, Olimlar ko\u2018chasi, 2-uy')
          + fr('Telefon', '(+998 75) 221-15-13')
          + '</div><p><br></p>');
        break;

      case 'factrow':
        var fbox = closest(area, 'pmm-facts');
        if (fbox) {
          fbox.insertAdjacentHTML('beforeend', fr('Nomi', 'Qiymati'));
          sync();
        } else {
          alert('Avval kursorni "Rekvizitlar" bloki ichiga qo\u2018ying.');
        }
        break;

      case 'note':
        ins('<div class="pmm-note">Muhim eslatma matni shu yerda.</div><p><br></p>');
        break;

      case 'stats':
        ins('<div class="pmm-stats">'
          + '<div class="s"><div class="n">1952</div><div class="l">Tashkil etilgan</div></div>'
          + '<div class="s"><div class="n">70+</div><div class="l">Yillik tajriba</div></div>'
          + '<div class="s"><div class="n">5000+</div><div class="l">Tinglovchi</div></div>'
          + '</div><p><br></p>');
        break;

      case 'cols':
        ins('<div class="pmm-cols"><div class="pmm-main">'
          + '<p>Asosiy matn shu yerda.</p>'
          + '</div><div class="pmm-side">'
          + '<div class="pmm-card"><h4>Qisqacha</h4>'
          + '<div class="row"><b>Nomi:</b><span>Qiymati</span></div>'
          + '</div></div></div><p><br></p>');
        break;
    }
    sync();
  }

  function tl(y, txt) {
    return '<div class="tl-item"><div class="tl-year">' + y + '</div><p>' + txt + '</p></div>';
  }
  function fr(n, v) {
    return '<div class="f-row"><b>' + n + '</b><span>' + v + '</span></div>';
  }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  }

  // Kursor turgan joydan yuqoriga qarab klass izlash
  function closest(root, cls) {
    var sel = window.getSelection();
    if (!sel || !sel.rangeCount) return null;
    var n = sel.getRangeAt(0).startContainer;
    while (n && n !== root) {
      if (n.nodeType === 1 && n.classList && n.classList.contains(cls)) return n;
      n = n.parentNode;
    }
    return null;
  }

  function ins(html) {
    area.focus();
    var sel = window.getSelection();
    if (!sel || !sel.rangeCount) { area.insertAdjacentHTML('beforeend', html); return; }
    document.execCommand('insertHTML', false, html);
  }

  // ---------- HTML rejimi ----------
  var srcMode = false;
  function toggleSrc() {
    if (!srcMode) {
      src.value = pretty(area.innerHTML);
      area.style.display = 'none';
      src.style.display = 'block';
      srcBtn.classList.add('on');
      srcBtn.textContent = 'Vizual rejim';
      bar.style.opacity = '.35';
      bar.style.pointerEvents = 'none';
      bar2.querySelectorAll('.blk').forEach(function (b) {
        b.style.opacity = '.35'; b.style.pointerEvents = 'none';
      });
    } else {
      area.innerHTML = src.value;
      src.style.display = 'none';
      area.style.display = 'block';
      srcBtn.classList.remove('on');
      srcBtn.textContent = 'HTML kodi';
      bar.style.opacity = '';
      bar.style.pointerEvents = '';
      bar2.querySelectorAll('.blk').forEach(function (b) {
        b.style.opacity = ''; b.style.pointerEvents = '';
      });
    }
    srcMode = !srcMode;
    sync();
  }

  // HTML'ni o'qish uchun qulay qatorlarga bo'lish
  function pretty(h) {
    return h
      .replace(/></g, '>\n<')
      .replace(/\n{2,}/g, '\n')
      .trim();
  }

  // ---------- Word / sayt matnini tozalab qo'yish ----------
  area.addEventListener('paste', function (e) {
    e.preventDefault();
    var cb = e.clipboardData || window.clipboardData;
    var html = cb.getData('text/html');
    var text = cb.getData('text/plain');

    if (html) {
      document.execCommand('insertHTML', false, clean(html));
    } else if (text) {
      // Har bir qatorni alohida xatboshi qilamiz
      var p = text.split(/\n{2,}/).map(function (x) {
        return '<p>' + x.replace(/\n/g, '<br>').replace(/</g, '&lt;') + '</p>';
      }).join('');
      document.execCommand('insertHTML', false, p);
    }
    sync();
  });

  // Word'dan kelgan axlatni olib tashlash
  function clean(h) {
    var d = document.createElement('div');
    d.innerHTML = h;

    // keraksiz teglar
    d.querySelectorAll('script,style,meta,link,o\\:p,xml,font').forEach(function (n) {
      n.parentNode && n.parentNode.removeChild(n);
    });

    // barcha atributlarni tozalash (faqat kerakligini qoldiramiz)
    var keepCls = /^(pmm-|tl-|f-row|s$|row$|n$|l$)/;
    d.querySelectorAll('*').forEach(function (n) {
      var keep = {};
      if (n.tagName === 'A' && n.getAttribute('href')) keep.href = n.getAttribute('href');
      if (n.tagName === 'IMG' && n.getAttribute('src')) {
        keep.src = n.getAttribute('src');
        keep.alt = n.getAttribute('alt') || '';
      }
      var c = n.getAttribute('class');
      if (c && keepCls.test(c.trim().split(/\s+/)[0])) keep['class'] = c;

      while (n.attributes.length) n.removeAttribute(n.attributes[0].name);
      for (var k in keep) n.setAttribute(k, keep[k]);
    });

    // bo'sh teglarni olib tashlash
    d.querySelectorAll('span,div,b,i,u,em,strong').forEach(function (n) {
      if (!n.textContent.trim() && !n.querySelector('img')) {
        n.parentNode && n.parentNode.removeChild(n);
      }
    });

    return d.innerHTML.replace(/<!--[\s\S]*?-->/g, '');
  }

  // ---------- Klaviatura ----------
  area.addEventListener('keydown', function (e) {
    // Enter — yangi xatboshi (div emas)
    if (e.key === 'Enter' && !e.shiftKey) {
      var inList = closest(area, 'tl-item') || closest(area, 'f-row');
      if (!inList) {
        // brauzer o'zi <div> yasamasligi uchun
        setTimeout(function () {
          document.execCommand('formatBlock', false, '<p>');
        }, 0);
      }
    }
    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'b') { e.preventDefault(); exec('bold'); }
      if (e.key === 'i') { e.preventDefault(); exec('italic'); }
    }
  });

  // ---------- Sinxronlash ----------
  function sync() {
    TA.value = srcMode ? src.value : area.innerHTML;
  }
  area.addEventListener('input', sync);
  src.addEventListener('input', sync);
  area.addEventListener('blur', sync);

  // Forma yuborilishidan oldin — albatta sinxron
  var form = TA.closest('form');
  if (form) form.addEventListener('submit', function () {
    if (srcMode) TA.value = src.value;
    else TA.value = area.innerHTML;
  });

  sync();
})();

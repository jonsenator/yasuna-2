// ===== Admin panel — umumiy skriptlar =====
// Eslatma: matn muharriri endi alohida faylda — assets/js/editor.js
// (vizual WYSIWYG muharrir). Bu yerdagi eski oddiy panel olib tashlandi.

(function () {
  'use strict';

  // O'chirish formalariga qo'shimcha himoya:
  // tugma ikki marta bosilib, ikki marta so'rov ketmasligi uchun
  document.querySelectorAll('form[onsubmit]').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = f.querySelector('button[type=submit], button:not([type])');
      if (b) {
        setTimeout(function () {
          b.disabled = true;
          b.style.opacity = '.6';
        }, 10);
      }
    });
  });
})();

# yasuna.uz — Qashqadaryo viloyati pedagogik mahorat markazi

Professional CMS sayt (PHP + MySQL). Hammasi **admin paneldan** boshqariladi:
yangiliklar, kategoriyalar, sahifalar, **menyu**, bosh sahifa **slayderi**,
**aloqa xabarlari** va **sayt sozlamalari**.

## 📁 Tuzilish
```
yasuna-site/
├── config.php            # DB sozlamalari + BASE_URL avtomatik aniqlash
├── db.php                # PDO ulanish + sozlamalar
├── functions.php         # XSS, slug, CSRF, sana, fayl, va h.k.
├── database.sql          # Ma'lumotlar bazasi (import qiling)
├── index.php             # Bosh sahifa (slayder + yangiliklar)
├── category.php          # Bo'lim sahifasi
├── post.php              # Yangilik sahifasi
├── page.php              # Statik sahifa
├── contact.php           # Aloqa formasi
├── search.php            # Qidiruv
├── sitemap.php           # XML sitemap (SEO)
├── includes/             # header, footer, queries
├── admin/                # Admin panel
├── assets/
│   ├── css/              # style.css (sayt), admin.css
│   ├── js/               # main.js, admin.js
│   ├── uploads/          # yuklangan rasmlar
│   └── favicon.svg
```

## 🚀 O'rnatish (aaPanel / hosting)

1. **Fayllarni joylash** — butun `yasuna-site/` papkasi ichidagi fayllarni
   sayt ildiziga yuklang (masalan `/www/wwwroot/yasuna.uz/`).

2. **Ma'lumotlar bazasi yarating** — aaPanel → "Databases" bo'limida yangi DB
   yarating. Nomini yozib oling (masalan `yasuna_uz`).

3. **DB ma'lumotlarini kiriting** — `config.php` faylini ochib:
   ```php
   define('DB_HOST', '127.0.0.1');
   define('DB_NAME', 'yasuna_uz');      // sizning DB nomingiz
   define('DB_USER', 'yasuna_uz');      // sizning DB user
   define('DB_PASS', 'SIZNING_PAROL');  // sizning DB parol
   ```

4. **DB import qiling** — phpMyAdmin'da DB'ni tanlab `database.sql` faylini
   import qiling. (Yoki: `mysql -u root yasuna_uz < database.sql`)

5. **Ruxsatlar** — `assets/uploads/` papkasi yoziladigan bo'lsin:
   ```bash
   chmod -R 755 assets/uploads/
   ```

6. **Admin panel** — brauzerda `https://yasuna.uz/admin` sahifasini oching.
   - **Login:** `admin`
   - **Parol:** o'rnatish paytidagi boshlang'ich parol (database.sql ichidagi izohda)

   ⚠️ Kirgach, **Sozlamalar** bo'limidan darhol parolni o'zgartiring.

## 🔐 Xavfsizlik
- Parollar `password_hash()` bilan shifrlangan
- Barcha kirishlar **CSRF token** bilan himoyalangan
- Chiqishlar XSS'dan himoyalangan (`h()`, `safe_html()`)
- PDO `prepared statements` — SQL-injection'dan himoya
- Apache'da `.htaccess`, **Nginx'da `nginx-himoya.conf`** qoidalari orqali
  `database.sql`, `README.md` va boshqa xizmat fayllari yopiladi
- Login: 15 daqiqada 5 ta xato urinishdan keyin bloklanadi
- Aloqa formasi: CSRF + spam himoyasi (yashirin maydon, 60 soniya limiti)

## 🔄 Yangilash (mavjud bazaga)
Agar bazangizda `menus.clickable` ustuni bo'lmasa (menyu saqlashda xato chiqsa):
```sql
ALTER TABLE menus ADD COLUMN clickable TINYINT(1) NOT NULL DEFAULT 1 AFTER url;
```

## 🎨 Dizayn
- Klassik davlat uslubi — chuqur yashil + oltin urg'u
- To'liq mobil-moslashuvchan (responsive)
- Bosh sahifada hero-slider, statistika bloklari, yangiliklar to'ri
- Manrope + Public Sans shriftlari

## ⚙️ Admin panel imkoniyatlari
| Bo'lim | Vazifasi |
|--------|----------|
| Boshqaruv paneli | Umumiy statistika, so'nggi yangiliklar |
| Yangiliklar | Yangilik qo'shish/tahrirlash/o'chirish, rasm yuklash, matn muharriri |
| Kategoriyalar | Bo'limlarni boshqarish (ota/bola) |
| Menyu | Bosh menyuni boshqarish (kategoriya/sahifa/maxsus havola) |
| Sahifalar | Statik sahifalar |
| Slayder | Bosh sahifa slayderi |
| Xabarlar | Aloqa formasi orqali kelgan xabarlar |
| Sozlamalar | Sayt nomi, shior, aloqa, ijtimoiy tarmoqlar, banner, parol |

## ✅ Test qilingan
- PHP 8.4, MariaDB 11.8
- Frontend: bosh sahifa, bo'lim, yangilik, aloqa, qidiruv — 200 OK
- Admin: login, yangilik yaratish, barcha bo'limlar — ishlaydi
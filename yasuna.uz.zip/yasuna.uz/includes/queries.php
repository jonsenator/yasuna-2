<?php
/**
 * Ma'lumot olish funksiyalari (frontend + admin)
 */

// ================= MENYU =================
// Bosh menyu (menus jadvalidan, ierarxiya + havola yechimi)
function get_menu(): array {
    $rows = db()->query(
        "SELECT * FROM menus WHERE active=1 ORDER BY sort_order, id"
    )->fetchAll();

    $cats = null;
    $pages = null;

    $build = function ($m) use (&$cats, &$pages): array {
        $href = '#';
        if ($m['type'] === 'category') {
            $cats = $cats ?? db()->query('SELECT id, slug FROM categories')->fetchAll();
            foreach ($cats as $c) if ((int)$c['id'] === (int)$m['ref_id']) $href = '/category.php?slug=' . urlencode($c['slug']);
        } elseif ($m['type'] === 'page') {
            $pages = $pages ?? db()->query("SELECT id, slug FROM pages WHERE status='published'")->fetchAll();
            foreach ($pages as $p) if ((int)$p['id'] === (int)$m['ref_id']) $href = '/page.php?slug=' . urlencode($p['slug']);
        } else {
            $href = $m['url'] ?: '#';
        }
        if (strpos($href, 'http') !== 0 && strpos($href, '/') === 0) $href = BASE_URL . $href;
        $clickable = !isset($m['clickable']) || (int)$m['clickable'] === 1;
        return ['id'=>(int)$m['id'], 'title'=>$m['title'], 'href'=>$href, 'type'=>$m['type'],
                'clickable'=>$clickable, 'children'=>[]];
    };

    // Ko'p darajali daraxt qurish (2, 3 va undan chuqur menyular uchun)
    $items = [];
    foreach ($rows as $r) {
        $it = $build($r);
        $it['parent_id'] = $r['parent_id'] === null ? null : (int)$r['parent_id'];
        $items[$it['id']] = $it;
    }

    // Bolalarni otalariga biriktiramiz (havola orqali)
    $tree = [];
    foreach ($items as $id => $_) {
        $pid = $items[$id]['parent_id'];
        if ($pid !== null && isset($items[$pid])) {
            $items[$pid]['children'][] =& $items[$id];
        } else {
            $tree[] =& $items[$id];
        }
    }
    unset($it);

    return $tree;
}

// ================= SLIDER =================
function get_slider(): array {
    return db()->query("SELECT * FROM slider WHERE active=1 ORDER BY sort_order, id")->fetchAll();
}

// ================= YANGILIKLAR =================
function get_latest_posts(int $limit = 9, int $offset = 0): array {
    $st = db()->prepare(
        "SELECT p.*, c.name AS cat, c.slug AS cat_slug
         FROM posts p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.status='published'
         ORDER BY p.created_at DESC LIMIT ? OFFSET ?"
    );
    $st->bindValue(1, $limit, PDO::PARAM_INT);
    $st->bindValue(2, $offset, PDO::PARAM_INT);
    $st->execute();
    return $st->fetchAll();
}

function count_published_posts(): int {
    return (int)db()->query("SELECT COUNT(*) FROM posts WHERE status='published'")->fetchColumn();
}

function get_post_by_slug(string $slug): ?array {
    $st = db()->prepare(
        "SELECT p.*, c.name AS cat, c.slug AS cat_slug
         FROM posts p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.slug = ? AND p.status='published' LIMIT 1"
    );
    $st->execute([$slug]);
    return $st->fetch() ?: null;
}

function get_post_by_id(int $id): ?array {
    $st = db()->prepare("SELECT * FROM posts WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function increment_views(int $id): void {
    db()->prepare('UPDATE posts SET views = views + 1 WHERE id = ?')->execute([$id]);
}

function get_related_posts(int $category_id, int $exclude_id, int $limit = 3): array {
    $st = db()->prepare(
        "SELECT p.*, c.name AS cat, c.slug AS cat_slug
         FROM posts p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.status='published' AND p.category_id = ? AND p.id != ?
         ORDER BY p.created_at DESC LIMIT ?"
    );
    $st->bindValue(1, $category_id, PDO::PARAM_INT);
    $st->bindValue(2, $exclude_id, PDO::PARAM_INT);
    $st->bindValue(3, $limit, PDO::PARAM_INT);
    $st->execute();
    return $st->fetchAll();
}

// ================= KATEGORIYA =================
function get_category_by_slug(string $slug): ?array {
    $st = db()->prepare('SELECT * FROM categories WHERE slug = ? LIMIT 1');
    $st->execute([$slug]);
    return $st->fetch() ?: null;
}

function get_category_by_id(int $id): ?array {
    $st = db()->prepare('SELECT * FROM categories WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function get_posts_by_category(int $catId, int $limit = 12, int $offset = 0): array {
    $st = db()->prepare(
        "SELECT p.*, c.name AS cat, c.slug AS cat_slug
         FROM posts p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.status='published' AND (p.category_id = ? OR c.parent_id = ?)
         ORDER BY p.created_at DESC LIMIT ? OFFSET ?"
    );
    $st->bindValue(1, $catId, PDO::PARAM_INT);
    $st->bindValue(2, $catId, PDO::PARAM_INT);
    $st->bindValue(3, $limit, PDO::PARAM_INT);
    $st->bindValue(4, $offset, PDO::PARAM_INT);
    $st->execute();
    return $st->fetchAll();
}

function count_posts_by_category(int $catId): int {
    $st = db()->prepare(
        "SELECT COUNT(*) FROM posts p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.status='published' AND (p.category_id = ? OR c.parent_id = ?)"
    );
    $st->bindValue(1, $catId, PDO::PARAM_INT);
    $st->bindValue(2, $catId, PDO::PARAM_INT);
    $st->execute();
    return (int)$st->fetchColumn();
}

function get_all_categories_tree(): array {
    $rows = db()->query('SELECT * FROM categories ORDER BY sort_order, name')->fetchAll();
    $parents = []; $children = [];
    foreach ($rows as $r) {
        if ($r['parent_id'] === null) $parents[$r['id']] = $r + ['children'=>[]];
        else $children[] = $r;
    }
    foreach ($children as $c) if (isset($parents[$c['parent_id']])) $parents[$c['parent_id']]['children'][] = $c;
    return array_values($parents);
}

// ================= SAHIFA =================
function get_page_by_slug(string $slug): ?array {
    $st = db()->prepare("SELECT * FROM pages WHERE slug = ? AND status='published' LIMIT 1");
    $st->execute([$slug]);
    return $st->fetch() ?: null;
}
function get_page_by_id(int $id): ?array {
    $st = db()->prepare("SELECT * FROM pages WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// ================= QIDIRUV =================
function search_posts(string $q, int $limit = 12, int $offset = 0): array {
    $like = '%' . $q . '%';
    $st = db()->prepare(
        "SELECT p.*, c.name AS cat, c.slug AS cat_slug
         FROM posts p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.status='published' AND (p.title LIKE ? OR p.excerpt LIKE ? OR p.content LIKE ?)
         ORDER BY p.created_at DESC LIMIT ? OFFSET ?"
    );
    $st->bindValue(1, $like); $st->bindValue(2, $like); $st->bindValue(3, $like);
    $st->bindValue(4, $limit, PDO::PARAM_INT);
    $st->bindValue(5, $offset, PDO::PARAM_INT);
    $st->execute();
    return $st->fetchAll();
}
function count_search_posts(string $q): int {
    $like = '%' . $q . '%';
    $st = db()->prepare(
        "SELECT COUNT(*) FROM posts p
         WHERE p.status='published' AND (p.title LIKE ? OR p.excerpt LIKE ? OR p.content LIKE ?)"
    );
    $st->bindValue(1, $like); $st->bindValue(2, $like); $st->bindValue(3, $like);
    $st->execute();
    return (int)$st->fetchColumn();
}

// ================= URL / RASM =================
function post_url(array $p): string     { return BASE_URL . '/post.php?slug=' . urlencode($p['slug']); }
function category_url(array $c): string { return BASE_URL . '/category.php?slug=' . urlencode($c['slug']); }
function page_url(array $p): string     { return BASE_URL . '/page.php?slug=' . urlencode($p['slug']); }

function post_image_url(?string $name): ?string {
    return $name ? UPLOAD_URL . rawurlencode($name) : null;
}
function slider_image_url(?string $name): ?string {
    return $name ? UPLOAD_URL . rawurlencode($name) : null;
}

function get_message(int $id): ?array {
    $st = db()->prepare('SELECT * FROM messages WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// Matndan qisqa parcha
function make_excerpt(array $p, int $len = 160): string {
    $t = trim($p['excerpt'] ?? '');
    if ($t === '') $t = trim(strip_tags(safe_html($p['content'] ?? '')));
    if (mb_strlen($t, 'UTF-8') > $len) $t = mb_substr($t, 0, $len, 'UTF-8') . '…';
    return $t;
}
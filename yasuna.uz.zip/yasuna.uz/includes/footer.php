<?php
$SITE   = setting('site_name', 'Qashqadaryo PMM');
$SLOGAN = setting('site_slogan', '');
$FOOTER = setting('footer_text', $SITE);
$COPY   = setting('copyright', 'Barcha huquqlar himoyalangan.');
$MENU   = $MENU ?? get_menu();
$ADDR   = setting('address');
$PHONE  = setting('phone');
$EMAIL  = setting('email');
$WH     = setting('working_hours');
?>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="footer-about">
      <div class="fbrand">
        <?php $LOGO = $LOGO ?? site_logo_url(); ?>
        <div class="seal seal-sm<?= $LOGO ? ' has-logo' : '' ?>">
          <?php if ($LOGO): ?><img src="<?= h($LOGO) ?>" alt="" width="52" height="52">
          <?php else: ?><svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><path d="M12 2 4 5v6c0 5 3.4 8.5 8 11 4.6-2.5 8-6 8-11V5l-8-3Z"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg><?php endif; ?>
        </div>
        <strong><?= h($SITE) ?></strong>
      </div>
      <?php if ($SLOGAN): ?><p class="fslogan"><?= h($SLOGAN) ?></p><?php endif; ?>
      <div class="social">
        <?php foreach (['telegram'=>'Telegram','facebook'=>'Facebook','instagram'=>'Instagram','youtube'=>'YouTube'] as $k=>$label):
          if (setting($k)): ?>
          <a href="<?= h(setting($k)) ?>" target="_blank" rel="noopener" aria-label="<?= $label ?>"><?= $label ?></a>
        <?php endif; endforeach; ?>
      </div>
    </div>

    <div class="footer-col">
      <h4>Bo'limlar</h4>
      <ul>
        <li><a href="<?= BASE_URL ?>/">Bosh sahifa</a></li>
        <?php foreach ($MENU as $m):
          if (rtrim($m['href'], '/') === rtrim(BASE_URL, '/') || !$m['clickable'] || $m['href'] === '#') continue; ?>
          <li><a href="<?= h($m['href']) ?>"><?= h($m['title']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Bog'lanish</h4>
      <div class="frow">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0Z"/><circle cx="12" cy="10" r="3"/></svg>
        <span><?= h($ADDR) ?></span>
      </div>
      <div class="frow">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/></svg>
        <a href="tel:<?= h(preg_replace('/\s+/','',$PHONE)) ?>"><?= h($PHONE) ?></a>
      </div>
      <div class="frow">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>
        <a href="mailto:<?= h($EMAIL) ?>"><?= h($EMAIL) ?></a>
      </div>
      <?php if ($WH): ?>
      <div class="frow">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
        <span><?= h($WH) ?></span>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="wrap">
      <span>&copy; <?= date('Y') ?> <?= h($FOOTER) ?>. <?= h($COPY) ?></span>
      <span class="pmm-badge">Qashqadaryo PMM</span>
    </div>
  </div>
</footer>

<!-- STOP KORRUPSIYA -->
<?php $AK = setting('anticorruption_url'); ?>
<a class="stop-korr" href="<?= h($AK ?: BASE_URL . '/contact.php') ?>"<?= $AK ? ' target="_blank" rel="noopener"' : '' ?> title="STOP KORRUPSIYA">
  <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 2 4 5v6c0 5 3.4 8.5 8 11 4.6-2.5 8-6 8-11V5l-8-3Z"/><path d="M9 12h6"/></svg>
  <span>STOP KORRUPSIYA</span>
</a>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
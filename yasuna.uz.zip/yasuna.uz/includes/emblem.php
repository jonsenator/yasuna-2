<?php
/**
 * GERB BANNERI — kartali (tuzilma) sahifalar tepasida chiqadigan tantanali sarlavha.
 * Gerb rasmi: admin → Sozlamalar → «Gerb» (setting: gerb_image).
 */

/** Bayroqdagi yarim oy va 12 yulduz — rangli SVG (naqsh uchun) */
function flag_motif_svg(string $color = '#fff'): string {
    $stars = '';
    foreach ([[3, 0], [4, 1], [5, 2]] as [$n, $row]) {
        for ($i = 0; $i < $n; $i++) {
            $x = 78 + (5 - $n) * 9 + $i * 18;
            $y = 18 + $row * 18;
            $stars .= '<path d="M' . $x . ' ' . ($y - 5) . 'l1.5 3.4 3.6.3-2.8 2.4.9 3.6L' . $x . ' ' . ($y + 3)
                    . 'l-3.2 1.9.9-3.6-2.8-2.4 3.6-.3z"/>';
        }
    }
    $id = 'fm' . substr(md5($color), 0, 6);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 80" fill="' . $color . '" aria-hidden="true">'
         . '<defs><mask id="' . $id . '"><rect width="170" height="80" fill="#fff"/><circle cx="46" cy="40" r="23" fill="#000"/></mask></defs>'
         . '<circle cx="36" cy="40" r="26" mask="url(#' . $id . ')"/>' . $stars . '</svg>';
}

function gerb_image_url(): ?string {
    $g = trim((string)setting('gerb_image'));
    if ($g === '') return null;
    if (preg_match('~^https?://~i', $g)) return $g;
    return is_file(UPLOAD_DIR . basename($g)) ? UPLOAD_URL . rawurlencode(basename($g)) : null; // fayl o'chgan bo'lsa — naqsh chiqadi
}

/** Sahifa matnida kartalar (pmm-staff) bo'lsa — banner qo'shiladi */
function page_wants_emblem(string $content): bool {
    return stripos($content, 'pmm-staff') !== false;
}

/** Banner HTML. $lead — sahifadagi kirish matni (pmm-lead) bo'lsa ostida chiqadi */
function render_emblem_banner(string $title, string $lead = ''): string {
    $gerb   = gerb_image_url();
    $kicker = 'O‘zbekiston Respublikasi Maktabgacha va maktab ta’limi vazirligi';
    $site   = setting('site_name', 'Qashqadaryo viloyati pedagogik mahorat markazi');
    ob_start(); ?>
    <?php if ($gerb): ?>
    <style>.static-body.has-emb{--gerb-img:url('<?= str_replace(["'", '(', ')', ' ', '\\', '<', '>', '"'], ['%27', '%28', '%29', '%20', '%5C', '%3C', '%3E', '%22'], $gerb) ?>');--gerb-size:90%}</style>
    <?php endif; ?>
    <?= cards_bg_style() ?>
    <div class="emb-hero">
      <div class="emb-gerb<?= $gerb ? ' has-img' : '' ?>">
        <?php if ($gerb): ?><img src="<?= h($gerb) ?>" alt="O‘zbekiston Respublikasi Davlat gerbi">
        <?php else: ?><?= flag_motif_svg('#0a5c36') ?><?php endif; ?>
      </div>
      <div class="emb-text">
        <small><?= h($kicker) ?></small>
        <b><?= h($site) ?></b>
        <span class="emb-title"><?= h($title) ?></span>
        <?php if ($lead !== ''): ?><p><?= h($lead) ?></p><?php endif; ?>
      </div>
      <div class="emb-motif"><?= flag_motif_svg('#fff') ?></div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Sahifa matniga banner qo'shadi: eski yorliq (pmm-kicker) va kirish matni (pmm-lead)
 * banner ichiga ko'chadi, shuning uchun takrorlanmaydi.
 */
function apply_emblem_banner(string $html, string $title): string {
    $lead = '';
    if (preg_match('~<(div|p|span|section)[^>]*class=["\'][^"\']*\bpmm-lead\b[^"\']*["\'][^>]*>(.*?)</\1>~is', $html, $m)) {
        $lead = trim(html_entity_decode(strip_tags($m[2]), ENT_QUOTES, 'UTF-8'));
        $html = str_replace($m[0], '', $html);
    }
    $html = preg_replace('~<(span|div|p)[^>]*class=["\'][^"\']*\bpmm-kicker\b[^"\']*["\'][^>]*>.*?</\1>~is', '', $html, 1);
    return render_emblem_banner($title, $lead) . $html;
}

/** Kartalardagi doiralar uchun CSS o'zgaruvchisi (gerb qo'yilgan bo'lsa) */
function gerb_style_attr(): string {
    $u = gerb_image_url();
    if (!$u) return '';
    return ' style="--gerb-img:url(\'' . h(str_replace(["'", '(', ')', ' '], ['%27', '%28', '%29', '%20'], $u)) . '\')"';
}

/** Kartalar foni (Sozlamalar): bayroq | tekis | rasm */
function cards_bg_image_url(): ?string {
    $v = trim((string)setting('cards_bg_image'));
    if ($v === '') return null;
    if (preg_match('~^https?://~i', $v)) return $v;
    return is_file(UPLOAD_DIR . basename($v)) ? UPLOAD_URL . rawurlencode(basename($v)) : null;
}

/** Sahifaga qo'shiladigan <style> (fon turi bo'yicha) */
function cards_bg_style(): string {
    $type = setting('cards_bg_type', 'flag');
    if ($type === 'flag' || $type === '') return '';      // standart (style.css dagi bayroq)

    if ($type === 'plain') {
        return '<style>.static-body{--card-bg:#fff;--card-bg-hover:#f7fbf8}</style>';
    }
    if ($type === 'image') {
        $u = cards_bg_image_url();
        if (!$u) return '';
        $u = str_replace(["'", '(', ')', ' ', '\\', '<', '>', '"'], ['%27', '%28', '%29', '%20', '%5C', '%3C', '%3E', '%22'], $u);
        $op = (int)setting('cards_bg_opacity', '85');      // oq pardaning qalinligi, %
        $op = max(30, min(98, $op)) / 100;
        $oh = max(0.20, $op - 0.10);
        $img = "url('" . $u . "') center/cover no-repeat";
        return '<style>.static-body{'
             . '--card-bg:linear-gradient(rgba(255,255,255,' . $op . '),rgba(255,255,255,' . $op . ')),' . $img . ';'
             . '--card-bg-hover:linear-gradient(rgba(255,255,255,' . $oh . '),rgba(255,255,255,' . $oh . ')),' . $img . ';'
             . '}</style>';
    }
    return '';
}
<?php
/**
 * KARTALAR MUHARRIRI — sahifa matnidagi .pmm-staff guruhlarini o'qish va qayta yozish.
 * Sahifaning boshqa qismlariga (banner, mudir kartochkasi, matnlar) tegilmaydi.
 */

function cards_dom(string $html): array {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8"?><div id="__cards_root">' . $html . '</div>');
    libxml_clear_errors();
    $xp = new DOMXPath($dom);
    return [$dom, $xp, $dom->getElementById('__cards_root')];
}

function cards_has(string $c): string {
    return "contains(concat(' ', normalize-space(@class), ' '), ' $c ')";
}

/** Guruh oldidagi sarlavha (h2/h3/h4) — oraliqdagi bo'sh matnlarni o'tkazib yuboradi */
function cards_heading_of(DOMNode $grid): ?DOMElement {
    for ($n = $grid->previousSibling; $n; $n = $n->previousSibling) {
        if ($n instanceof DOMText && trim($n->textContent) === '') continue;
        if ($n instanceof DOMElement && preg_match('~^h[2-4]$~i', $n->nodeName)) return $n;
        return null;
    }
    return null;
}

/** Sahifadagi guruhlar: [['title'=>..., 'cards'=>[['nm','pos','phone','email','extra'], ...]], ...] */
function cards_read(string $html): array {
    [$dom, $xp, $root] = cards_dom($html);
    $groups = [];
    foreach ($xp->query('.//*[' . cards_has('pmm-staff') . ']', $root) as $grid) {
        $h = cards_heading_of($grid);
        $g = ['title' => $h ? trim($h->textContent) : '', 'cards' => []];
        foreach ($xp->query('./*[' . cards_has('st') . ']', $grid) as $st) {
            $get = function (string $cls) use ($xp, $st) {
                $n = $xp->query('.//*[' . cards_has($cls) . ']', $st)->item(0);
                return $n ? trim(preg_replace('~\s+~u', ' ', $n->textContent)) : '';
            };
            $phone = $email = '';
            $extra = '';
            $c = $xp->query('.//*[' . cards_has('c') . ']', $st)->item(0);
            if ($c) {
                foreach ($xp->query('.//a', $c) as $a) {
                    $href = $a->getAttribute('href');
                    if (stripos($href, 'tel:') === 0 && $phone === '')        $phone = trim($a->textContent);
                    elseif (stripos($href, 'mailto:') === 0 && $email === '') $email = trim($a->textContent);
                }
                // Qolgan matn (telefon/email dan tashqari)
                $txt = trim(preg_replace('~\s+~u', ' ', $c->textContent));
                foreach ([$phone, $email] as $rm) if ($rm !== '') $txt = str_replace($rm, '', $txt);
                $txt = trim(preg_replace('~^[^\p{L}\p{N}]+$~u', '', preg_replace('~[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{2709}\x{260E}\x{FE0F}]~u', '', $txt)));
                $extra = trim($txt, " \t|,;·-");
            }
            $photo = '';
            $im = $xp->query('.//img[' . cards_has('cph') . ']', $st)->item(0);
            if ($im) {
                $src = $im->getAttribute('src');
                $photo = preg_match('~/assets/uploads/([^/?#]+)$~', $src, $mm) ? rawurldecode($mm[1]) : $src;
            }
            $about = '';
            $ab = $xp->query('.//*[' . cards_has('ab') . ']', $st)->item(0);
            if ($ab) {
                $html2 = '';
                foreach ($ab->childNodes as $n) $html2 .= $ab->ownerDocument->saveHTML($n);
                $about = trim(html_entity_decode(strip_tags(preg_replace('~<br\s*/?>~i', "\n", $html2)), ENT_QUOTES, 'UTF-8'));
            }
            $g['cards'][] = ['nm' => $get('nm'), 'pos' => $get('pos'), 'phone' => $phone, 'email' => $email,
                             'extra' => $extra, 'about' => $about, 'photo' => $photo];
        }
        $groups[] = $g;
    }
    return $groups;
}

/** Bitta guruh uchun .pmm-staff HTML */
function cards_build_grid(array $cards): string {
    $withPhoto = false;
    foreach ($cards as $c) if (trim((string)($c['photo'] ?? '')) !== '' && trim($c['nm'] ?? '') !== '') $withPhoto = true;
    $out = '<div class="pmm-staff' . ($withPhoto ? ' has-photos' : '') . '">';
    foreach ($cards as $c) {
        $nm = trim($c['nm'] ?? '');
        if ($nm === '') continue;
        $out .= '<div class="st">';
        $ph = trim((string)($c['photo'] ?? ''));
        if ($ph !== '') {
            $url = preg_match('~^(https?:)?//~i', $ph) || strpos($ph, '/') === 0 ? $ph : UPLOAD_URL . rawurlencode($ph);
            $out .= '<img class="cph" src="' . h($url) . '" alt="' . h($nm) . '" loading="lazy">';
        }
        $out .= '<div class="nm">' . h($nm) . '</div>';
        if (trim($c['pos'] ?? '') !== '') $out .= '<div class="pos">' . h(trim($c['pos'])) . '</div>';
        $lines = [];
        $ph = trim($c['phone'] ?? '');
        $em = trim($c['email'] ?? '');
        $ex = trim($c['extra'] ?? '');
        if ($ph !== '') $lines[] = '📞 <a href="tel:' . h(preg_replace('~[^\d+]~', '', $ph)) . '">' . h($ph) . '</a>';
        if ($em !== '') $lines[] = '✉ <a href="mailto:' . h($em) . '">' . h($em) . '</a>';
        if ($ex !== '') $lines[] = h($ex);
        if ($lines) $out .= '<div class="c">' . implode('<br>', $lines) . '</div>';
        $ab = trim((string)($c['about'] ?? ''));
        if ($ab !== '') $out .= '<div class="ab">' . nl2br(h($ab), false) . '</div>';
        $out .= '</div>';
    }
    return $out . '</div>';
}

/** Guruhlarni sahifa matniga yozadi (mavjudlarini o'rnida almashtiradi, ortiqchasini o'chiradi, yangisini oxiriga qo'shadi) */
function cards_write(string $html, array $groups): string {
    [$dom, $xp, $root] = cards_dom($html);
    $grids = iterator_to_array($xp->query('.//*[' . cards_has('pmm-staff') . ']', $root));

    // Bo'sh guruhlarni tashlab yuboramiz
    $groups = array_values(array_filter($groups, function ($g) {
        foreach ($g['cards'] ?? [] as $c) if (trim($c['nm'] ?? '') !== '') return true;
        return false;
    }));

    $frag = function (string $markup) use ($dom): DOMNode {
        $tmp = new DOMDocument();
        libxml_use_internal_errors(true);
        $tmp->loadHTML('<?xml encoding="utf-8"?><div id="x">' . $markup . '</div>');
        libxml_clear_errors();
        $f = $dom->createDocumentFragment();
        foreach (iterator_to_array($tmp->getElementById('x')->childNodes) as $n) $f->appendChild($dom->importNode($n, true));
        return $f;
    };

    $last = null;
    foreach ($groups as $i => $g) {
        $title = trim($g['title'] ?? '');
        if (isset($grids[$i])) {
            $old = $grids[$i];
            $h = cards_heading_of($old);
            if ($h) {
                if ($title === '') $h->parentNode->removeChild($h);
                else { while ($h->firstChild) $h->removeChild($h->firstChild); $h->appendChild($dom->createTextNode($title)); }
            } elseif ($title !== '') {
                $old->parentNode->insertBefore($frag('<h2>' . h($title) . '</h2>'), $old);
            }
            $new = $frag(cards_build_grid($g['cards']));
            $newEl = $new->firstChild;
            $old->parentNode->replaceChild($new, $old);
            $last = $newEl;
        } else {
            $markup = ($title !== '' ? '<h2>' . h($title) . '</h2>' : '') . cards_build_grid($g['cards']);
            $f = $frag($markup);
            $tail = $f->lastChild;
            if ($last && $last->parentNode) {
                $last->parentNode->insertBefore($f, $last->nextSibling);
            } else {
                $root->appendChild($f);
            }
            $last = $tail;
        }
    }
    // Ortiqcha (o'chirilgan) guruhlar
    for ($i = count($groups); $i < count($grids); $i++) {
        $old = $grids[$i];
        if (!$old->parentNode) continue;
        if ($h = cards_heading_of($old)) $h->parentNode->removeChild($h);
        $old->parentNode->removeChild($old);
    }

    $out = '';
    foreach ($root->childNodes as $ch) $out .= $dom->saveHTML($ch);
    return $out;
}

/* ============================================================
   MUDIR / RAHBAR KARTOCHKASI (.pmm-person) — o'qish va yozish
   ============================================================ */

/** Sahifadagi birinchi .pmm-person kartochkasi ma'lumotlari (yo'q bo'lsa — bo'sh massiv) */
function person_read(string $html): array {
    $empty = ['photo' => '', 'nm' => '', 'pos' => '', 'phone' => '', 'email' => '', 'time' => '', 'bio' => '', 'exists' => false];
    if (stripos($html, 'pmm-person') === false) return $empty;
    [$dom, $xp, $root] = cards_dom($html);
    $p = $xp->query('.//*[' . cards_has('pmm-person') . ']', $root)->item(0);
    if (!$p) return $empty;

    $txt = function (?DOMNode $n): string {
        return $n ? trim(preg_replace('~\s+~u', ' ', $n->textContent)) : '';
    };
    $one = fn(string $cls) => $xp->query('.//*[' . cards_has($cls) . ']', $p)->item(0);

    $photo = '';
    if (($im = $xp->query('.//*[' . cards_has('ph') . ']//img', $p)->item(0))) {
        $src = $im->getAttribute('src');
        $photo = preg_match('~/assets/uploads/([^/?#]+)$~', $src, $m) ? rawurldecode($m[1]) : $src;
    }

    $phone = $email = $time = '';
    foreach ($xp->query('.//*[' . cards_has('meta') . ']/*', $p) as $chip) {
        $t = trim(preg_replace('~^[^\p{L}\p{N}+]+~u', '', $txt($chip)));
        $href = $chip instanceof DOMElement ? $chip->getAttribute('href') : '';
        if (stripos($href, 'tel:') === 0)             $phone = $t;
        elseif (stripos($href, 'mailto:') === 0)      $email = $t;
        elseif (preg_match('~\d{1,2}[:.]\d{2}~', $t)) $time  = $t;
    }

    $bio = '';
    if (($b = $one('bio'))) {
        $parts = [];
        foreach ($b->childNodes as $n) {
            if ($n instanceof DOMElement && in_array(strtolower($n->nodeName), ['ul','ol'], true)) {
                foreach ($xp->query('./li', $n) as $li) $parts[] = $txt($li);
            } else {
                $t = $txt($n);
                if ($t !== '') $parts[] = $t;
            }
        }
        $bio = implode("\n", $parts);
    }

    return ['photo' => $photo, 'nm' => $txt($one('nm')), 'pos' => $txt($one('pos')),
            'phone' => $phone, 'email' => $email, 'time' => $time, 'bio' => $bio, 'exists' => true];
}

/** Mudir kartochkasi HTML */
function person_build(array $d): string {
    $nm = trim($d['nm'] ?? '');
    if ($nm === '') return '';
    $ph = trim((string)($d['photo'] ?? ''));
    $out = '<div class="pmm-person head"><div class="ph">';
    if ($ph !== '') {
        $url = preg_match('~^(https?:)?//~i', $ph) || strpos($ph, '/') === 0 ? $ph : UPLOAD_URL . rawurlencode($ph);
        $out .= '<img src="' . h($url) . '" alt="' . h($nm) . '" loading="lazy">';
    } else {
        $out .= '<div class="noimg">PMM</div>';
    }
    $out .= '</div><div class="info"><div class="nm">' . h($nm) . '</div>';
    if (trim($d['pos'] ?? '') !== '') $out .= '<div class="pos">' . h(trim($d['pos'])) . '</div>';

    $chips = [];
    if (trim($d['phone'] ?? '') !== '') $chips[] = '<a href="tel:' . h(preg_replace('~[^\d+]~', '', $d['phone'])) . '">📞 ' . h(trim($d['phone'])) . '</a>';
    if (trim($d['email'] ?? '') !== '') $chips[] = '<a href="mailto:' . h(trim($d['email'])) . '">✉ ' . h(trim($d['email'])) . '</a>';
    if (trim($d['time'] ?? '')  !== '') $chips[] = '<span>🕐 ' . h(trim($d['time'])) . '</span>';
    if ($chips) $out .= '<div class="meta">' . implode('', $chips) . '</div>';

    $bio = trim((string)($d['bio'] ?? ''));
    if ($bio !== '') {
        $out .= '<div class="bio">';
        foreach (preg_split('~\R+~u', $bio) as $line) {
            $line = trim($line);
            if ($line !== '') $out .= '<p>' . h($line) . '</p>';
        }
        $out .= '</div>';
    }
    return $out . '</div></div>';
}

/** Mudir kartochkasini sahifaga yozadi (mavjudini almashtiradi, yo'qni qo'shadi, bo'sh bo'lsa o'chiradi) */
function person_write(string $html, array $d): string {
    [$dom, $xp, $root] = cards_dom($html);
    $old = $xp->query('.//*[' . cards_has('pmm-person') . ']', $root)->item(0);
    $markup = person_build($d);

    if ($markup === '') {                      // bo'sh — kartochka o'chiriladi
        if ($old) $old->parentNode->removeChild($old);
    } else {
        $tmp = new DOMDocument();
        libxml_use_internal_errors(true);
        $tmp->loadHTML('<?xml encoding="utf-8"?><div id="x">' . $markup . '</div>');
        libxml_clear_errors();
        $new = $dom->importNode($tmp->getElementById('x')->firstChild, true);
        if ($old) {
            $old->parentNode->replaceChild($new, $old);
        } else {
            // birinchi guruh (yoki uning sarlavhasi) oldiga qo'yamiz
            $grid = $xp->query('.//*[' . cards_has('pmm-staff') . ']', $root)->item(0);
            $ref  = $grid ? (cards_heading_of($grid) ?: $grid) : null;
            if ($ref) $ref->parentNode->insertBefore($new, $ref);
            else      $root->appendChild($new);
        }
    }
    $out = '';
    foreach ($root->childNodes as $ch) $out .= $dom->saveHTML($ch);
    return $out;
}
<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/queries.php';

$SITE   = setting('site_name', 'Qashqadaryo PMM');
$SLOGAN = setting('site_slogan', '');
$MENU   = get_menu();
$active_slug = $active_slug ?? '';
$meta_title  = $meta_title ?? $SITE;
$meta_desc   = $meta_desc ?? setting('meta_description', $SITE);
$today_uz    = uzdate(date('Y-m-d'));
$PHONE = setting('phone');
$EMAIL = setting('email');
$ADDR  = setting('address');

// Joriy sahifa manzili — menyuda faol bandni belgilash uchun
$active_url = $active_url ?? (BASE_URL . ($_SERVER['REQUEST_URI'] ?? '/'));
$norm_url = function (string $u): string {
    $u = preg_replace('~[?&]page=\d+~', '', $u);
    $u = preg_replace('~/index\.php$~', '/', $u);
    return rtrim($u, '/?&');
};
?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($meta_title) ?></title>
<meta name="description" content="<?= h($meta_desc) ?>">
<meta name="keywords" content="<?= h(setting('meta_keywords')) ?>">
<meta property="og:title" content="<?= h($meta_title) ?>">
<meta property="og:description" content="<?= h($meta_desc) ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="<?= h(BASE_URL . ($_SERVER['REQUEST_URI'] ?? '/')) ?>">
<meta name="theme-color" content="#0a5c36">
<link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>/assets/favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;600;700;800&family=Public+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<!-- Yuqori banner (mustaqillik / maxsus xabar) -->
<?php if (setting('banner_enabled') === '1' && setting('banner_text') !== ''): ?>
<div class="top-banner">
  <span class="banner-text"><?= h(setting('banner_text')) ?></span>
</div>
<?php endif; ?>

<!-- Yuqori ma'lumot paneli -->
<div class="topbar">
  <div class="wrap">
    <div class="tb-left">
      <?php if ($ADDR): ?><span class="tb-item">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0Z"/><circle cx="12" cy="10" r="3"/></svg>
        <?= h($ADDR) ?></span><?php endif; ?>
      <span class="tb-item hide-sm"><?= h($today_uz) ?></span>
    </div>
    <div class="tb-right">
      <?php if ($PHONE): ?><a class="tb-item" href="tel:<?= h(preg_replace('/\s+/','',$PHONE)) ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/></svg>
        <?= h($PHONE) ?></a><?php endif; ?>
      <?php if (setting('telegram')): ?><a class="tb-item" href="<?= h(setting('telegram')) ?>" target="_blank" rel="noopener">Telegram</a><?php endif; ?>
      <?php if ($EMAIL): ?><a class="tb-item hide-sm" href="mailto:<?= h($EMAIL) ?>"><?= h($EMAIL) ?></a><?php endif; ?>
    </div>
  </div>
</div>

<!-- Sarlavha / logo -->
<header class="site-header">
  <div class="wrap">
    <a class="brand" href="<?= BASE_URL ?>/">
      <?php $LOGO = site_logo_url(); ?>
      <div class="seal<?= $LOGO ? ' has-logo' : '' ?>">
        <?php if ($LOGO): ?><img src="<?= h($LOGO) ?>" alt="<?= h($SITE) ?> logotipi" width="88" height="88">
        <?php else: ?><svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><path d="M12 2 4 5v6c0 5 3.4 8.5 8 11 4.6-2.5 8-6 8-11V5l-8-3Z"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg><?php endif; ?>
      </div>
      <div class="brand-text">
        <span class="brand-kicker">O'zbekiston Respublikasi Maktabgacha va maktab ta'limi vazirligi</span>
        <h1><?= h($SITE) ?></h1>
        <?php if ($SLOGAN): ?><p><?= h($SLOGAN) ?></p><?php endif; ?>
      </div>
    </a>
    <div class="header-actions">
      <button class="search-toggle" aria-label="Qidiruv">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
      </button>
      <button class="burger" aria-label="Menyu"><span></span><span></span><span></span></button>
    </div>
  </div>
</header>

<!-- Qidiruv paneli -->
<div class="search-panel" id="searchPanel">
  <div class="wrap">
    <form action="<?= BASE_URL ?>/search.php" method="get" class="search-form">
      <input type="search" name="q" placeholder="Yangiliklar bo'yicha qidirish…" value="<?= h($_GET['q'] ?? '') ?>">
      <button type="submit">Qidirish</button>
    </form>
  </div>
</div>

<!-- Navigatsiya -->
<nav class="mainnav">
  <div class="wrap">
    <ul class="nav-list">
      <?php
      /**
       * Menyuni istalgan chuqurlikda chizadi (2, 3 va undan ko'p daraja).
       * $level: 0 = asosiy qator, 1 = ochiluvchi, 2+ = ichma-ich ochiluvchi
       */
      // Band yoki uning ichki bandlaridan biri joriy sahifami?
      function menu_is_active(array $m, string $cur, callable $norm): bool {
          if ($m['href'] !== '#' && $norm($m['href']) === $cur) return true;
          foreach ($m['children'] as $c) if (menu_is_active($c, $cur, $norm)) return true;
          return false;
      }
      function render_menu(array $items, string $cur, callable $norm, int $level = 0): void {
          foreach ($items as $m) {
              $has = !empty($m['children']);
              $isActive = menu_is_active($m, $cur, $norm);
              $link = $m['clickable'] || !$has;
              $cls = [];
              if ($has) $cls[] = $level === 0 ? 'has-sub' : 'has-sub deep';
              if ($isActive) $cls[] = 'is-active';
              $aCls = [];
              if ($isActive) $aCls[] = 'active';
              if (!$link) $aCls[] = 'no-link';
              ?>
              <li class="<?= implode(' ', $cls) ?>">
                <a href="<?= $link ? h($m['href']) : '#' ?>" class="<?= implode(' ', $aCls) ?>"<?= $link ? '' : ' role="button"' ?>>
                  <?= h($m['title']) ?><?php if ($has): ?><i class="caret"></i><?php endif; ?>
                </a>
                <?php if ($has): ?>
                  <ul class="submenu<?= $level > 0 ? ' sub-deep' : '' ?>">
                    <?php render_menu($m['children'], $cur, $norm, $level + 1); ?>
                  </ul>
                <?php endif; ?>
              </li>
              <?php
          }
      }
      render_menu($MENU, $norm_url($active_url), $norm_url, 0);
      ?>
    </ul>
  </div>
</nav>
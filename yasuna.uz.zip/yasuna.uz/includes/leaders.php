<?php
/**
 * RAHBARIYAT moduli
 * - leaders jadvali (birinchi murojaatda avtomatik yaratiladi)
 * - sahifa matnidagi [rahbariyat] belgisi o'rniga kartochkalar chiqariladi
 */

const LEADER_DAYS = ['Dushanba', 'Seshanba', 'Chorshanba', 'Payshanba', 'Juma', 'Shanba', 'Yakshanba'];

function leaders_ensure_table(): void {
    static $done = false;
    if ($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS leaders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(160) NOT NULL,
        position VARCHAR(255) DEFAULT NULL,
        phone VARCHAR(64) DEFAULT NULL,
        email VARCHAR(128) DEFAULT NULL,
        photo VARCHAR(255) DEFAULT NULL,
        reception_from VARCHAR(5) DEFAULT NULL,
        reception_to VARCHAR(5) DEFAULT NULL,
        reception_days VARCHAR(160) DEFAULT NULL,
        career_intro TEXT,
        career MEDIUMTEXT,
        duties TEXT,
        is_head TINYINT(1) NOT NULL DEFAULT 0,
        sort_order INT NOT NULL DEFAULT 0,
        active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}

function get_leaders(bool $onlyActive = true): array {
    try {
        leaders_ensure_table();
        $sql = 'SELECT * FROM leaders' . ($onlyActive ? ' WHERE active=1' : '') . ' ORDER BY sort_order, id';
        return db()->query($sql)->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

function get_leader(int $id): ?array {
    leaders_ensure_table();
    $st = db()->prepare('SELECT * FROM leaders WHERE id=?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

/** Mehnat faoliyati qatorlari: [['y'=>'2002','t'=>'...'], ...] */
function leader_career(array $l): array {
    $rows = json_decode((string)($l['career'] ?? ''), true);
    return is_array($rows) ? $rows : [];
}

function leader_photo_url(?string $p): ?string {
    if (!$p) return null;
    if (preg_match('~^(https?:)?//~i', $p) || strpos($p, '/') === 0) return $p;
    return UPLOAD_URL . rawurlencode($p);
}

/** Saytdagi rahbar kartochkalari (HTML) */
function render_leaders_html(): string {
    $list = get_leaders(true);
    if (!$list) return '';

    $svg = fn(string $p) => '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" aria-hidden="true">' . $p . '</svg>';
    $ic = [
        'tel'  => $svg('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/>'),
        'mail' => $svg('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/>'),
        'time' => $svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
        'day'  => $svg('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>'),
        'job'  => $svg('<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>'),
        'list' => $svg('<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>'),
        'chk'  => $svg('<path d="M20 6 9 17l-5-5"/>'),
    ];

    ob_start();
    echo '<div class="ldr-list">';
    foreach ($list as $l):
        $lid    = (int)$l['id'];
        $img    = leader_photo_url($l['photo']);
        $career = leader_career($l);
        $intro  = trim((string)$l['career_intro']);
        $time   = trim(($l['reception_from'] ?? '') . ($l['reception_to'] ? ' – ' . $l['reception_to'] : ''));
        $days   = str_replace(',', ', ', (string)$l['reception_days']);
        $duties = array_values(array_filter(array_map('trim', preg_split('~\R~u', (string)$l['duties']))));
        // "a; b; c" ko'rinishidagi bitta qatorni ham ro'yxatga ajratamiz
        if (count($duties) === 1 && substr_count($duties[0], ';') >= 2) {
            $duties = array_values(array_filter(array_map('trim', explode(';', $duties[0]))));
        }
        $duties = array_map(fn($d) => mb_strtoupper(mb_substr($d, 0, 1)) . mb_substr($d, 1), $duties);
        $words    = preg_split('~\s+~u', trim($l['full_name']));
        $initials = mb_strtoupper(mb_substr($words[0] ?? '', 0, 1) . mb_substr($words[1] ?? '', 0, 1));
        $hasCareer = $intro !== '' || $career;
        ?>
        <article class="ldr-card<?= $l['is_head'] ? ' is-head' : '' ?>" id="rahbar-<?= $lid ?>">
          <div class="ldr-top">
            <div class="ldr-photo">
              <?php if ($img): ?><img src="<?= h($img) ?>" alt="<?= h($l['full_name']) ?>" loading="lazy">
              <?php else: ?><span class="ldr-initials"><?= h($initials) ?></span><?php endif; ?>
            </div>

            <div class="ldr-main">
              <?php if ($l['is_head']): ?><span class="ldr-badge">Markaz rahbari</span><?php endif; ?>
              <h2 class="ldr-name"><?= h($l['full_name']) ?></h2>
              <?php if ($l['position']): ?><p class="ldr-pos"><?= h($l['position']) ?></p><?php endif; ?>

              <div class="ldr-facts">
                <?php if ($l['phone']): ?>
                  <a class="ldr-fact" href="tel:<?= h(preg_replace('~[^\d+]~', '', $l['phone'])) ?>">
                    <i><?= $ic['tel'] ?></i><span><small>Telefon</small><b><?= h($l['phone']) ?></b></span>
                  </a>
                <?php endif; ?>
                <?php if ($l['email']): ?>
                  <a class="ldr-fact" href="mailto:<?= h($l['email']) ?>">
                    <i><?= $ic['mail'] ?></i><span><small>Elektron pochta</small><b><?= h($l['email']) ?></b></span>
                  </a>
                <?php endif; ?>
                <?php if ($days !== ''): ?>
                  <div class="ldr-fact">
                    <i><?= $ic['day'] ?></i><span><small>Qabul kunlari</small><b><?= h($days) ?></b></span>
                  </div>
                <?php endif; ?>
                <?php if ($time !== ''): ?>
                  <div class="ldr-fact">
                    <i><?= $ic['time'] ?></i><span><small>Qabul vaqti</small><b><?= h($time) ?></b></span>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <?php if ($hasCareer || $duties): ?>
          <div class="ldr-tabs" data-tabs>
            <div class="ldr-tablist" role="tablist">
              <?php if ($hasCareer): ?>
                <button type="button" role="tab" id="t-c-<?= $lid ?>" aria-controls="p-c-<?= $lid ?>" aria-selected="true"><?= $ic['job'] ?>Mehnat faoliyati</button>
              <?php endif; ?>
              <?php if ($duties): ?>
                <button type="button" role="tab" id="t-d-<?= $lid ?>" aria-controls="p-d-<?= $lid ?>" aria-selected="<?= $hasCareer ? 'false' : 'true' ?>"><?= $ic['list'] ?>Vazifalari</button>
              <?php endif; ?>
            </div>

            <?php if ($hasCareer): ?>
            <div class="ldr-panel" role="tabpanel" id="p-c-<?= $lid ?>" aria-labelledby="t-c-<?= $lid ?>">
              <?php if ($intro !== ''): ?><p class="ldr-intro"><?= nl2br(h($intro)) ?></p><?php endif; ?>
              <?php if ($career): ?>
                <ol class="ldr-tl">
                  <?php foreach ($career as $r): ?>
                    <li>
                      <?php if (($r['y'] ?? '') !== ''): ?><span class="yr"><?= h($r['y']) ?></span><?php endif; ?>
                      <p><?= h($r['t'] ?? '') ?></p>
                    </li>
                  <?php endforeach; ?>
                </ol>
              <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($duties): ?>
            <div class="ldr-panel" role="tabpanel" id="p-d-<?= $lid ?>" aria-labelledby="t-d-<?= $lid ?>">
              <?php if (count($duties) === 1): ?>
                <p class="ldr-intro"><?= h($duties[0]) ?></p>
              <?php else: ?>
                <ul class="ldr-duties">
                  <?php foreach ($duties as $d): ?><li><i><?= $ic['chk'] ?></i><span><?= h(rtrim($d, ';')) ?></span></li><?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </div>
            <?php endif; ?>
          </div>
          <?php endif; ?>
        </article>
    <?php
    endforeach;
    echo '</div>';
    return ob_get_clean();
}

/** Sahifa matnidagi [rahbariyat] belgisini kartochkalar bilan almashtiradi */
function apply_leaders_shortcode(string $html): string {
    if (stripos($html, '[rahbariyat]') === false) return $html;
    $block = render_leaders_html();
    $html = preg_replace('~<p>\s*\[rahbariyat\]\s*</p>~i', '[rahbariyat]', $html);
    return str_ireplace('[rahbariyat]', $block, $html);
}

/**
 * Eski sahifadagi (qo'lda yozilgan) .pmm-person kartochkalarini jadvalga ko'chiradi
 * va sahifa matnida ularning o'rniga [rahbariyat] qo'yadi.
 * Qaytaradi: ko'chirilgan rahbarlar soni.
 */
function leaders_import_from_page(int $pageId): int {
    leaders_ensure_table();
    $st = db()->prepare('SELECT * FROM pages WHERE id=?');
    $st->execute([$pageId]);
    $page = $st->fetch();
    if (!$page || stripos((string)$page['content'], 'pmm-person') === false) return 0;

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8"?><div id="__root">' . $page['content'] . '</div>');
    libxml_clear_errors();
    $xp   = new DOMXPath($dom);
    $root = $dom->getElementById('__root');
    $cls  = fn(string $c) => "contains(concat(' ', normalize-space(@class), ' '), ' $c ')";
    $clean = fn(string $s) => trim(preg_replace('~^[^\p{L}\p{N}+]+~u', '', trim(preg_replace('~\s+~u', ' ', $s))));

    $cards = $xp->query('.//div[' . $cls('pmm-person') . ']', $root);
    if (!$cards->length) return 0;

    $order = (int)db()->query('SELECT COALESCE(MAX(sort_order),0) FROM leaders')->fetchColumn();
    $ins = db()->prepare('INSERT INTO leaders (full_name, position, phone, email, photo, reception_from, reception_to,
                          reception_days, career_intro, career, duties, is_head, sort_order, active)
                          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)');
    $count = 0;
    $first = null;

    foreach (iterator_to_array($cards) as $card) {
        $q = fn(string $expr) => $xp->query($expr, $card)->item(0);
        $name = ($n = $q('.//*[' . $cls('nm') . ']')) ? $clean($n->textContent) : '';
        if ($name === '') continue;
        $pos = ($n = $q('.//*[' . $cls('pos') . ']')) ? $clean($n->textContent) : '';

        $photo = null;
        if (($img = $q('.//*[' . $cls('ph') . ']//img')) && $img->getAttribute('src')) {
            $src = $img->getAttribute('src');
            $photo = preg_match('~/assets/uploads/([^/?#]+)$~', $src, $m) ? rawurldecode($m[1]) : $src;
        }

        $phone = $email = $from = $to = $days = '';
        foreach ($xp->query('.//*[' . $cls('meta') . ']/*', $card) as $chip) {
            $txt  = $clean($chip->textContent);
            $href = $chip instanceof DOMElement ? $chip->getAttribute('href') : '';
            if (stripos($href, 'tel:') === 0)            $phone = $txt;
            elseif (stripos($href, 'mailto:') === 0)     $email = $txt;
            elseif (preg_match('~(\d{1,2}[:.]\d{2})\s*[–—-]\s*(\d{1,2}[:.]\d{2})~u', $txt, $m)) {
                $from = str_replace('.', ':', $m[1]); $to = str_replace('.', ':', $m[2]);
            } else {
                $words = array_map(fn($w) => mb_strtolower($w), preg_split('~[^\p{L}]+~u', $txt, -1, PREG_SPLIT_NO_EMPTY));
                $found = array_filter(LEADER_DAYS, fn($d) => in_array(mb_strtolower($d), $words, true));
                if ($found) $days = implode(',', $found);
            }
        }

        // Bio: "Mehnat faoliyati:" matni + ro'yxat, "Asosiy vazifalari:" matni
        $intro = ''; $career = []; $duties = ''; $section = 'career';
        $bio = $q('.//*[' . $cls('bio') . ']');
        if ($bio) {
            foreach ($bio->childNodes as $node) {
                if (!($node instanceof DOMElement)) continue;
                $tag = strtolower($node->nodeName);
                $txt = trim(preg_replace('~\s+~u', ' ', $node->textContent));
                if ($tag === 'ul' || $tag === 'ol') {
                    foreach ($xp->query('./li', $node) as $li) {
                        $lt = trim(preg_replace('~\s+~u', ' ', $li->textContent));
                        $b  = $xp->query('./b|./strong', $li)->item(0);
                        $y  = '';
                        if ($b && mb_strpos($lt, trim($b->textContent)) === 0) {
                            $y  = rtrim(trim($b->textContent), ': ');
                            $lt = trim(mb_substr($lt, mb_strlen(trim($b->textContent))), ": \t");
                        }
                        if ($section === 'duties') $duties .= ($duties !== '' ? "\n" : '') . $lt;
                        else $career[] = ['y' => $y, 't' => $lt];
                    }
                } elseif (preg_match('~^Mehnat faoliyati\s*:?\s*(.*)$~iu', $txt, $m)) {
                    $section = 'career'; $intro = trim($m[1]);
                } elseif (preg_match('~^Asosiy vazifalari\s*:?\s*(.*)$~iu', $txt, $m)) {
                    $section = 'duties'; $duties = trim($m[1]);
                } elseif ($txt !== '') {
                    if ($section === 'duties') $duties .= ($duties !== '' ? "\n" : '') . $txt;
                    else $intro .= ($intro !== '' ? "\n" : '') . $txt;
                }
            }
        }

        $isHead = (int)str_contains(' ' . $card->getAttribute('class') . ' ', ' head ');
        $ins->execute([$name, $pos, $phone, $email, $photo, $from ?: null, $to ?: null, $days,
                       $intro, json_encode($career, JSON_UNESCAPED_UNICODE), $duties, $isHead, ++$order]);
        $count++;

        // Sahifadan olib tashlash; birinchisi o'rniga belgi qo'yiladi
        if ($first === null) {
            $first = $dom->createElement('p', '[rahbariyat]');
            $card->parentNode->replaceChild($first, $card);
        } else {
            $card->parentNode->removeChild($card);
        }
    }

    if ($count) {
        $out = '';
        foreach ($root->childNodes as $ch) $out .= $dom->saveHTML($ch);
        save_setting('leaders_backup_page_' . $pageId, $page['content']); // zaxira nusxa
        db()->prepare('UPDATE pages SET content=? WHERE id=?')->execute([$out, $pageId]);
    }
    return $count;
}

/**
 * Zaxiradan qaytarish: sahifaning ko'chirishdan oldingi matnini tiklaydi va
 * o'sha sahifadan ko'chirilgan kishilarni (ism bo'yicha) rahbarlar ro'yxatidan o'chiradi.
 * Qaytaradi: [tiklandi(bool), o'chirilganlar soni]
 */
function leaders_restore_page(int $pageId): array {
    leaders_ensure_table();
    $key = 'leaders_backup_page_' . $pageId;
    $st  = db()->prepare('SELECT svalue FROM settings WHERE skey=?');
    $st->execute([$key]);
    $backup = $st->fetchColumn();
    if ($backup === false || $backup === '') return [false, 0];

    // Zaxiradagi kartochkalardan ismlarni olamiz
    $names = [];
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8"?><div>' . $backup . '</div>');
    libxml_clear_errors();
    $xp = new DOMXPath($dom);
    foreach ($xp->query("//div[contains(concat(' ', normalize-space(@class), ' '), ' pmm-person ')]//*[contains(concat(' ', normalize-space(@class), ' '), ' nm ')]") as $n) {
        $nm = trim(preg_replace('~^[^\p{L}\p{N}+]+~u', '', trim(preg_replace('~\s+~u', ' ', $n->textContent))));
        if ($nm !== '') $names[] = $nm;
    }

    $deleted = 0;
    if ($names) {
        $sel = db()->prepare('SELECT id, photo FROM leaders WHERE full_name = ?');
        $del = db()->prepare('DELETE FROM leaders WHERE id = ?');
        foreach (array_unique($names) as $nm) {
            $sel->execute([$nm]);
            foreach ($sel->fetchAll() as $r) {   // rasm fayli sahifada ham ishlatiladi — o'chirilmaydi
                $del->execute([$r['id']]);
                $deleted++;
            }
        }
    }

    db()->prepare('UPDATE pages SET content=? WHERE id=?')->execute([$backup, $pageId]);
    db()->prepare('DELETE FROM settings WHERE skey=?')->execute([$key]);
    return [true, $deleted];
}

/** Zaxirasi bor sahifalar ro'yxati */
function leaders_backups(): array {
    try {
        return db()->query("SELECT p.id, p.title, p.slug FROM settings s
                            JOIN pages p ON p.id = CAST(SUBSTRING(s.skey, 21) AS UNSIGNED)
                            WHERE s.skey LIKE 'leaders\\_backup\\_page\\_%' ORDER BY p.title")->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}
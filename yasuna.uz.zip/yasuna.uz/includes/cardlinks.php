<?php
/**
 * KARTA HAVOLALARI — sahifa matnidagi .pmm-staff > .st kartalarini bosiladigan qiladi.
 *
 * Qoida:  1) admin → «Karta havolalari» da qo'lda tanlangan havola
 *         2) topilmasa — avtomatik: nomi mos menyu bandi / sahifa / bo'lim
 * Saqlanadi: settings.card_links (JSON)  { "normallashgan nom": {"type":"page","id":5}, ... }
 */

/** Nomni solishtirish uchun normallashtirish (katta-kichik harf, tutuq belgilari, bo'shliqlar) */
function card_key(string $s): string {
    $s = html_entity_decode($s, ENT_QUOTES, 'UTF-8');
    $s = mb_strtolower(trim($s), 'UTF-8');
    $s = str_replace(["'", '`', "\u{2018}", "\u{2019}", "\u{201B}", "\u{02BB}", "\u{02BC}", "\u{2032}", '"', '«', '»'], '', $s);
    return trim(preg_replace('~\s+~u', ' ', $s));
}

function card_links_map(): array {
    $m = json_decode((string)setting('card_links'), true);
    return is_array($m) ? $m : [];
}

function card_links_save(array $map): void {
    save_setting('card_links', json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

/** Avtomatik moslash uchun lug'at: nom => URL (menyu, sahifalar, bo'limlar) */
function card_auto_index(): array {
    static $idx = null;
    if ($idx !== null) return $idx;
    $idx = [];
    try {
        foreach (db()->query('SELECT id, name, slug FROM categories') as $c) {
            $idx[card_key($c['name'])] ??= category_url($c);
        }
        foreach (db()->query("SELECT id, title, slug FROM pages WHERE status='published'") as $p) {
            $idx[card_key($p['title'])] = page_url($p);
        }
        // Menyu bandlari eng ustun (admin shu nomni aynan shu joyga bog'lagan)
        $walk = function (array $items) use (&$walk, &$idx) {
            foreach ($items as $m) {
                if (($m['href'] ?? '#') !== '#' && !empty($m['clickable'])) $idx[card_key($m['title'])] = $m['href'];
                if (!empty($m['children'])) $walk($m['children']);
            }
        };
        if (function_exists('get_menu')) $walk(get_menu());
    } catch (Throwable $e) { /* jadval bo'lmasa — avtomatik havola yo'q */ }
    return $idx;
}

/** Rahbariyat sahifasining manzili ([rahbariyat] belgisi turgan sahifa) */
function leaders_page_url(): ?string {
    static $u = false;
    if ($u !== false) return $u;
    $u = null;
    try {
        $p = db()->query("SELECT slug FROM pages WHERE status='published' AND content LIKE '%[rahbariyat]%' LIMIT 1")->fetch();
        if ($p) $u = page_url($p);
    } catch (Throwable $e) {}
    return $u;
}

/** Bitta qoidani URL ga aylantiradi (null — havola yo'q) */
function card_rule_url(?array $r): ?string {
    if (!$r) return null;
    switch ($r['type'] ?? '') {
        case 'page':
            $st = db()->prepare("SELECT slug FROM pages WHERE id=? AND status='published'");
            $st->execute([(int)$r['id']]);
            return ($p = $st->fetch()) ? page_url($p) : null;
        case 'category':
            $st = db()->prepare('SELECT slug FROM categories WHERE id=?');
            $st->execute([(int)$r['id']]);
            return ($c = $st->fetch()) ? category_url($c) : null;
        case 'leader':
            $base = leaders_page_url();
            return $base ? $base . '#rahbar-' . (int)$r['id'] : null;
        case 'url':
            $u = trim((string)($r['url'] ?? ''));
            if ($u === '') return null;
            if (strpos($u, '/') === 0) return BASE_URL . $u;
            return preg_match('~^https?://~i', $u) ? $u : null;
    }
    return null;
}

/** Karta nomi bo'yicha yakuniy URL: [url, manba]  manba: manual|auto|none|off */
function card_resolve(string $title): array {
    $key = card_key($title);
    $map = card_links_map();
    if (isset($map[$key])) {
        if (($map[$key]['type'] ?? '') === 'none') return [null, 'off'];
        $u = card_rule_url($map[$key]);
        if ($u) return [$u, 'manual'];
    }
    $idx = card_auto_index();
    return isset($idx[$key]) ? [$idx[$key], 'auto'] : [null, 'none'];
}

/** Sahifa matnidagi kartalarni o'qish (admin ro'yxati uchun): [[title, pos, group], ...] */
function extract_staff_cards(string $html): array {
    $out = [];
    if (stripos($html, 'pmm-staff') === false) return $out;
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8"?><div>' . $html . '</div>');
    libxml_clear_errors();
    $xp = new DOMXPath($dom);
    $has = fn($c) => "contains(concat(' ', normalize-space(@class), ' '), ' $c ')";
    foreach ($xp->query('//*[' . $has('pmm-staff') . ']') as $grid) {
        $group = '';
        for ($n = $grid->previousSibling; $n; $n = $n->previousSibling) {
            if ($n instanceof DOMElement && preg_match('~^h[1-6]$~i', $n->nodeName)) { $group = trim($n->textContent); break; }
        }
        foreach ($xp->query('./*[' . $has('st') . ']', $grid) as $st) {
            $nm  = $xp->query('.//*[' . $has('nm') . ']', $st)->item(0);
            $pos = $xp->query('.//*[' . $has('pos') . ']', $st)->item(0);
            $t = $nm ? trim(preg_replace('~\s+~u', ' ', $nm->textContent)) : '';
            if ($t !== '') $out[] = ['title' => $t, 'pos' => $pos ? trim($pos->textContent) : '', 'group' => $group];
        }
    }
    return $out;
}

/** Saytda: kartalarni havolaga aylantiradi (<div class="st"> → <a class="st is-link">) */
function apply_card_links(string $html): string {
    if (stripos($html, 'pmm-staff') === false) return $html;

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8"?><div id="__cl_root">' . $html . '</div>');
    libxml_clear_errors();
    $xp   = new DOMXPath($dom);
    $root = $dom->getElementById('__cl_root');
    $has  = fn($c) => "contains(concat(' ', normalize-space(@class), ' '), ' $c ')";
    $changed = false;

    foreach (iterator_to_array($xp->query('.//*[' . $has('pmm-staff') . ']/*[' . $has('st') . ']', $root)) as $st) {
        if ($st->nodeName === 'a' || $xp->query('.//a', $st)->length) continue; // ichida havola bor — ichma-ich <a> bo'lmasin
        $nm = $xp->query('.//*[' . $has('nm') . ']', $st)->item(0);
        if (!$nm) continue;
        [$url] = card_resolve($nm->textContent);
        if (!$url) continue;

        $a = $dom->createElement('a');
        foreach ($st->attributes as $attr) $a->setAttribute($attr->name, $attr->value);
        $a->setAttribute('class', trim($st->getAttribute('class') . ' is-link'));
        $a->setAttribute('href', $url);
        if (preg_match('~^https?://~i', $url) && strpos($url, BASE_URL) !== 0) {
            $a->setAttribute('target', '_blank');
            $a->setAttribute('rel', 'noopener');
        }
        while ($st->firstChild) $a->appendChild($st->firstChild);
        $go = $dom->createElement('span', '→');
        $go->setAttribute('class', 'st-go');
        $go->setAttribute('aria-hidden', 'true');
        $a->appendChild($go);
        $st->parentNode->replaceChild($a, $st);
        $changed = true;
    }
    if (!$changed) return $html;

    $out = '';
    foreach ($root->childNodes as $ch) $out .= $dom->saveHTML($ch);
    return $out;
}
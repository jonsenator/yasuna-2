<?php
function conferences_ensure_table(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec("CREATE TABLE IF NOT EXISTS conferences (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(500) NOT NULL,
      type ENUM('xalqaro','respublika') NOT NULL DEFAULT 'respublika',
      year SMALLINT DEFAULT NULL,
      event_date DATE DEFAULT NULL,
      date_text VARCHAR(120) DEFAULT NULL,
      location VARCHAR(255) DEFAULT NULL,
      participants INT NOT NULL DEFAULT 0,
      countries INT NOT NULL DEFAULT 0,
      tags VARCHAR(500) DEFAULT NULL,
      short_code VARCHAR(20) DEFAULT NULL,
      description TEXT,
      pdf_url VARCHAR(500) DEFAULT NULL,
      link_url VARCHAR(500) DEFAULT NULL,
      image VARCHAR(255) DEFAULT NULL,
      sort_order INT NOT NULL DEFAULT 0,
      active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX (type), INDEX (year), INDEX (active), INDEX (sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function get_conferences(bool $only_active = true, ?string $type = null): array {
    conferences_ensure_table();
    $sql = "SELECT * FROM conferences";
    $where = [];
    $params = [];
    if ($only_active) $where[] = "active = 1";
    if ($type === 'xalqaro' || $type === 'respublika') {
        $where[] = "type = ?";
        $params[] = $type;
    }
    if ($where) $sql .= " WHERE " . implode(' AND ', $where);
    $sql .= " ORDER BY year DESC, sort_order ASC, id DESC";
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function get_conference(int $id): ?array {
    conferences_ensure_table();
    $st = db()->prepare("SELECT * FROM conferences WHERE id = ?");
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}

function conference_stats(): array {
    conferences_ensure_table();
    $total = (int)db()->query("SELECT COUNT(*) FROM conferences WHERE active=1")->fetchColumn();
    $xalqaro = (int)db()->query("SELECT COUNT(*) FROM conferences WHERE active=1 AND type='xalqaro'")->fetchColumn();
    $respublika = (int)db()->query("SELECT COUNT(*) FROM conferences WHERE active=1 AND type='respublika'")->fetchColumn();
    $countries = (int)db()->query("SELECT COALESCE(SUM(countries),0) FROM conferences WHERE active=1")->fetchColumn();
    $participants = (int)db()->query("SELECT COALESCE(SUM(participants),0) FROM conferences WHERE active=1")->fetchColumn();
    return compact('total', 'xalqaro', 'respublika', 'countries', 'participants');
}

function render_conferences_page(): void {
    conferences_ensure_table();
    $stats = conference_stats();
    $all = get_conferences(true);
    $filter = $_GET['type'] ?? 'all';
    if (!in_array($filter, ['all', 'xalqaro', 'respublika'], true)) $filter = 'all';
    $list = $all;
    if ($filter === 'xalqaro') $list = array_values(array_filter($all, fn($c) => $c['type'] === 'xalqaro'));
    elseif ($filter === 'respublika') $list = array_values(array_filter($all, fn($c) => $c['type'] === 'respublika'));
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q !== '') {
        $ql = mb_strtolower($q);
        $list = array_values(array_filter($list, function ($c) use ($ql) {
            return mb_strpos(mb_strtolower($c['title']), $ql) !== false
                || mb_strpos(mb_strtolower((string)$c['location']), $ql) !== false
                || mb_strpos(mb_strtolower((string)$c['tags']), $ql) !== false;
        }));
    }
    $base = BASE_URL . '/page.php?slug=ilmiy-amaliy-konferensiya';
    ?>
<section class="conf-hero">
  <div class="wrap">
    <div class="conf-hero-inner">
      <h1>Bizning <span class="accent">respublika</span> va<br><span class="accent2">xalqaro</span> konferensiyalarimiz</h1>
      <p class="conf-lead">Ta'lim sohasidagi eng muhim ilmiy-amaliy anjumanlar to'plami.</p>
      <div class="conf-actions">
        <a href="#conf-list" class="btn-gold">Konferensiyalarni ko'rish</a>
        <a href="<?= BASE_URL ?>/contact.php" class="btn-outline-w">Batafsil ma'lumot</a>
      </div>
      <div class="conf-stats">
        <div class="cs"><strong><?= $stats['total'] ?>+</strong><span>Jami konferensiyalar</span></div>
        <div class="cs"><strong><?= $stats['xalqaro'] ?>+</strong><span>Xalqaro anjumanlar</span></div>
        <div class="cs"><strong><?= max($stats['countries'], 10) ?>+</strong><span>Hamkor davlatlar</span></div>
      </div>
    </div>
  </div>
</section>
<section class="wrap conf-section" id="conf-list">
  <div class="sec-head conf-sec-head">
    <div>
      <div class="eyebrow">Ilmiy anjumanlar</div>
      <h2>Konferensiyalar ro'yxati</h2>
      <p class="sec-desc">Respublika va xalqaro darajadagi konferensiyalarimiz bilan tanishing.</p>
    </div>
  </div>
  <div class="conf-toolbar">
    <div class="conf-filters">
      <a href="<?= h($base) ?>" class="cf-btn<?= $filter==='all'?' active':'' ?>">Hammasi <span><?= $stats['total'] ?></span></a>
      <a href="<?= h($base . '&type=xalqaro') ?>" class="cf-btn<?= $filter==='xalqaro'?' active':'' ?>">Xalqaro <span><?= $stats['xalqaro'] ?></span></a>
      <a href="<?= h($base . '&type=respublika') ?>" class="cf-btn<?= $filter==='respublika'?' active':'' ?>">Respublika <span><?= $stats['respublika'] ?></span></a>
    </div>
    <form class="conf-search" method="get" action="<?= h($base) ?>">
      <?php if ($filter !== 'all'): ?><input type="hidden" name="type" value="<?= h($filter) ?>"><?php endif; ?>
      <input type="hidden" name="slug" value="ilmiy-amaliy-konferensiya">
      <input type="search" name="q" value="<?= h($q) ?>" placeholder="Konferensiya qidirish...">
      <button type="submit" aria-label="Qidirish">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      </button>
    </form>
  </div>
  <?php if (!$list): ?>
    <div class="empty" style="margin:40px 0"><h3>Hozircha konferensiya topilmadi</h3><p>Tez orada yangi anjumanlar qo'shiladi.</p></div>
  <?php else: ?>
    <div class="conf-grid">
      <?php foreach ($list as $c):
        $isX = $c['type'] === 'xalqaro';
        $code = trim((string)$c['short_code']);
        if ($code === '') $code = $isX ? 'XAL' : mb_strtoupper(mb_substr(preg_replace('/[^a-zA-Zа-яА-ЯёЁўқғҳʼ\' ]/u', '', $c['title']), 0, 2));
        $tags = array_filter(array_map('trim', explode(',', (string)$c['tags'])));
        $dateShow = $c['date_text'] ?: ($c['event_date'] ? uzdate($c['event_date']) : '');
        $year = $c['year'] ?: ($c['event_date'] ? date('Y', strtotime($c['event_date'])) : '');
      ?>
        <article class="conf-card">
          <div class="conf-card-top <?= $isX ? 'xal' : 'res' ?>">
            <span class="conf-badge"><?= $isX ? 'XALQARO' : 'RESPUBLIKA' ?></span>
            <div class="conf-code"><?= h($code) ?></div>
            <?php if ($year): ?><span class="conf-year"><?= (int)$year ?></span><?php endif; ?>
          </div>
          <div class="conf-card-body">
            <?php if ($dateShow): ?><div class="conf-date"><?= h($dateShow) ?></div><?php endif; ?>
            <h3><?= h($c['title']) ?></h3>
            <div class="conf-meta">
              <?php if ($c['location']): ?><div>Joy: <?= h($c['location']) ?></div><?php endif; ?>
              <?php if ((int)$c['participants'] > 0): ?><div>Ishtirokchilar: <?= number_format((int)$c['participants']) ?></div><?php endif; ?>
              <?php if ((int)$c['countries'] > 0): ?><div>Davlatlar: <?= (int)$c['countries'] ?></div><?php endif; ?>
            </div>
            <?php if ($tags): ?><div class="conf-tags"><?php foreach ($tags as $t): ?><span><?= h($t) ?></span><?php endforeach; ?></div><?php endif; ?>
            <div class="conf-actions-row">
              <?php if ($c['link_url']): ?><a class="conf-link" href="<?= h($c['link_url']) ?>" target="_blank" rel="noopener">Batafsil</a><?php endif; ?>
              <?php if ($c['pdf_url']): ?><a class="conf-pdf" href="<?= h($c['pdf_url']) ?>" target="_blank" rel="noopener">PDF</a><?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
<section class="wrap conf-cta">
  <div class="conf-cta-inner">
    <h2>Keyingi konferensiyada biz bilan birga bo'ling</h2>
    <p>Yangi anjumanlar haqida birinchi bo'lib xabardor bo'ling.</p>
    <a class="btn-cta" href="<?= BASE_URL ?>/contact.php">Bog'lanish</a>
  </div>
</section>
<?php
}
<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/includes/queries.php';

$perPage = 9;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$posts    = get_latest_posts($perPage, $offset);
$slides   = $page === 1 ? get_slider() : [];
$total    = count_published_posts();
$pages    = max(1, (int)ceil($total / $perPage));

$active_slug = '';
$meta_title  = setting('site_name', 'Qashqadaryo PMM') . ' — rasmiy sayt';
require __DIR__ . '/includes/header.php';
?>

<?php if ($slides): ?>
<!-- Hero slayder (admin → Slayder) -->
<section class="wrap hero">
  <div class="slider">
    <div class="slides">
      <?php foreach ($slides as $i => $s):
        $simg = slider_image_url($s['image']);
        $link = trim((string)$s['link']);
        if ($link !== '' && strpos($link, '/') === 0) $link = BASE_URL . $link; ?>
        <div class="slide<?= $i === 0 ? ' active' : '' ?>">
          <?php if ($simg): ?><img src="<?= h($simg) ?>" alt="<?= h($s['title']) ?>"<?= $i ? ' loading="lazy"' : '' ?>><?php endif; ?>
          <div class="scrim"></div>
          <div class="caption">
            <h2><?= h($s['title']) ?></h2>
            <?php if (!empty($s['subtitle'])): ?><div class="meta"><?= h($s['subtitle']) ?></div><?php endif; ?>
            <?php if ($link !== ''): ?><a class="btn-read" href="<?= h($link) ?>">Batafsil &rarr;</a><?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php if (count($slides) > 1): ?>
      <button class="slider-btn prev" type="button" aria-label="Oldingi">&lsaquo;</button>
      <button class="slider-btn next" type="button" aria-label="Keyingi">&rsaquo;</button>
      <div class="dots">
        <?php foreach ($slides as $i => $s): ?><button type="button" class="<?= $i === 0 ? 'active' : '' ?>" aria-label="<?= $i + 1 ?>-slayd"></button><?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<section class="wrap section" style="padding-top:<?= $slides ? '10px' : '34px' ?>">
  <div class="sec-head">
    <div>
      <div class="eyebrow">Markaz hayoti</div>
      <h2>So'nggi yangiliklar</h2>
    </div>
    <a class="sec-link" href="<?= BASE_URL ?>/category.php?slug=yangiliklar">Barchasi &rarr;</a>
  </div>

  <?php if ($posts): ?>
    <div class="grid">
      <?php foreach ($posts as $p): $img = post_image_url($p['image']); ?>
        <a class="card reveal" href="<?= post_url($p) ?>">
          <div class="thumb">
            <?php if ($img): ?><img src="<?= h($img) ?>" alt="<?= h($p['title']) ?>" loading="lazy">
            <?php else: ?><div class="noimg">PMM</div><?php endif; ?>
            <?php if (!empty($p['cat'])): ?><span class="badge"><?= h($p['cat']) ?></span><?php endif; ?>
          </div>
          <div class="body">
            <div class="date">
              <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
              <?= uzdate($p['created_at']) ?>
            </div>
            <h3><?= h($p['title']) ?></h3>
            <p><?= h(make_excerpt($p)) ?></p>
            <span class="readmore">Batafsil &rarr;</span>
          </div>
        </a>
      <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>">&lsaquo;</a><?php endif; ?>
        <?php for ($n=1;$n<=$pages;$n++): ?>
          <?php if ($n===$page): ?><span class="cur"><?= $n ?></span>
          <?php else: ?><a href="?page=<?= $n ?>"><?= $n ?></a><?php endif; ?>
        <?php endfor; ?>
        <?php if ($page < $pages): ?><a href="?page=<?= $page+1 ?>">&rsaquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div class="empty"><h3>Hozircha yangilik yo'q</h3><p>Tez orada bu yerda markaz yangiliklari paydo bo'ladi.</p></div>
  <?php endif; ?>
</section>

<!-- Aloqa taklifi -->
<section class="wrap contact-cta">
  <div class="cta-inner">
    <div>
      <div class="eyebrow">Savollaringiz bormi?</div>
      <h2>Biz bilan bog'laning</h2>
      <p><?= h(setting('site_slogan')) ?></p>
    </div>
    <a class="btn-cta" href="<?= BASE_URL ?>/contact.php">Aloqa formasi &rarr;</a>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
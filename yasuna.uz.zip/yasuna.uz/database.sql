-- ============================================================
--  yasuna.uz — Qashqadaryo viloyati pedagogik mahorat markazi
--  Professional CMS | PHP + MySQL
--  Import: phpMyAdmin yoki `mysql -u root yasuna < database.sql`
-- ============================================================
SET NAMES utf8mb4;
SET time_zone = '+05:00';

-- ---------- Sozlamalar (key-value) ----------
CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  skey VARCHAR(64) NOT NULL UNIQUE,
  svalue TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Adminlar ----------
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(128),
  role VARCHAR(20) NOT NULL DEFAULT 'admin',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Kategoriyalar (ota/bola ierarxiyasi) ----------
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parent_id INT DEFAULT NULL,
  name VARCHAR(128) NOT NULL,
  slug VARCHAR(160) NOT NULL UNIQUE,
  description TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Yangiliklar ----------
CREATE TABLE IF NOT EXISTS posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT DEFAULT NULL,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(280) NOT NULL UNIQUE,
  excerpt VARCHAR(600),
  content MEDIUMTEXT,
  image VARCHAR(255),
  author_id INT DEFAULT NULL,
  status ENUM('draft','published') NOT NULL DEFAULT 'published',
  views INT NOT NULL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (category_id), INDEX (status), INDEX (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Statik sahifalar ----------
CREATE TABLE IF NOT EXISTS pages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(280) NOT NULL UNIQUE,
  content MEDIUMTEXT,
  status ENUM('draft','published') NOT NULL DEFAULT 'published',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Menyu ----------
CREATE TABLE IF NOT EXISTS menus (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parent_id INT DEFAULT NULL,
  title VARCHAR(128) NOT NULL,
  type ENUM('category','page','custom') NOT NULL DEFAULT 'category',
  ref_id INT DEFAULT NULL,      -- kategoriya/pages id (type bog'liq)
  url VARCHAR(255) DEFAULT NULL, -- custom havola uchun
  clickable TINYINT(1) NOT NULL DEFAULT 1, -- 0 = bosilmaydigan (faqat ichki menyu ochadi)
  sort_order INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Bosh sahifa slayderi ----------
CREATE TABLE IF NOT EXISTS slider (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  subtitle VARCHAR(500),
  image VARCHAR(255),
  link VARCHAR(255),
  sort_order INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Aloqa xabarlari ----------
CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(128) NOT NULL,
  email VARCHAR(128),
  phone VARCHAR(64),
  subject VARCHAR(255),
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ================= BOSHLANG'ICH MA'LUMOTLAR =================

-- Admin: login = admin | parol = Admin@2026  (kirgach o'zgartiring)
INSERT INTO users (username, password, full_name, role) VALUES
('admin', '$2y$12$.V99IW0QDglNY91YHGPnlOSErI/q/FC0JaDaoEFG1dCbFf8PS0nf.', 'Administrator', 'admin');

-- Sozlamalar
INSERT INTO settings (skey, svalue) VALUES
('site_name', 'Qashqadaryo viloyati pedagogik mahorat markazi'),
('site_short', 'Qashqadaryo PMM'),
('site_slogan', 'Sifatli ta''lim — yuksak mahoratdan boshlanadi.'),
('phone', '+998 75 000 00 00'),
('email', 'info@yasuna.uz'),
('address', 'Qashqadaryo viloyati, Qarshi shahri'),
('working_hours', 'Dushanba — Juma, 09:00 — 18:00'),
('telegram', 'https://t.me/yasuna_pmm'),
('facebook', ''),
('instagram', ''),
('youtube', ''),
('anticorruption_url', ''),
('banner_enabled', '1'),
('banner_text', 'O''zbekiston Respublikasi davlat mustaqilligiga 35 yil'),
('footer_text', 'Qashqadaryo viloyati pedagogik mahorat markazi'),
('copyright', 'Barcha huquqlar himoyalangan.'),
('meta_description', 'Qashqadaryo viloyati pedagogik mahorat markazining rasmiy sayti'),
('meta_keywords', 'Qashqadaryo, pedagogik mahorat, PMM, malaka oshirish, Qarshi');

-- Asosiy kategoriyalar (menyu ostidagi bo'limlar)
INSERT INTO categories (name, slug, sort_order) VALUES
('Markaz haqida', 'markaz-haqida', 1),
('Ilmiy faoliyat', 'ilmiy-faoliyat', 2),
('Malaka oshirish', 'malaka-oshirish', 3),
('Qayta tayyorlash', 'qayta-tayyorlash', 4),
('Ochiq ma''lumotlar', 'ochiq-malumotlar', 5),
('Tinglovchilar uchun', 'tinglovchilar-uchun', 6),
('Yangiliklar', 'yangiliklar', 7);

-- Bosh menyu
INSERT INTO menus (title, type, ref_id, url, sort_order) VALUES
('Bosh sahifa', 'custom', NULL, '/', 1),
('Markaz haqida', 'category', (SELECT id FROM categories WHERE slug='markaz-haqida'), NULL, 2),
('Yangiliklar', 'category', (SELECT id FROM categories WHERE slug='yangiliklar'), NULL, 3),
('Ilmiy faoliyat', 'category', (SELECT id FROM categories WHERE slug='ilmiy-faoliyat'), NULL, 4),
('Malaka oshirish', 'category', (SELECT id FROM categories WHERE slug='malaka-oshirish'), NULL, 5),
('Ochiq ma''lumotlar', 'category', (SELECT id FROM categories WHERE slug='ochiq-malumotlar'), NULL, 6),
('Bog''lanish', 'custom', NULL, '/contact.php', 7);